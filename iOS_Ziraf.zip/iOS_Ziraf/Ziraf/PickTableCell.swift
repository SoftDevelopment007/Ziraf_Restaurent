//
//  PickTableCell.swift
//  Ziraf
//
//  Created by LEE on 8/5/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

//after sound record, you can select friend picker....
class PickTableCell: UITableViewCell {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var rateText: UITextField!
    @IBOutlet weak var popularText: UITextField!
    
    @IBOutlet weak var selectButton: UIButton!
}
