//
//  ZirProfileViewController.swift
//  Ziraf
//
//  Created by LEE on 8/7/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ZirProfileViewController: UIViewController {
    
    let GlobalVar = Global()
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ziraferAvatar: UIImageView!
    
    @IBOutlet weak var Avatar_sameView: UIView!
    
    @IBOutlet weak var profession_Label: UILabel!
    @IBOutlet weak var quote_Label: UILabel!
    
    @IBOutlet weak var reviews_Label: UILabel!
    @IBOutlet weak var photos_Label: UILabel!
    
    // animation views
    @IBOutlet weak var review_View: UIView!
    @IBOutlet weak var photo_View: UIView!
    @IBOutlet weak var mid_View: UIView!
    @IBOutlet weak var under_View: UIView!
    
    @IBOutlet weak var Image_Overshadows: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel.text = "Zirafer"
        
        Avatar_sameView.bounds.size.height = Avatar_sameView.bounds.size.width
        ziraferAvatar.bounds.size.height = ziraferAvatar.bounds.size.width
        
        self.review_View.fadeOut(duration: 0.0, delay: 0.0)
        self.photo_View.fadeOut(duration: 0.0, delay: 0.0)
        self.mid_View.fadeOut(duration: 0.0, delay: 0.0)
        self.under_View.fadeOut(duration: 0.0, delay: 0.0)
        
        tryGet_ziraferProfile()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        Avatar_sameView.bounds.size.height = Avatar_sameView.bounds.size.width
        ziraferAvatar.bounds.size.height = ziraferAvatar.bounds.size.width
    }
    
    @IBAction func onTappedFaceBookLink(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string: g_zirafer_Profile.info.social_link[0])! as URL)
    }
    
    @IBAction func onTappedInstagramLink(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string: g_zirafer_Profile.info.social_link[2])! as URL)
    }
    
    @IBAction func onTappedTwitterLink(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string: g_zirafer_Profile.info.social_link[1])! as URL)
    }
    
    @IBAction func onTappedSnapChatLink(_ sender: Any) {
        UIApplication.shared.openURL(NSURL(string: g_zirafer_Profile.info.social_link[3])! as URL)
    }
    
    @IBAction func onTappedPhotoButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromZirProfileToPhotos.rawValue, sender: self)
    }
    
    @IBAction func onTappedReviewButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromZirafProfileToZirafReviews.rawValue, sender: self)
    }
    
    
    @IBAction func onTappedGotoHomeButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag) //2 views to pop
        navigationController?.setViewControllers(viewControllers!, animated: true)
    }
    
    @IBAction func onTappedGotoProfileButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //2
        self.performSegue(withIdentifier: StorySegues.FromzirProfileToProfile.rawValue, sender: self)
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedZirafButton(_ sender: Any) {
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromZirafProfileToZirafers.rawValue, sender: self)
        
        
        //g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        //self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func onTappedZirafProfileToDetailButtonMethod(_ sender: Any) {
        
        if g_zirafer_Profile.reviews.count > 0 {
            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
            
            g_Pick_Restaurant_Id = g_zirafer_Profile.reviews[0].rest_id
            self.performSegue(withIdentifier: StorySegues.FromZirafProfileToDetail.rawValue, sender: self)
            
        } else {
            
        }
    }
    
    
    
    //=========================================================================================
    //
    // Post get_ziraferProfile
    //
    //=========================================================================================
    func tryGet_ziraferProfile() {

        g_Init_Temp = zirafer_Info(id: -1, name: "", profession: "", quote: "", social_link: [])
        
        g_zirafer_Profile = zirafer_Profile_Info(info: g_Init_Temp, top_picks: [], reviews:[], restaurants: [], Zir_restaurants: [])
        g_zirafer_Profile.top_picks.removeAll()
        g_zirafer_Profile.restaurants.removeAll()
        
        
        let serviceObj = ServiceClass()
        if g_zirafersTozirProfile_selectedIndexNumber_Id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_ZiraferProfile)\(g_zirafersTozirProfile_selectedIndexNumber_Id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let info_dict          = responseObject["info"]  as! [String: AnyObject]
                    g_Init_Temp.id         = info_dict["_id"]        as! Int
                    g_Init_Temp.name       = info_dict["name"]       as! String
                    g_Init_Temp.profession = info_dict["profession"] as! String
                    g_Init_Temp.quote      = info_dict["quote"]      as! String
                    
                    g_Init_Temp.social_link.removeAll()
                    let social_link_temp   = info_dict["social_link"]  as! [String]
                    for i in 0..<social_link_temp.count {
                        g_Init_Temp.social_link.append(social_link_temp[i])
                    }
                    
                    
                    g_zirafer_Profile.info = g_Init_Temp
                    
                    
                    let top_picks_dict     = responseObject["top_picks"]  as! NSArray
                    if (top_picks_dict != nil ) {
                        for top_picks_data in top_picks_dict {
                            
                            var Temp_topics: top_picks_Info = top_picks_Info(id: -1, zirafer_id: -1, rest_id: -1, description: "")
                            let dict_1 = top_picks_data as! [String: AnyObject]
                            
                            Temp_topics.id = dict_1["_id"]                  as! Int
                            Temp_topics.zirafer_id = dict_1["zirafer_id"]   as! Int
                            Temp_topics.rest_id = dict_1["rest_id"]         as! Int
                            Temp_topics.description = dict_1["description"] as! String
                            
                            g_zirafer_Profile.top_picks.append(Temp_topics)
                        }
                    }
                    
                    
                    let reviews_dict     = responseObject["reviews"]  as! NSArray
                    if (reviews_dict != nil ) {
                        for reviews_data in reviews_dict {
                            
                            var Temp_reviews: reviews_Info = reviews_Info(id: -1, zirafer_id: -1, rest_id: -1, review: "", rating: [])
                            let dict_2 = reviews_data as! [String: AnyObject]
                            
                            Temp_reviews.id = dict_2["_id"]                  as! Int
                            Temp_reviews.zirafer_id = dict_2["zirafer_id"]   as! Int
                            Temp_reviews.rest_id = dict_2["rest_id"]         as! Int
                            Temp_reviews.review = dict_2["review"]           as! String
                            
                            let dict_3 = dict_2["rating"]                    as!  [Double]
                            for i in 0..<dict_3.count {
                                Temp_reviews.rating.append(dict_3[i])
                            }
                            
                            g_zirafer_Profile.reviews.append(Temp_reviews)
                        }
                    }

                    
                    let restaurants_dict     = responseObject["restaurants"]  as! NSArray
                    if (restaurants_dict != nil ) {
                        for restaurants_data in restaurants_dict {
                            
                            var Temp_restaurants: Zir_restaurants_Info = Zir_restaurants_Info(id: -1, name: "")
                            let dict_4 = restaurants_data as! [String: AnyObject]
                            
                            Temp_restaurants.id = dict_4["_id"]            as! Int
                            Temp_restaurants.name = dict_4["name"]   as! String
                            
                            g_zirafer_Profile.Zir_restaurants.append(Temp_restaurants)
                        }
                    }
                                        
                    
                    if g_zirafer_Profile.reviews.count > 1 {
                        g_zirafer_Profile.reviews.sort(by: { $0.rating[4] > $1.rating[4] })
                    }
                                        
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        self.SetupUI()
                    }
              
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
    
    
    @IBOutlet weak var btn_fb_image: UIButton!
    @IBOutlet weak var btn_ins_image: UIButton!
    @IBOutlet weak var btn_twi_image: UIButton!
    @IBOutlet weak var btn_sna_image: UIButton!
    
    
    func SetupUI() {
        ziraferAvatar.sd_setShowActivityIndicatorView(true)
        ziraferAvatar.sd_setIndicatorStyle(.white)
        
//        let k = randomInt(min: 1, max: 30)
//        let avatar_url = "http://35.177.9.16:8080/upload/zirafer?url=\(g_zirafer_Profile.info.id).png&temp=\(k)"
        let avatar_url = "http://35.177.9.16:8080/upload/zirafer?url=\(g_zirafer_Profile.info.id).png"
        ziraferAvatar.sd_setImage(with: URL(string: avatar_url))
        
//        Image_Overshadows.sd_setShowActivityIndicatorView(true)
//        Image_Overshadows.sd_setIndicatorStyle(.white)
//        Image_Overshadows.sd_setImage(with: URL(string: avatar_url))
        
        //Image_Overshadows.image = UIImage(named: "zirProfileHome.png")
        
        nameLabel.text = g_zirafer_Profile.info.name
        profession_Label.text = g_zirafer_Profile.info.profession
        quote_Label.text = g_zirafer_Profile.info.quote
        
        reviews_Label.text = "\(g_zirafer_Profile.reviews.count)"
        photos_Label.text = "\(g_zirafer_Profile.top_picks.count)"        
        
        
        //FaceBookLink
        if g_zirafer_Profile.info.social_link[0] == "" {
            let backImage = UIImage(named: "Facebook2x.png")?.withRenderingMode(.alwaysTemplate)
            btn_fb_image.tintColor = UIColor.lightGray
            btn_fb_image.setImage(backImage, for: .normal)
        }
        //InstagramLink
        if g_zirafer_Profile.info.social_link[2] == "" {
            let backImage = UIImage(named: "Instagram2x.png")?.withRenderingMode(.alwaysTemplate)
            btn_ins_image.tintColor = UIColor.lightGray
            btn_ins_image.setImage(backImage, for: .normal)
        }
        //TwitterLink
        if g_zirafer_Profile.info.social_link[1] == "" {
            let backImage = UIImage(named: "Twitter2x.png")?.withRenderingMode(.alwaysTemplate)
            btn_twi_image.tintColor = UIColor.lightGray
            btn_twi_image.setImage(backImage, for: .normal)
        }
        //SnapChatLink
        if g_zirafer_Profile.info.social_link[3] == "" {
            let backImage = UIImage(named: "Snapchat2x.png")?.withRenderingMode(.alwaysTemplate)
            btn_sna_image.tintColor = UIColor.lightGray
            btn_sna_image.setImage(backImage, for: .normal)
        }
        
        self.review_View.fadeIn(duration: 0.5, delay: 0.5)
        self.photo_View.fadeIn(duration: 0.5, delay: 0.5)
        self.mid_View.fadeIn(duration: 0.5, delay: 0.5)
        self.under_View.fadeIn(duration: 0.5, delay: 0.5)
    }
    
}
