//
//  SmallCategoryViewController.swift
//  Ziraf
//
//  Created by LEE on 8/16/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class SmallCategoryViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    let GlobalVar = Global()
    
    @IBOutlet weak var Title_Label: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        g_SubCategory.Nationality = HeaderList.Nationality()
//        g_SubCategory.Dietary     = HeaderList.Dietary()
//        g_SubCategory.Settings    = HeaderList.Settings()
//        g_SubCategory.Cuisines    = HeaderList.Cuisines()
//        g_SubCategory.Meals       = HeaderList.Meals()
//        g_SubCategory.HappyHour   = ["Yes", "No"]
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        switch g_MoreCategory_current_Select {
        case 0:
            Title_Label.text = g_More_Category_Array[0].name
        case 1:
            Title_Label.text = g_More_Category_Array[1].name
        case 2:
            Title_Label.text = g_More_Category_Array[2].name
        case 3:
            Title_Label.text = g_More_Category_Array[3].name
        case 4:
            Title_Label.text = g_More_Category_Array[4].name
        case 5:
            Title_Label.text = g_More_Category_Array[5].name
        default:
            break
        }
        
        if Title_Label.text != g_subTitleLabel_Temp {
            g_subTitleLabel_Temp = Title_Label.text!
            tryGet_SubCategory()
        }
        
//        if g_subTitleLabel != g_subTitleLabel_Temp {
//            g_subTitleLabel_Temp  = g_subTitleLabel
//            self.Title_Label.text = g_subTitleLabel
//            tryGet_SubCategory()
//        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag) //2 views to pop
        navigationController?.setViewControllers(viewControllers!, animated: true)
    }
    
    @IBAction func onTappedGotoProfile(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromSmallCategoryToProfile.rawValue, sender: self)
        
    }
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return g_Sub_Category_Array.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallCategoryCollectionCell", for: indexPath as IndexPath) as! SmallCategoryCollectionCell
        cell.backgroundColor =  UIColor.clear
        
        cell.subCategory_Label.layer.cornerRadius = cell.subCategory_Label.bounds.size.height / 2.0
        cell.subCategory_Label.layer.borderColor = UIColor.white.cgColor
        cell.subCategory_Label.layer.borderWidth = 1
        
        cell.subCategory_Label.text = g_Sub_Category_Array[indexPath.item].name //row
       
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        //let ScreenHeight = ScreenSize.height
        
        let newCellWidth = 170 * ScreenWidth / 375
        //let newCellHeight = 40 * ScreenHeight / 667
        
        return CGSize(width: newCellWidth, height: 40)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375  - 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375  - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        g_Category_Id = g_Sub_Category_Array[indexPath.item].id
        
        analyticsEvent(forName: "\(g_Sub_Category_Array[indexPath.item].name)")
        

        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromSmallCategoryToPick.rawValue, sender: self)
    }
    
    func analyticsEvent(forName: String!) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let analytics = appDelegate.analytics
        let eventClient = analytics?.eventClient;
        let levelEvent = eventClient?.createEvent(withEventType: "OpenCategory")
        levelEvent?.addAttribute(forName, forKey:"categoryName")
        eventClient?.record(levelEvent)
        eventClient?.submitEvents()
    }
    
    //=========================================================================================
    //
    // Post Get_SubCategory
    //
    //=========================================================================================
    func tryGet_SubCategory() {
        
        g_Sub_Category_Array.removeAll()
        self.collectionView.reloadData()
        
        let serviceObj = ServiceClass()
        
        g_subID = g_More_Category_Array[g_MoreCategory_current_Select].id
        if g_subID == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Sub_Category)\(g_subID)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let main_dict = responseObject["info"] as! NSArray
                    if (main_dict != nil ) {
                        
                        for main_data in main_dict {
                            let dict = main_data as! [String: AnyObject]
                            
                            let id   = dict["_id"]  as! Int
                            let name = dict["name"] as! String
                            let type = dict["type"] as! String
                            
                            var temp : category_Info = category_Info(id: -1, name: "", type: "")
                            temp.id = id
                            temp.name = name
                            temp.type = type
                            
                            g_Sub_Category_Array.append(temp)
                        }
                        
                        let when = DispatchTime.now() + 1
                        DispatchQueue.main.asyncAfter(deadline: when) {
                            // Your code with delay
                            //ProgressHUD.dismiss()
                            self.collectionView.reloadData()
                        }
                        
                    }
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
}



