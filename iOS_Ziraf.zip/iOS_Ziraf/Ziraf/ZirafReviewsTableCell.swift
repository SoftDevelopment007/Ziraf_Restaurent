//
//  ZirafReviewsTableCell.swift
//  Ziraf
//
//  Created by LEE on 8/25/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class ZirafReviewsTableCell: UITableViewCell {
    
    @IBOutlet weak var Round_View: UIView!
    
    @IBOutlet weak var name_Label: UITextField!
    @IBOutlet weak var Rating_Label: UITextField!
    
    @IBOutlet weak var Review_Label: UILabel!
    
    @IBOutlet weak var selectButton: UIButton!
    
}
