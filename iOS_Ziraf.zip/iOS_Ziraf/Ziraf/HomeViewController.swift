//
//  HomeViewController.swift
//  Ziraf
//
//  Created by LEE on 8/4/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
import ImageSlideshow
import CoreLocation
import GoogleMaps


class HomeViewController: UIViewController, CLLocationManagerDelegate {

    let GlobalVar = Global()
    
    @IBOutlet weak var homeImage: UIImageView!
    @IBOutlet weak var profileImage: UIImageView!
    
    //SlidShow
    @IBOutlet weak var slideshow: ImageSlideshow!
    @IBOutlet weak var slideshow_BackgroundImage: UIImageView!
    
    // get Current Location
    var locationManager:CLLocationManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        g_numerOfpage_Flag = 0
        
        //SlideShow==========================================================================
        

        
        /*
        g_localSource.removeAll()
        g_localSource.append(ImageSource(image: UIImage(named: "slide1.png")!))
        g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "image2.png")))
        g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "image3.png")))
        g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "image4.png")))
        g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "image5.png")))
        g_localSource.append(ImageSource(image: #imageLiteral(resourceName: "image6.png")))
        slideshow.setImageInputs(g_localSource)
        */
        
        if g_UrlSource.count == 0 {
            slideshow_BackgroundImage.image = UIImage(named: "slide1.png")
        } else {
            slideshow_BackgroundImage.image = UIImage(named: "")
        }
        
        for i in 0..<g_ProfileInfo.home.count {
            g_UrlSource.append(AlamofireSource(url: URL(string: g_ProfileInfo.home[i])!))
        }
        
        //slideshow.backgroundColor = UIColor.white
        slideshow.slideshowInterval = 3.5
        slideshow.pageControlPosition = PageControlPosition.underScrollView
        slideshow.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        slideshow.pageControl.pageIndicatorTintColor = UIColor.white
        slideshow.contentScaleMode = UIViewContentMode.scaleAspectFill
        
        // optional way to show activity indicator during image load (skipping the line will show no activity indicator)
        slideshow.activityIndicator = DefaultActivityIndicator(style: .white, color: nil)
        slideshow.setImageInputs(g_UrlSource)
        
        slideshow.currentPageChanged = { page in
            //print("current page:", page)
        }
        //let recognizer = UITapGestureRecognizer(target: self, action: #selector(HomeViewController.didTap))
        //slideshow.addGestureRecognizer(recognizer)
        
        
    }

   
    //SlideShow==========================================================================
    func didTap() {
        
        if g_localSource.count > 0 {
            slideshow.presentFullScreenController(from: self)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        homeImage.image = UIImage(named: "homeOn.png")
        profileImage.image = UIImage(named: "profileOff.png")
        
        if g_UrlSource.count == 0 {
            slideshow_BackgroundImage.image = UIImage(named: "slide1.png")
        } else {
            slideshow_BackgroundImage.image = UIImage(named: "")
        }
        
        slideshow.setImageInputs(g_UrlSource)
        g_numerOfpage_Flag = 0
        
        
        determineMyCurrentLocation()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func onTappedGotoProfile(_ sender: Any) {
        g_numerOfpage_Flag = 0
        self.performSegue(withIdentifier: StorySegues.FromHomeToProfile.rawValue, sender: self)
    }
    
    @IBAction func onTappedGotoExplorer(_ sender: Any) {
        g_numerOfpage_Flag = 0
        self.performSegue(withIdentifier: StorySegues.FromHomeToExplorer.rawValue, sender: self)
    }
    
    @IBAction func onTappedGtoZirafers(_ sender: Any) {
        g_numerOfpage_Flag = 0
        self.performSegue(withIdentifier: StorySegues.FromHomeToZirafers.rawValue, sender: self)
    }
    
    @IBAction func onTappedGotoQuestion(_ sender: Any) {
        if g_nearMe_firstVisit == false {
            g_numerOfpage_Flag = 0
            
            //self.performSegue(withIdentifier: StorySegues.FromHomeToQuestion.rawValue, sender: self)
            tryGet_User_Answers()
            
        } else {
            g_numerOfpage_Flag = 0
            self.performSegue(withIdentifier: StorySegues.FromHomeToNearme.rawValue, sender: self)
        }        
    }
    
    //=========================================================================================
    //
    // Post get_user_answers 64
    //
    //=========================================================================================
    func tryGet_User_Answers() {
        
        
        g_post_answers_Array.removeAll()
        
        let serviceObj = ServiceClass()
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_User_Answers)\(g_ProfileInfo.id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    //                    struct PostAnswers_info {
                    //                        var que_id:  Int
                    //                        var ans_num: [Int]
                    //                    }
                    //                    var g_post_answers_Array:         Array<PostAnswers_info>      = Array<PostAnswers_info>()
                    
                    let A_dict          = responseObject["answers"]  as! NSArray
                    if (A_dict != nil ) {
                        for A_data in A_dict {
                            
                            var Temp: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
                            
                            let B_question = A_data as! [String: AnyObject]
                            
                            let dict_question = B_question["question"] as! [String: AnyObject]
                            Temp.que_id = dict_question["id"]   as! Int
                            
                            let dict_answers = B_question["answers"] as! NSArray
                            if (dict_answers != nil ) {
                                for C_data in dict_answers {
                                    let C_dict = C_data as! [String: AnyObject]
                                    Temp.ans_num.append(C_dict["id"] as! Int)
                                }
                            }
                            
                            g_post_answers_Array.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()

                        g_nearMe_firstVisit = true
                        
                        self.performSegue(withIdentifier: StorySegues.FromHomeToQuestion.rawValue, sender: self)
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
    
    
    // Get User Current Location ==================================================================
    //
    //
    func determineMyCurrentLocation() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        locationManager.requestAlwaysAuthorization()
        
        //locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation:CLLocation = locations[0] as CLLocation
        
        // Call stopUpdatingLocation() to stop listening for location updates,
        // other wise this function will be called every time when user location changes.
        
        // manager.stopUpdatingLocation()
        
//        print("user latitude = \(userLocation.coordinate.latitude)")
//        print("user longitude = \(userLocation.coordinate.longitude)")
        
        g_User_Lat = userLocation.coordinate.latitude
        g_User_Lon = userLocation.coordinate.longitude
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        print("Error \(error)")
    }

}






