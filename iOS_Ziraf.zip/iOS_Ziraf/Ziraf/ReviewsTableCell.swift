//
//  ReviewsTableCell.swift
//  Ziraf
//
//  Created by LEE on 8/6/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class ReviewsTableCell: UITableViewCell {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var titleText: UILabel!
    @IBOutlet weak var rateText: UILabel!
    @IBOutlet weak var popularText: UILabel!
    
    
    @IBOutlet weak var select_Button: UIButton!

    @IBOutlet weak var reviewTextView: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        backgroundImage.bounds.size.height = backgroundImage.bounds.size.width
        backgroundImage.layer.cornerRadius = backgroundImage.frame.width / 2
        backgroundImage.layer.borderWidth = 1.0
        backgroundImage.layer.masksToBounds = true
        backgroundImage.layer.borderColor = UIColor.gray.cgColor
    }

//    override func prepareForReuse() {
//        imgView.image = nil
//    }
}
