//
//  SmallCategoryCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/16/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class SmallCategoryCollectionCell: UICollectionViewCell {
    @IBOutlet weak var subCategory_Label: UILabel!
}
