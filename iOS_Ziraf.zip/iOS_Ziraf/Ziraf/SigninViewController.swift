//
//  ViewController.swift
//  Ziraf
//
//  Created by LEE on 8/4/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
import Toast_Swift

import FBSDKCoreKit
import FBSDKLoginKit

import Firebase
import GoogleSignIn

import FirebaseAuth

class SigninViewController: UIViewController, GIDSignInUIDelegate, GIDSignInDelegate {

    let GlobalVar = Global()
    
    @IBOutlet weak var SignRegisterFlag_View: UIView!
    @IBOutlet weak var SigninFlag_Button: UIButton!
    @IBOutlet weak var RegisterFlag_Button: UIButton!
    
    
    @IBOutlet weak var in_Email_Text: UITextField!
    @IBOutlet weak var in_Password_Text: UITextField!
    
    @IBOutlet weak var up_username_Text: UITextField!
    @IBOutlet weak var up_Email_Text: UITextField!
    @IBOutlet weak var up_Password_Text: UITextField!
    
    @IBOutlet weak var Sign_Button: UIButton!
    @IBOutlet weak var Sign_GoogleButton: UIButton!
    @IBOutlet weak var Sign_FbButton: UIButton!
    
    @IBOutlet weak var SignIn_Parameter_View: UIView!
    @IBOutlet weak var SignUp_Parameter_View: UIView!
    
    var SigninFlag: Bool = true //"true"->"login", "false"->"signup"
    
    
    //Round Every Text for Signup
    @IBOutlet weak var Round_UserName: UIView!
    @IBOutlet weak var Round_Email: UIView!
    @IBOutlet weak var Round_Password: UIView!
    
    //Round Every Text for Signin
    @IBOutlet weak var Round_Email_Sign_In: UIView!
    @IBOutlet weak var Round_Password_Sign_In: UIView!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        g_ProfileInfo.email = ""
        g_ProfileInfo.password = ""
        
        //Signup View every text round
        Round_UserName.layer.cornerRadius   = (Round_UserName.bounds.size.height - 3) / 2.0
        Round_Email.layer.cornerRadius      = (Round_Email.bounds.size.height - 3) / 2.0
        Round_Password.layer.cornerRadius   = (Round_Password.bounds.size.height - 3) / 2.0
        
        let color = UIColor.darkGray
        up_username_Text.attributedPlaceholder = NSAttributedString(string: up_username_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        up_Email_Text.attributedPlaceholder = NSAttributedString(string: up_Email_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        up_Password_Text.attributedPlaceholder = NSAttributedString(string: up_Password_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        
        //Signin View every text round
        Round_Email_Sign_In.layer.cornerRadius      = (Round_Email_Sign_In.bounds.size.height - 3) / 2.0
        Round_Password_Sign_In.layer.cornerRadius   = (Round_Password_Sign_In.bounds.size.height - 3) / 2.0
        
        in_Email_Text.attributedPlaceholder = NSAttributedString(string: in_Email_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        in_Password_Text.attributedPlaceholder = NSAttributedString(string: in_Password_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        
        
        
        
        
        //in this page, dodo's setup
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.init(red: 170.0/255.0, green: 60.0/255.0, blue: 28.0/255.0, alpha: 1.0).withAlphaComponent(0.9)
        
        //Google
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        
        SetupUI()
        
        let bSignIned = UserDefaults.standard.bool(forKey: "SignIned")
        if (bSignIned) {
            
            g_ProfileInfo.email = UserDefaults.standard.string(forKey: "email")!
            g_ProfileInfo.password = UserDefaults.standard.string(forKey: "password")!
            g_signinType = UserDefaults.standard.string(forKey: "type")!
            
            trySign_In(email: g_ProfileInfo.email, password: g_ProfileInfo.password)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func SetupUI() {
        
        SigninFlag = true
        
        SignRegisterFlag_View.layer.cornerRadius = 2.0  //SignRegisterFlag_View.bounds.size.height / 2.0
        
        
        //SignRegisterFlag_View.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        //SignRegisterFlag_View.layer.borderWidth = 1
        
        SigninFlag_Button.backgroundColor =  UIColor(red: 130.0/255.0, green: 130.0/255.0, blue: 130.0/255.0, alpha: 0.7)
        //SigninFlag_Button.backgroundColor =  UIColor(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0)
        //SigninFlag_Button.setTitleColor(UIColor.white, for: UIControlState.normal)
        
        RegisterFlag_Button.backgroundColor =  UIColor(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 0.7)
        //RegisterFlag_Button.backgroundColor =  UIColor.clear
        //RegisterFlag_Button.setTitleColor(UIColor(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0), for: UIControlState.normal)
        
        
        //Sign_Button.layer.cornerRadius = 3.0  //SignRegisterFlag_View.bounds.size.height / 2.0
        //Sign_Button.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        //Sign_Button.layer.borderWidth = 1
        
//        Sign_Button.setTitle("Continue", for: .normal)
//        Sign_GoogleButton.setTitle("Continue with Google+", for: .normal)
//        Sign_FbButton.setTitle("Continue with Facebook", for: .normal)
        
        SignIn_Parameter_View.isHidden = false
        SignUp_Parameter_View.isHidden = true
        
//        SignIn_Parameter_View.fadeIn(duration: 0.0, delay: 0.0)
//        SignUp_Parameter_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    @IBAction func onTappedSigninFlagButton(_ sender: Any) {
        if RegisterFlag_Button.backgroundColor != UIColor(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 0.7) {
            
            SigninFlag = true
            
            SigninFlag_Button.backgroundColor =  UIColor(red: 130.0/255.0, green: 130.0/255.0, blue: 130.0/255.0, alpha: 0.7)
            //SigninFlag_Button.setTitleColor(UIColor.white, for: UIControlState.normal)
            
            RegisterFlag_Button.backgroundColor =  UIColor(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 0.7)
            //RegisterFlag_Button.backgroundColor =  UIColor.clear
            //RegisterFlag_Button.setTitleColor(UIColor(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0), for: UIControlState.normal)
            
//            Sign_Button.setTitle("Continue", for: .normal)
//            Sign_GoogleButton.setTitle("Continue with Google+", for: .normal)
//            Sign_FbButton.setTitle("Continue Facebook", for: .normal)
            
            SignIn_Parameter_View.isHidden = false
            SignUp_Parameter_View.isHidden = true
//            SignIn_Parameter_View.fadeIn(duration: 0.0, delay: 0.5, completion: {_ in
//                self.SignUp_Parameter_View.fadeOut(duration: 0.0, delay: 0.5)
//            })
            
        }
    }

    @IBAction func onTappedRegisterFlagButton(_ sender: Any) {
        if RegisterFlag_Button.backgroundColor == UIColor(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 0.7) {
            
            SigninFlag = false
            
            RegisterFlag_Button.backgroundColor =  UIColor(red: 130.0/255.0, green: 130.0/255.0, blue: 130.0/255.0, alpha: 0.7)
            //RegisterFlag_Button.backgroundColor =  UIColor(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0)
            //RegisterFlag_Button.setTitleColor(UIColor.white, for: UIControlState.normal)
            
            SigninFlag_Button.backgroundColor =  UIColor(red: 60.0/255.0, green: 60.0/255.0, blue: 60.0/255.0, alpha: 0.7)
            //SigninFlag_Button.backgroundColor =  UIColor.clear
            //SigninFlag_Button.setTitleColor(UIColor(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0), for: UIControlState.normal)
            
            
//            Sign_Button.setTitle("Continue", for: .normal)
//            Sign_GoogleButton.setTitle("Continue with Google+", for: .normal)
//            Sign_FbButton.setTitle("Continue Facebook", for: .normal)
            
            SignIn_Parameter_View.isHidden = true
            SignUp_Parameter_View.isHidden = false
//            SignIn_Parameter_View.fadeOut(duration: 0.0, delay: 0.5, completion: {_ in
//                self.SignUp_Parameter_View.fadeIn(duration: 0.0, delay: 0.5)
//            })
            
        }
    }
    

    
    func InputAllParameters() -> (Bool) {
        
        var Flag: Bool = true
        
        // Sign Up Part
        if SigninFlag == false {
            if up_Email_Text.text == "" || up_Password_Text.text == "" || up_username_Text.text == "" {
                Flag = false
            }
            if up_Email_Text.text?.isEmail == false {
                Flag = false
            }
        }
            
        // Sign In part
        else {
            if in_Email_Text.text == "" || in_Password_Text.text == "" {
                Flag = false
            }
            if in_Email_Text.text?.isEmail == false {
                Flag = false
            }
        }
        
        return Flag
    }
    
    @IBAction func onTappedForgotPassButton(_ sender: Any) {
        self.performSegue(withIdentifier: StorySegues.FromSignToForgotPass.rawValue, sender: self)
    }
    
    @IBAction func onTappedSignInMethod(_ sender: Any) {

        // Sign Up Part
        if SigninFlag == false {
            if InputAllParameters() {
                
                g_signinType = "email"
                
                g_ProfileInfo.email = up_Email_Text.text!
                g_ProfileInfo.password = up_Password_Text.text!
                g_ProfileInfo.name = up_username_Text.text!
                
                trySign_Up(email: up_Email_Text.text!, password: up_Password_Text.text!, type: "e", name: up_username_Text.text!)
            }
        }
        
        // Sign In part
        else {
            if InputAllParameters() {
                
                g_signinType = "email"
                
                g_ProfileInfo.email = in_Email_Text.text!
                g_ProfileInfo.password = in_Password_Text.text!
                
                trySign_In(email: in_Email_Text.text!, password: in_Password_Text.text!)
            }
        }
    }
    
    @IBAction func onTappedGoogleSignInMethod(_ sender: Any) {
        GIDSignIn.sharedInstance().signIn()
    }
    func signIn(_ signIn: GIDSignIn!, didDisconnectWithUser user: GIDGoogleUser!, withError error: NSError!) {
        
    }
    
    func sign( _ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let err = error {
            print("Failed to log in with Google: \(err)")
            return
        }
        else {
            //print("Successfully logged in with Goodle: \(user)")
            
            //ProgressHUD.show()
            
            guard let idToken = user.authentication.idToken else { return }
            guard let accessToken = user.authentication.accessToken else { return }
            
            let userId = user.userID
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            
            g_ProfileInfo.email = email!
            g_ProfileInfo.password = userId!
            
            /*self.up_username_Text.text = fullName! + givenName!
            self.up_Email_Text.text! = email as! String
            self.up_Password_Text.text = userId
            */
            
            /*if user.profile.hasImage
            {
                let pic = user.profile.imageURL(withDimension: 100)
                //print(pic)
                
                if let imageData: NSData = NSData(contentsOf: pic!) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }*/
            
            //=================================================================================
            //
            // Sign Up Part
            if SigninFlag == false {
                //if InputAllParameters() {
                
                    g_signinType = "google"
                    trySign_Up(email: email!, password: userId!, type: "g", name: fullName!)
                //}
            }
            // Sign In part
            else {
                //if InputAllParameters() {
                
                    g_signinType = "google"
                    trySign_In(email: email!, password: userId!)
                //} else {
                //    self.view.dodo.error("You have not signed up using this Google account, At first please Sign up using this Google account.")
                //}
            }
            //
            //
            //=================================================================================
        }
    }
    
    @IBAction func onTappedFBSignInMethod(_ sender: Any) {
        
        //ProgressHUD.show()
        FBSDKLoginManager().logIn(withReadPermissions: ["email", "public_profile"], from: self) { (result, err) in
            
            if err != nil {
                //ProgressHUD.dismiss()
                print("FB login failed: \(err)")
                return
            }
            self.showEmailAddress()
        }
    }
    
    func showEmailAddress() {
        
        let accessToken = FBSDKAccessToken.current()
        guard let accessTokenString = accessToken?.tokenString else { return }
        
        let credentials = FIRFacebookAuthProvider.credential(withAccessToken: accessTokenString)
        
        //ProgressHUD.show()
        
        FIRAuth.auth()?.signIn(with: credentials, completion: { (user, error) in
            if error != nil {
                print("Something is wrong with FB user: \(error)")
            }
            
            //print("successfully logged in with our user: \(user)")
        })
        
        //FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "email, id, name"]).start { (connection, result, err) in
        FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(normal), link"]).start { (connection, result, err) in
            
            if err != nil {
                print("failed to login: \(err)")
                return
            }
            
            /*guard let userInfo = result as? [String: Any] else { return } //handle the error
            //The url is nested 3 layers deep into the result so it's pretty messy
            if let imageURL = ((userInfo["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                if let imageData: NSData = NSData(contentsOf: NSURL(string: imageURL) as! URL) {
                    g_ProfileInfo.avatarimage = Utils.profileImage(image: UIImage(data: imageData as Data)!)
                }
            }*/
            
            
            //-----------------------------------------------------------
            let data:[String:AnyObject] = result as! [String : AnyObject]
            
            //print(data)
            
            let uid       : NSString? = data["id"]!         as? NSString
            let userName  : NSString? = data["name"]!       as? NSString
            let firstName : NSString? = data["first_name"]! as? NSString
            let lastName  : NSString? = data["last_name"]!  as? NSString
            let email     : NSString? = data["email"]!      as? NSString
           
            
            g_ProfileInfo.email = email as! String
            g_ProfileInfo.password = uid as! String

            
            /*self.up_username_Text.text = (userName as! String) + (firstName as! String)
            self.up_Email_Text.text = email as! String
            self.up_Password_Text.text = uid as! String
            */
            
            //=================================================================================
            //
            // Sign Up Part
            if self.SigninFlag == false {
                //if self.InputAllParameters() {
                
                    g_signinType = "fb"
                    self.trySign_Up(email: email! as String, password: uid! as String, type: "f", name: userName! as String)
                //}
            }
            // Sign In part
            else {
                //if self.InputAllParameters() {
                
                    g_signinType = "fb"
                    self.trySign_In(email: email! as String, password: uid! as String)
                //} else {
                //    self.view.dodo.error("You have not signed up using this FB account, At first please Sign up using this FB account.")
                //}
            }
            //
            //
            //=================================================================================
        }
    }

    //=========================================================================================
    //
    // T&C, privacy policy & cookie policy are hyperlinks to their respective link.
    //
    //=========================================================================================
    @IBAction func TermAndConditions_ButtonMethod(_ sender: Any) {
        
//        let url = URL(string: "https://www.google.com")
//        if UIApplication.shared.canOpenURL(url!) {
//            if #available(iOS 10.0, *) {
//                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
//            } else {
//                // Fallback on earlier versions
//            }
//            //If you want handle the completion block than
//            if #available(iOS 10.0, *) {
//                UIApplication.shared.open(url!, options: [:], completionHandler: { (success) in
//                    print("Open url : \(success)")
//                })
//            } else {
//                // Fallback on earlier versions
//            }
//        }
        
        let directionUrl = "https://www.zirafapp.com/terms-and-conditions-of-use"
        UIApplication.shared.openURL(URL(string: directionUrl)!)
    }
    
    @IBAction func PrivacyAndPolicy_ButtonMethod(_ sender: Any) {
        let directionUrl = "https://www.zirafapp.com/privacy-policy"
        UIApplication.shared.openURL(URL(string: directionUrl)!)
    }
    
    @IBAction func CookieAndPolicy_ButtonMethod(_ sender: Any) {
        let directionUrl = "https://www.zirafapp.com/cookie-policy"
        UIApplication.shared.openURL(URL(string: directionUrl)!)
    }
    
    
    
    //=========================================================================================
    //
    // Post Sign
    //
    //=========================================================================================
    func trySign_Up(email: String, password: String, type: String, name: String) {
        
        g_ProfileInfo.password = password
        
        g_ProfileInfo = ProfileInfo(id:     -1,
                                    email:  g_ProfileInfo.email,
                                    type:   "", // "e", "f", "g"
                                    name:   g_ProfileInfo.name,
                                    quote:  "",
                                    
                                    avatarUrl:  "",
                                    avatarimage: UIImage(named: "AnonymousImag.png")!,
                                    
                                    home: [],
                                    user_rest: [],
                                    
                                    user_que: false,
                                    
                                    password: g_ProfileInfo.password)
        
        let params: NSDictionary = [
                                    "email":    email,
                                    "password": password,
                                    "type":     type,
                                    "name":     name
                                    //,"quote":    ""
                                   ]
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.USER_SIGNUP, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    self.view.dodo.error("Please Sign in")
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.trySign_In(email: g_ProfileInfo.email, password: g_ProfileInfo.password)
                    
                    
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    let dict = responseObject?["user"] as! [String: AnyObject]
                    
                    g_ProfileInfo.id    =   dict["_id"] as! Int
                    g_ProfileInfo.email =   dict["email"]   as! String
                    g_ProfileInfo.type  =   dict["type"]    as! String
                    g_ProfileInfo.name  =   dict["name"]    as! String
                    g_ProfileInfo.quote =   dict["quote"]   as! String
                    g_ProfileInfo.avatarUrl = "http://35.177.9.16:8080/upload/profile?url=\(g_ProfileInfo.id).png"
                    
                    let home_dict = responseObject?["home"] as! NSArray
                    if (home_dict != nil ) {
                        for home_data in home_dict {
                            let dict = home_data as! [String: AnyObject]
                            let home_photo_name = dict["photo"] as! String
                            g_ProfileInfo.home.append("http://35.177.9.16:8080/upload/home?url=\(home_photo_name).png")
                        }
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                    
                    UserDefaults.standard.set(true, forKey: "SignIned")
                    UserDefaults.standard.set(g_ProfileInfo.email, forKey: "email")
                    UserDefaults.standard.set(g_ProfileInfo.password, forKey: "password")
                    
                    UserDefaults.standard.set(g_signinType, forKey: "type")
                    
                    DispatchQueue.main.async {
                        
                        //self.view.makeToast("You have been succeed for log in", duration: 2.0, position: .bottom)
                        //let when = DispatchTime.now() + 2
                        //DispatchQueue.main.asyncAfter(deadline: when) {
                        self.performSegue(withIdentifier: StorySegues.FromSignToHome.rawValue, sender: self)
                        //}
                    }
                    
                    
                    
                    /*DispatchQueue.main.async {
                        self.view.dodo.error("You have successfully signed up")
                        
                        //self.onTappedSigninFlagButton(self)
                        
                        self.trySign_In(email: g_ProfileInfo.email, password: g_ProfileInfo.password)
                    }*/
                    
                }
            }
            else {
            }
        })
    }
    
    func trySign_In(email: String, password: String) {
        
        g_ProfileInfo = ProfileInfo(id:     -1,
                                    email:  g_ProfileInfo.email,
                                    type:   "", // "e", "f", "g"
                                    name:   "",
                                    quote:  "",
                                    
                                    avatarUrl:  "",
                                    avatarimage: UIImage(named: "AnonymousImag.png")!,
                                    
                                    home: [],
                                    user_rest: [],
        
                                    user_que: false,
                                    
                                    password: g_ProfileInfo.password)
        
        let params: NSDictionary = [
            "email":    email,
            "password": password
        ]
        
        let serviceObj = ServiceClass()
        
        
//        let hud:MBProgressHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
//        hud.bezelView.color = UIColor.green // Your backgroundcolor
//        hud.bezelView.style = .solidColor // you should change the bezelview style to solid color.
        
        //ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.USER_LOGIN, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()

            
            if (responseObject != nil ) {
                
                /*if responseObject?["user_que"] != nil {
                    g_ProfileInfo.user_que = responseObject?["user_que"] as! Bool
                    if g_ProfileInfo.user_que == true {
                    } else {
                        g_nearMe_firstVisit = false
                    }
                } else {
                    g_nearMe_firstVisit = false
                }*/
                
                g_nearMe_firstVisit = false
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                    self.view.dodo.error("Please Sign up.")
                    
                } else {
                    
                    let dict = responseObject?["user"] as! [String: AnyObject]
                    
                    g_ProfileInfo.id    =   dict["_id"]     as! Int
                    g_ProfileInfo.email =   dict["email"]   as! String
                    g_ProfileInfo.type  =   dict["type"]    as! String
                    g_ProfileInfo.name  =   dict["name"]    as! String
                    g_ProfileInfo.quote =   dict["quote"]   as! String
                    
                    
                    g_ProfileInfo.password = password
                    
                    let k = randomInt(min: 1, max: 30)
                    g_ProfileInfo.avatarUrl = "http://35.177.9.16:8080/upload/profile?url=\(g_ProfileInfo.id).png&temp=\(k)"
                    //g_ProfileInfo.avatarUrl = "http://35.177.9.16:8080/upload/profile?url=\(g_ProfileInfo.id).png"
                    
                    let home_dict = responseObject?["home"] as! NSArray
                    if (home_dict != nil ) {
                        for home_data in home_dict {
                            //print(data)
                            
                            let dict = home_data as! [String: AnyObject]
                            let home_photo_name = dict["photo"] as! String
                            g_ProfileInfo.home.append("http://35.177.9.16:8080/upload/home?url=\(home_photo_name).png")
                        }
                    }
                    
                    UserDefaults.standard.set(true, forKey: "SignIned")
                    UserDefaults.standard.set(g_ProfileInfo.email, forKey: "email")
                    UserDefaults.standard.set(g_ProfileInfo.password, forKey: "password")
                    
                    UserDefaults.standard.set(g_signinType, forKey: "type")
                    
                    DispatchQueue.main.async {
                        
                        //self.view.makeToast("You have been succeed for log in", duration: 2.0, position: .bottom)
                        //let when = DispatchTime.now() + 2
                        //DispatchQueue.main.asyncAfter(deadline: when) {
                        self.performSegue(withIdentifier: StorySegues.FromSignToHome.rawValue, sender: self)
                        //}
                    }
                    
                }
            }
            else {
            }
        })
    }

    
}

