//
//  ZiraffersCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/7/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class ZiraffersCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var zirafersName: UILabel!
    
    @IBOutlet weak var zirafersRoundView: UIView!
    @IBOutlet weak var LabelRoundView: UIView!    
}
