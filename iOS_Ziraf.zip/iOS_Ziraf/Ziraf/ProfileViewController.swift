//
//  ProfileViewController.swift
//  Ziraf
//
//  Created by LEE on 8/5/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

import FBSDKCoreKit
import FBSDKLoginKit

import Firebase
import GoogleSignIn

import FirebaseAuth



class ProfileViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, WDImagePickerDelegate, UIImagePickerControllerDelegate {

    let GlobalVar = Global()
    
    var change_profile_Flag: Bool = false
    var goto_anotherPage_Flag: Bool = false //false: go to Home, true: go to Back
    
    @IBOutlet weak var avatarImage: UIImageView!
    
    @IBOutlet weak var homeImage: UIImageView!
    @IBOutlet weak var profileImage: UIImageView!

    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var username_Label: UILabel!
    @IBOutlet weak var quote_Label: UITextView!
    
    //WDImagePicker
    var imagePicker: WDImagePicker!
    var fixedImage: UIImage?

    @IBOutlet weak var none_Favorite_Label: UILabel!
    
    //Current work
    @IBOutlet weak var UpdateQuestionButton: UIButton!
    
    @IBOutlet weak var SignUp_Button: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        //quote_Label.returnKeyType = UIReturnKeyType.done
        
        // Do any additional setup after loading the view.
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        //let ScreenHeight = ScreenSize.height
        //let newWidth = Int(130 * ScreenWidth / 375)
        //let newHeight = 130 * ScreenHeight / 375
        
        avatarImage.bounds.size.height = avatarImage.bounds.size.width
        avatarImage.layer.cornerRadius = avatarImage.bounds.size.width / 2.0
        avatarImage.layer.borderColor = UIColor.white.cgColor
        avatarImage.layer.borderWidth = 2
        
//        UpdateQuestionButton.layer.cornerRadius = UpdateQuestionButton.bounds.size.height / 2.0
//        UpdateQuestionButton.layer.borderColor = UIColor.white.cgColor
//        UpdateQuestionButton.layer.borderWidth = 1
        
//        avatarImage.bounds.size.height = CGFloat(newWidth)
//        avatarImage.bounds.size.width  = CGFloat(newWidth)
//        avatarImage.layer.cornerRadius = CGFloat(newWidth) / 2.0
//        
//        avatarImage.layer.borderColor = UIColor.white.cgColor
//        avatarImage.layer.borderWidth = 2
        
        avatarImage.sd_setShowActivityIndicatorView(true)
        avatarImage.sd_setIndicatorStyle(.white)
        avatarImage.sd_setImage(with: URL(string: g_ProfileInfo.avatarUrl))
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        if g_ProfileInfo.quote == "" {
            quote_Label.text = "You didn't add quote yet."
        } else {
            quote_Label.text = g_ProfileInfo.quote
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        g_profileToquestion = false
        
        
        //avatarImage.bounds.size.height = avatarImage.bounds.size.width
        homeImage.image = UIImage(named: "homeOff.png")
        profileImage.image = UIImage(named: "profileOn.png")

        
        username_Label.text = g_ProfileInfo.name
        
        if g_ProfileInfo.quote == "" {
            quote_Label.text = "You didn't add quote yet."
        } else {
            quote_Label.text = g_ProfileInfo.quote
        }
        
        avatarImage.bounds.size.height = avatarImage.bounds.size.width
        avatarImage.layer.cornerRadius = avatarImage.bounds.size.width / 2.0
        avatarImage.layer.borderColor = UIColor.white.cgColor
        avatarImage.layer.borderWidth = 2
        
        tryGet_Favorite()
    }
    
//    func profileUpdate() {
//        if g_ProfileInfo.quote != self.quote_Label.text {
//            change_profile_Flag = true
//            
//            tryChangeProfile()
//        }
//    }
    
    @IBAction func onTappedSignUpButton(_ sender: Any) {
        goto_anotherPage_Flag = false //go to Home Page

        
        
        if g_signinType == "email" {
            
        } else if g_signinType == "fb" {
            
            let loginManager = FBSDKLoginManager()
            loginManager.logOut()
            FBSDKAccessToken.setCurrent(nil)
            
        } else if g_signinType == "google" {
            
            GIDSignIn.sharedInstance().signOut()
        }
        
        g_signinType = ""
        
        
        
        g_UrlSource.removeAll()
        g_Rest_Detail_UrlSource.removeAll()
        
        UserDefaults.standard.set(false, forKey: "SignIned")
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 2
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag)
        g_numerOfpage_Flag = 0
        navigationController?.setViewControllers(viewControllers!, animated: true)
        
//        if g_ProfileInfo.quote != self.quote_Label.text {
//            change_profile_Flag = true
//        }
//        
//        if change_profile_Flag == false {
//            
//            g_numerOfpage_Flag = g_numerOfpage_Flag + 2
//            var viewControllers = navigationController?.viewControllers
//            viewControllers?.removeLast(g_numerOfpage_Flag)
//            g_numerOfpage_Flag = 0
//            navigationController?.setViewControllers(viewControllers!, animated: true)
//            
//        } else {
//            change_profile_Flag = false
//        }
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        
        goto_anotherPage_Flag = true //go to Back Page
        
        if g_ProfileInfo.quote != self.quote_Label.text {
            change_profile_Flag = true
        }
        
        if change_profile_Flag == false {
 
            g_numerOfpage_Flag = g_numerOfpage_Flag - 1
            self.navigationController?.popViewController(animated: true)
            
        } else {
            change_profile_Flag = false
            tryChangeProfile()
        }
    }
    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        
        goto_anotherPage_Flag = false //go to Home Page
        
        if g_ProfileInfo.quote != self.quote_Label.text {
            change_profile_Flag = true
        }
        
        if change_profile_Flag == false {
            
            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
            var viewControllers = navigationController?.viewControllers
            viewControllers?.removeLast(g_numerOfpage_Flag)
            g_numerOfpage_Flag = 0
            navigationController?.setViewControllers(viewControllers!, animated: true)
            
        } else {
            change_profile_Flag = false
            tryChangeProfile()
        }
        
/*        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag)
        g_numerOfpage_Flag = 0
*/
        
        
/*
//        if g_numerOfpage_Flag == 0 {
//            viewControllers?.removeLast(1) // views to pop
//        }
//    
//        if g_numerOfpage_Flag == 1 {
//            viewControllers?.removeLast(2) // views to pop
//        }
//            
//        if g_numerOfpage_Flag == 2 {
//            viewControllers?.removeLast(3) // views to pop
//        }
//        
//        if g_numerOfpage_Flag == 3 {
//            viewControllers?.removeLast(4) // views to pop
//        }
        
//        if g_numerOfpage_Flag == 4 {
//            g_numerOfpage_Flag = 0
//            viewControllers?.removeLast(5) // views to pop
//        }
*/
 
//        navigationController?.setViewControllers(viewControllers!, animated: true)
    }

    
    @IBAction func onTappedUpdateQuestionButton(_ sender: Any) {
        
        tryGet_User_Answers()
    }
    
    @IBAction func onTappedSupportButtonMethod(_ sender: Any) {
        let directionUrl = "https://www.zirafapp.com/feedback"
        UIApplication.shared.openURL(URL(string: directionUrl)!)
    }
    
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return g_ProfileInfo.user_rest.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfileCollectionCell", for: indexPath as IndexPath) as! ProfileCollectionCell
        
        cell.backgroundColor =  UIColor.clear
        
        //Cell shape
        cell.myTitle.layer.borderColor = UIColor.darkGray.cgColor
        cell.myTitle.layer.borderWidth = 1
        
        // Use the outlet in our custom class to get a reference to the UILabel in the cell
        cell.myTitle.text = g_ProfileInfo.user_rest[indexPath.item].name
        
        
        
        
        cell.myImageView.sd_setShowActivityIndicatorView(true)
        cell.myImageView.sd_setIndicatorStyle(.white)
 
        let url = "http://35.177.9.16:8080/upload/restaurant?url=pic\(g_ProfileInfo.user_rest[indexPath.row].id)_0.png"
        cell.myImageView.sd_setImage(with: URL(string: url))
        
        
//        let ScreenSize = UIScreen.main.bounds
//        let ScreenWidth = ScreenSize.width
//        let newImg_width = ScreenWidth * 110 / 375
//        let newImg_height = (cell.myImageView.image?.size.height)! * ((cell.myImageView.image?.size.width)! / newImg_width )//
//        cell.myImageView.image = cell.myImageView.image?.resize(width: newImg_width, height: newImg_height)
        
//        cell.myImageView.layer.borderColor = UIColor.black.cgColor
//        cell.myImageView.layer.borderWidth = 1
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        
        let newCellWidth = 110 * ScreenWidth / 375
        let newCellHeight = 110 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 20 * ScreenWidth / 375 - 1;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")

        g_Pick_Restaurant_Id = g_ProfileInfo.user_rest[indexPath.item].id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromProfileToDetail.rawValue, sender: self)
    }
    
    @IBAction func onTappedAddAvatarImageButton(_ sender: Any) {
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: 375, height: 375)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Option", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Choose from Album", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        
        self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 375, height: 375))
        self.fixedImage = Utils.profileImage(image: self.fixedImage!)
        
        //g_ProfileInfo.avatarImage = fixedImage!
        if self.fixedImage == UIImage(named: "SignAddAvatar.png") {
            
        } else {
            change_profile_Flag = true
            self.avatarImage.image = self.fixedImage
            
            avatarImage.bounds.size.height = avatarImage.bounds.size.width
            avatarImage.layer.cornerRadius = avatarImage.bounds.size.width / 2.0
            avatarImage.layer.borderColor = UIColor.white.cgColor
            avatarImage.layer.borderWidth = 2
        }
        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    //=========================================================================================
    //
    // Post Change Profile
    //
    //========================================================================================= 
    func tryChangeProfile() {
        
        var params: NSDictionary
        
        let jpegCompressionQuality: CGFloat = 0.1 // Set this to whatever suits your purpose
        if let base64String = UIImageJPEGRepresentation(avatarImage.image!, jpegCompressionQuality)?.base64EncodedString() {
            // Upload base64String to your database
            params = [
                "id":    g_ProfileInfo.id,
                "name":  g_ProfileInfo.name,
                "quote": quote_Label.text,
                "file":  base64String       //file: base64-string
            ]
        } else {
            return
        }
        
        
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show("updating...")
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.CHANGE_PROFILE, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    let errorTemp = responseObject?["error"] as! String
                    self.view.makeToast(errorTemp, duration: 2.0, position: .bottom)
                } else {
                    
                    let dict = responseObject?["user"] as! [String: AnyObject]
                    g_ProfileInfo.quote =   dict["quote"]   as! String
                    
                    let k = randomInt(min: 1, max: 30)
                    g_ProfileInfo.avatarUrl = "http://35.177.9.16:8080/upload/profile?url=\(g_ProfileInfo.id).png&temp=\(k)"
                    self.view.makeToast("You have updated your profile", duration: 3.0, position: .bottom)
                    
                    if self.goto_anotherPage_Flag == true {
                        
                        //go to Back Page
                        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
                        self.navigationController?.popViewController(animated: true)
                    } else {
                        
                        //go to Home Page
                        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                        var viewControllers = self.navigationController?.viewControllers
                        viewControllers?.removeLast(g_numerOfpage_Flag)
                        g_numerOfpage_Flag = 0
                        self.navigationController?.setViewControllers(viewControllers!, animated: true)
                    }
                }
            }
            else {
            }
        })
    }
    
    //=========================================================================================
    //
    // Post get_favorite
    //
    //=========================================================================================
    func tryGet_Favorite() {
        
        g_ProfileInfo.user_rest.removeAll()
        collectionView.reloadData()
        
        //g_ProfileInfo.user_rest[indexPath.item]
        
        let serviceObj = ServiceClass()
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_Favorite)\(g_ProfileInfo.id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let info_dict          = responseObject["user_rest"]  as! NSArray
                    if (info_dict != nil ) {
                        for rest_pick_data in info_dict {
                            
                            var Temp: category_Info = category_Info(id: -1, name: "", type: "")
                            let dict = rest_pick_data as! [String: AnyObject]
                            
                            Temp.id = dict["id"]           as! Int
                            Temp.name = dict["name"]       as! String
                            Temp.type = "My_Favorite"
                            g_ProfileInfo.user_rest.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        
                        if g_ProfileInfo.user_rest.count == 0 {
                            self.none_Favorite_Label.isHidden = false
                        } else {
                            self.none_Favorite_Label.isHidden = true
                        }
                        
                        self.collectionView.reloadData()
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
    
    //=========================================================================================
    //
    // Post get_user_answers
    //
    //=========================================================================================
    func tryGet_User_Answers() {
        
        
        g_post_answers_Array.removeAll()
        
        let serviceObj = ServiceClass()
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_User_Answers)\(g_ProfileInfo.id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
//                    struct PostAnswers_info {
//                        var que_id:  Int
//                        var ans_num: [Int]
//                    }
//                    var g_post_answers_Array:         Array<PostAnswers_info>      = Array<PostAnswers_info>()
                    
                    let A_dict          = responseObject["answers"]  as! NSArray
                    if (A_dict != nil ) {
                        for A_data in A_dict {
                            
                            var Temp: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
                            
                            let B_question = A_data as! [String: AnyObject]
                            
                            let dict_question = B_question["question"] as! [String: AnyObject]
                            Temp.que_id = dict_question["id"]   as! Int

                            let dict_answers = B_question["answers"] as! NSArray
                            if (dict_answers != nil ) {
                                for C_data in dict_answers {
                                    let C_dict = C_data as! [String: AnyObject]
                                    Temp.ans_num.append(C_dict["id"] as! Int)
                                }
                            }
                            
                            g_post_answers_Array.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        
                        g_profileToquestion = true
                        
                        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                        self.performSegue(withIdentifier: StorySegues.FromProfileToQuestion.rawValue, sender: self)
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }

}


