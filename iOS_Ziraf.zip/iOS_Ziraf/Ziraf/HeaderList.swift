//
//  File.swift
//  Ziraf
//
//  Created by LEE on 8/15/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class HeaderList: NSObject {
    class func Nationality() -> Array <String> {
        return ["African",
                "American",
                "Arabic",
                "Argentinian",
                "Australian",
                "Brazilian*",
                "British",
                "Caribbean",
                "Chinese",
                "Dutch",
                "European",
                "Eastern European",
                "French",
                "German",
                "Greek",
                "Indian",
                "Indonesian",
                "Italian",
                "Irish Pubs",
                "Japanese",
                "Jamaican",
                "Korean",
                "Lebanese*",
                "Malaysian",
                "Mediterranean",
                "Mexican",
                "Middle Eastern",
                "Moroccan*",
                "Nordic",
                "Nigeria",
                "Polish",
                "Portuguese",
                "Pakistani*",
                "Persian*",
                "Peruvian",
                "Romanian",
                "Russian",
                "Spanish",
                "Sri Lankan*",
                "Thai",
                "Turkish*",
                "Vietnamese"
        ]
    }
    
    class func Dietary() -> Array <String> {
        return ["Gluten Free",
                "Healthy",
                "Kosher",
                "Organic",
                "Vegan"
        ]
    }
    
    class func Settings() -> Array <String> {
        return ["Birthdays",
                "Celebrations",
                "Diner",
                "Dining with a View",
                "Families",
                "Fun",
                "Historic",
                "Live Music",
                "Open Kitchen",
                "Outdoor Setting",
                "Private Room",
                "Quirky",
                "Romantic"
        ]
    }
    
    class func Cuisines() -> Array <String> {
        return ["Bakery",
                "Barbeque",
                "Burgers",
                "Buffet",
                "Bubble Tea",
                "Curry",
                "Coffee",
                "Chocolate",
                "Dim Sum",
                "Fusion",
                "Grill",
                "Hot Pot",
                "Ice Cream",
                "Kebab",
                "Molecular Gastronomy",
                "Pancakes",
                "Pizzeria",
                "Ramen",
                "Seafood",
                "Steakhouse",
                "Sushi",
                "Tapas"
        ]
    }
    
    class func Meals() -> Array <String> {
        return ["Afternoon Tea",
                "Contemporary / Modern European",
                "Comfort Food",
                "Fast Food",
                "Gastropub",
                "Tasting Menu",
                "Quick Fix",
                "Shisha/Hookah",
                "Supper",
                "Wine Bar"
        ]
    }
}
