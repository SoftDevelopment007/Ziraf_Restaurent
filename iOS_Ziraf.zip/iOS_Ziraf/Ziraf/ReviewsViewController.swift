//
//  ReviewsViewController.swift
//  Ziraf
//
//  Created by LEE on 8/25/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ReviewsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.backgroundColor = UIColor.clear
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }
    
    //================================================================================
    // table delegate
    //
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return g_zirafer_Profile.reviews.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ZirafReviewsTableCell") as? ZirafReviewsTableCell
        
        for i in 0..<g_zirafer_Profile.Zir_restaurants.count {
            if g_zirafer_Profile.Zir_restaurants[i].id == g_zirafer_Profile.reviews[indexPath.row].rest_id {
                cell?.name_Label.text = g_zirafer_Profile.Zir_restaurants[i].name
                continue
            }
        }
        
        cell?.Rating_Label.text = "\(g_zirafer_Profile.reviews[indexPath.row].rating[4])"
        cell?.Review_Label.text = g_zirafer_Profile.reviews[indexPath.row].review

        cell?.Round_View.layer.cornerRadius = 3.0
        cell?.Round_View.layer.borderColor = UIColor.white.cgColor
        cell?.Round_View.layer.borderWidth = 1
        
        cell?.selectButton.tag  =  indexPath.row
        
        
        return cell!
    }
    
    @IBAction func onTappedSelectButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        
        print("select Button!")
        
        g_Pick_Restaurant_Id = g_zirafer_Profile.reviews[index].rest_id
        //g_pickTable_Array[index].id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //3
        self.performSegue(withIdentifier: StorySegues.FromReviewsToDetail.rawValue, sender: self)
        
        
    }
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//    }
    
//    @IBAction func onTappedSelectButton(_ sender: Any) {
//        let index = (sender as! UIButton).tag
//        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
//        
//        print("select Button!")
//        
//        g_pickTable_Index = index
//        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //3
//        self.performSegue(withIdentifier: StorySegues.FromPickToDetail.rawValue, sender: self)
//    }
}
