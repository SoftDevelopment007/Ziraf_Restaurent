//
//  NearmeViewController.swift
//  Ziraf
//
//  Created by LEE on 8/7/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
//import MapKit
//import CoreLocation
import GoogleMaps
import CoreFoundation

struct Location {
    var title: String
    var latitude: Double
    var longitude: Double
}

class NearmeViewController: UIViewController, GMSMapViewDelegate {
    
    let GlobalVar = Global()
    
    //Mapkit Page
   // @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var zoomSlide: UISlider!
    
    @IBOutlet var btnZoomIn: UIButton!
    
    @IBOutlet var btnZoomOut: UIButton!
    
    var lat_Delta: Double = 0.1/40.0
    var long_Delta: Double = 0.1/40.0
    //zoom button 
    var currentMapZoomValue = Float()
    let MaxZoomAllowed : Float =  20.0
    let MinZoomAllowed : Float =  1.0
    
    //
    //Current Location
   
    
    // Near me Restaurant Detail
    @IBOutlet weak var NearmeRestaurant_Veiw: UIView!
    @IBOutlet weak var restPhotoImage: UIImageView!
    @IBOutlet weak var detailRound_View: UIView!
    
    @IBOutlet weak var restNameLabel: UILabel!
    @IBOutlet weak var restOpenStatusLabel: UILabel!
    
    //Change To GoogleMap
    @IBOutlet weak var viewMap: GMSMapView!
    var locationManager = CLLocationManager()
    
    var didFindMyLocation = false
    
    var locationMarker: GMSMarker!
    
    var originMarker: GMSMarker!
    
    var destinationMarker: GMSMarker!
    
    var routePolyline: GMSPolyline!
    
    var markersArray: Array<GMSMarker> = []
    
    var waypointsArray: Array<String> = []

    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currentMapZoomValue = 6.0
        zoomSlide.value = 6.0
        //NearmeRestaurant_Veiw.isHidden = true
        self.NearmeRestaurant_Veiw.fadeOut(duration: 0.0, delay: 0.0)
        detailRound_View.layer.cornerRadius = 7.5
        detailRound_View.layer.borderColor = UIColor.black.cgColor
        
        restPhotoImage.layer.cornerRadius = 7.5
        restPhotoImage.layer.borderColor = UIColor.black.cgColor
        
        
//        ProgressHUD.show("Loading...")
//        let when = DispatchTime.now() + 4 // change 2 to desired number of seconds
//        DispatchQueue.main.asyncAfter(deadline: when) {
//            // Your code with delay
//            self.AddDataMarks()
//            //createMapView_LoadData()
//            
//            ProgressHUD.dismiss()
//        }
        
        //ProgressHUD.show("Loading...")
        
        
        if g_flag_SKIP == false {
            let startTime = DispatchTime.now() + 3
            DispatchQueue.main.asyncAfter(deadline: startTime) {
                self.tryGet_Near_Rests()
                //ProgressHUD.dismiss()
            }
            
        } else {
            
            let startTime = DispatchTime.now() + 3
            DispatchQueue.main.asyncAfter(deadline: startTime) {
                
                self.tryGet_Near_Rests()
                //self.tryGet_Rests_All()
                //ProgressHUD.dismiss()
            }
        }
        
        
        
        
        //change
        
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestAlwaysAuthorization()
        //locationManager.requestWhenInUseAuthorization()
        
        
        locationManager.distanceFilter = 50
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
        self.viewMap.isMyLocationEnabled = true
        //self.viewMap.settings.myLocationButton = true
        //self.viewMap.settings.compassButton = true
        //self.viewMap.settings.zoomGestures = true
        self.viewMap.isIndoorEnabled = false
        viewMap.settings.allowScrollGesturesDuringRotateOrZoom = false
       

        let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: 48.857165, longitude: 2.354613, zoom: 8.0)
        viewMap.camera = camera
        viewMap.delegate = self

//        viewMap.addObserver(self, forKeyPath: "myLocation", options: NSKeyValueObservingOptions.new, context: nil)
//        
        zoomSlide.addTarget(self, action: #selector(NearmeViewController.sliderValueDidChange(_:)), for: .valueChanged)
        btnZoomIn.addTarget(self, action: #selector(NearmeViewController.ZoomInIntoMap(_:)), for: .touchUpInside)
        btnZoomOut.addTarget(self, action: #selector(NearmeViewController.ZoomOutIntoMap(_:)), for: .touchUpInside)

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
//        g_ProfileInfo.user_que = true
//        g_nearMe_firstVisit = true
        
        //NearmeRestaurant_Veiw.isHidden = true
        //self.NearmeRestaurant_Veiw.fadeOut(duration: 0.0, delay: 0.0)
        
        analyticsEvent(forName: "Near Me")
        

    }
    
    func analyticsEvent(forName: String!) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let analytics = appDelegate.analytics
        let eventClient = analytics?.eventClient;
        let levelEvent = eventClient?.createEvent(withEventType: "Near Me")
        levelEvent?.addAttribute(forName, forKey:"Near Me")
        eventClient?.record(levelEvent)
        eventClient?.submitEvents()
    }
    

    
    func sliderValueDidChange(_ sender:UISlider!)
    {
        print("value--\(sender.value)")

        g_Delta = Double(sender.value)
        currentMapZoomValue = sender.value
        self.viewMap.animate(toZoom: sender.value)
        /*var currentRegion = self.map.region
        currentRegion.span = MKCoordinateSpan(latitudeDelta: lat_Delta * Delta, longitudeDelta: long_Delta * Delta)
        self.map.region = currentRegion
        
        let (lat, long) = (currentRegion.center.latitude, currentRegion.center.longitude)
        */
        
//        DispatchQueue.main.async {
//            self.locationManager.startUpdatingLocation()
//        }
    }
    
    func ZoomInIntoMap(_ sender: UIButton)
    {
        currentMapZoomValue += 1.0
        if  MinZoomAllowed < currentMapZoomValue{
            
            self.viewMap.animate(toZoom: currentMapZoomValue)
            zoomSlide.value = currentMapZoomValue
        }
    }
    
    func ZoomOutIntoMap(_ sender: UIButton)
    {
        
        currentMapZoomValue -= 1.0
        if  MaxZoomAllowed > currentMapZoomValue{
            
            self.viewMap.animate(toZoom: currentMapZoomValue)
            zoomSlide.value = currentMapZoomValue
        }
    }

    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag) //2 views to pop
        navigationController?.setViewControllers(viewControllers!, animated: true)
    }
    
    @IBAction func onTappedGotoProfile(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromNearmeToProfile.rawValue, sender: self)
    }
    
    //???
    @IBAction func onTappedSetPreferencesMethod(_ sender: Any) {
        
        g_nearbyToquestion = true
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromNearmeToQuestion.rawValue, sender: self)
    }
    
    
    /*func createMapView_LoadData()
    {
        map.mapType = MKMapType.standard
        map.isZoomEnabled = true
        map.isScrollEnabled = true
        map.showsTraffic = true
        map.showsUserLocation = true
        
        //==================================================
        if g_initMapLoad_Flag == false {
            //AddDataMarks()
            
            loadData()
        } else {
            for i in 0..<g_businesses_Array.count {
                let locations = Location(title: g_businesses_Array[i].BusinessName,    latitude: g_businesses_Array[i].lat, longitude: g_businesses_Array[i].long)
                
                let annotation = MKPointAnnotation()
                annotation.title = locations.title
                annotation.coordinate = CLLocationCoordinate2D(latitude: locations.latitude, longitude: locations.longitude)
                self.map.addAnnotation(annotation)
            }
        }
        //==================================================
    }*/
    
    
    
    
    
    
    //for Test
    
    func AddDataMarks() {
        
        if NearMeRestaurant_Array.count == 0 {
            return
        }
        
        /*var locations = [
            Location(title: "Burger & Lobster  1",     latitude: 51.510865, longitude: -0.150092),
            Location(title: "Burger & Lobster  2",     latitude: 51.507865, longitude: -0.130092),
            Location(title: "Burger & Lobster  3",     latitude: 51.542865, longitude: -0.127092),
            Location(title: "Burger & Lobster  4",     latitude: 51.482865, longitude: -0.147092),
            Location(title: "Burger & Lobster  5",     latitude: 51.492865, longitude: -0.137092),
            ]*/
        
        var g_NearMe_locations_Array: Array<Location>   =  Array<Location>()
        
        for i in 0..<NearMeRestaurant_Array.count {
            var temp_location: Location = Location(title: "", latitude: 0.0, longitude: 0.0)
            temp_location.title = NearMeRestaurant_Array[i].name
            temp_location.latitude = NearMeRestaurant_Array[i].location[0]
            temp_location.longitude = NearMeRestaurant_Array[i].location[1]
            
            g_NearMe_locations_Array.append(temp_location)
        }
        
        
        
        for location in g_NearMe_locations_Array {
            
            
//            let annotation = MKPointAnnotation()
//            
//            annotation.subtitle = "Diner with set-price surf & turf menu"
//            annotation.title = location.title
            let coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
//            map.addAnnotation(annotation)
            
            let marker = GMSMarker()
            marker.position = coordinate
            marker.title = location.title
            marker.icon = UIImage(named: "mapIcon.png")
            marker.map = viewMap
            
        }
    }
    
 
    
    
 
    //============================================================================
    //
    //   Mapkit delagete
    //
    //============================================================================
    @IBAction func onTappedGotoDetail(_ sender: Any) {
//        g_numerOfpage_nearMe_Flag = true
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromNearmeToDetail.rawValue, sender: self)
    }
    
    @IBAction func onTappedOpenStatus(_ sender: Any) {
    }
    
    @IBAction func onTappedExistButton(_ sender: Any) {
        self.NearmeRestaurant_Veiw.fadeOut()
    }
    
    @IBAction func onTappedShowMap(_ sender: Any) {
        if UIApplication.shared.canOpenURL(URL(string: "comgooglemaps://")!) {
            UIApplication.shared.openURL(URL(string: "comgooglemaps://?saddr=&daddr=\(g_poiLat),\(g_poiLon)&directionsmode=driving&zoom=20")!)
        }
        else {
            
            let alert = UIAlertController(title: ("Google Maps hasn't installed in your phone. Do you want to install now?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Apple Store", style: .default, handler: { (action) in
                
                UIApplication.shared.openURL(URL(string: "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?type=Purple+Software&id=585027354")!)
                
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
    // Tap on detail ----------------------------------------------------------------------------------------------
    /*
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        g_rest_Lat = (view.annotation?.coordinate.latitude)!
        g_rest_Lon = (view.annotation?.coordinate.longitude)!
        
        g_poiLat = "\(g_rest_Lat)"
        g_poiLon = "\(g_rest_Lon)"
        
//        print(view.annotation?.title)
//        print(view.annotation?.subtitle)
        
        //restPhotoImage.image = UIImage(named: "mapRestHome.png")
        restNameLabel.text = (view.annotation?.title)!
        restOpenStatusLabel.text = "Open now"
        
        
        
        
//        let when = DispatchTime.now() + 0.5 // change 2 to desired number of seconds
//        DispatchQueue.main.asyncAfter(deadline: when) {
//            self.NearmeRestaurant_Veiw.isHidden = false
//            self.NearmeRestaurant_Veiw.fadeIn()
//        }
        
        if let search_index_1 = NearMeRestaurant_Array.index(where: {$0.location[0] == g_rest_Lat}) {
            
            if let search_index_2 = NearMeRestaurant_Array.index(where: {$0.location[1] == g_rest_Lon}) {
                
                if search_index_1 == search_index_2 {
                    g_Pick_Restaurant_Id = NearMeRestaurant_Array[search_index_1].id
                    
                    restPhotoImage.sd_setShowActivityIndicatorView(true)
                    restPhotoImage.sd_setIndicatorStyle(.white)
                    let url = "http://35.177.9.16:8080/upload/restaurant?url=\(NearMeRestaurant_Array[search_index_1].picture).png"
                    restPhotoImage.sd_setImage(with: URL(string: url))
                    
                    self.NearmeRestaurant_Veiw.fadeIn()
                }
            }
            
        }
        
    }

    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        let annotationIdentifier = "Identifier"
        var annotationView: MKAnnotationView?
        if let dequeuedAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: annotationIdentifier) {
            annotationView = dequeuedAnnotationView
            annotationView?.annotation = annotation
        }
        else {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: annotationIdentifier)
            annotationView?.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
            
            annotationView?.canShowCallout = true
        }
        
        if let annotationView = annotationView {
            
            annotationView.canShowCallout = true
            //annotationView.calloutOffset = CGPoint(x: -7, y: 7)
            
            annotationView.image = UIImage(named: "mapIcon.png")
            
            //THIS IS THE GOOD BIT
            let subtitleView = UILabel()
            subtitleView.font = subtitleView.font.withSize(12)
            subtitleView.numberOfLines = 0
            subtitleView.text = annotation.subtitle!
            annotationView.detailCalloutAccessoryView = subtitleView

        }
        return annotationView
    }
    
    
    
    //============================================================================
    //
    //   Get Location
    //
    //============================================================================

    //var LocationUpload_Flag: Bool = false
   /* change
    @nonobjc func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let userLocation:CLLocation = locations[0] as CLLocation
        let center = CLLocationCoordinate2D(latitude: (userLocation.coordinate.latitude), longitude: (userLocation.coordinate.longitude))
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: lat_Delta * g_Delta, longitudeDelta: long_Delta * g_Delta))
        map.setRegion(region, animated: true)
        locationManager.stopUpdatingLocation()

     */
        //Set Current Location in Firebase
        /*let userLocation:CLLocation = locations[0] as CLLocation
         let geofireRef = FIRDatabase.database().reference().child("locations")
         let geoFire = GeoFire(firebaseRef: geofireRef)
         if self.LocationUpload_Flag == false {
         //One time Upload Location
         geoFire!.setLocation(userLocation, forKey: self.myUID!) { (error) in
         if (error != nil) {
         debugPrint("An error occured: \(error)")
         } else {
         //print("Saved location successfully!")
         
         self.LocationUpload_Flag = true
         }
         }
         }
         g_latitude  = userLocation.coordinate.latitude
         g_longitude = userLocation.coordinate.longitude*/
    }
    
    func centerMap() {
        
        let centerLat = CENTER_MAP_LAT
        let centerLon = CENTER_MAP_LON
        var centerLatDelta = 0 as CLLocationDegrees
        var centerLonDelta = 0 as CLLocationDegrees
        
        let device = UIDevice.current.model
        let index = device.index(device.startIndex, offsetBy: 4)
        let deviceType = device.substring(to: index)
        
        if deviceType != "iPad" {
            
            let screenSize: CGRect = UIScreen.main.bounds
            let deviceWidth = screenSize.width
            
            switch deviceWidth {
            case 320: // 4/5
                centerLatDelta = SCREEN_320_LAT
                centerLonDelta = SCREEN_320_LON
            case 375: // 6
                centerLatDelta = SCREEN_375_LAT
                centerLonDelta = SCREEN_375_LON
            case 414: // 6+
                centerLatDelta = SCREEN_414_LAT
                centerLonDelta = SCREEN_414_LON
            default:
                centerLatDelta = SCREEN_375_LAT
                centerLonDelta = SCREEN_375_LON
            }
            
        } else {
            centerLatDelta = SCREEN_IPAD_LAT
            centerLonDelta = SCREEN_IPAD_LON
        }
        
        let zoom = MKCoordinateSpan(latitudeDelta: centerLatDelta, longitudeDelta: centerLonDelta)
        let centerPoint = CLLocationCoordinate2D(latitude: centerLat , longitude: centerLon)
        let region: MKCoordinateRegion = MKCoordinateRegion(center: centerPoint, span: zoom)
        map.setRegion(region, animated: true)
    }


////////////////

    */




    //=========================================================================================
    //
    // Post get_near_rests  :  allAnswers --> 64
    //
    //=========================================================================================
    func tryGet_Near_Rests() {
        
        NearMeRestaurant_Array.removeAll()
        
        let serviceObj = ServiceClass()
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_NearMeRestaurant)\(g_ProfileInfo.id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    let info_dict          = responseObject["info"]  as! NSArray
                    if (info_dict != nil ) {
                        for info_data in info_dict {
                            
                            var Temp: NearMeRestaurant_Info = NearMeRestaurant_Info(id: -1, name: "", location: [], picture: "")
                            let dict = info_data as! [String: AnyObject]
                            
                            Temp.id = dict["id"]           as! Int
                            Temp.name = dict["name"]       as! String
                            Temp.picture = dict["picture"] as! String
                            
                            let temp_location_array   = dict["location"]  as! [Double]
                            for i in 0..<temp_location_array.count {
                                Temp.location.append(temp_location_array[i])
                            }

                            NearMeRestaurant_Array.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        
                        //================================================================================
                        
                        if NearMeRestaurant_Array.count == 0 {
                            self.tryGet_Rests_All()
                            
                        } else {
                            
                            self.AddDataMarks()
                        }
                        
                        //================================================================================
                        
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
    
    //=========================================================================================
    //
    // Post Get_Rests_All
    //
    //=========================================================================================
    func tryGet_Rests_All() {
        
        NearMeRestaurant_Array.removeAll()
        
        let serviceObj = ServiceClass()
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_Rests_All)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    let info_dict          = responseObject["info"]  as! NSArray
                    if (info_dict != nil ) {
                        for info_data in info_dict {
                            
                            var Temp: NearMeRestaurant_Info = NearMeRestaurant_Info(id: -1, name: "", location: [], picture: "")
                            let dict = info_data as! [String: AnyObject]
                            
                            Temp.id = dict["_id"]           as! Int
                            Temp.name = dict["name"]       as! String
                            
                            
                            let temp_pictures_array   = dict["pictures"]  as! [String]
                            
                            if temp_pictures_array.count > 0 {
                                Temp.picture = temp_pictures_array[0]
                            } else {
                                Temp.picture = ""
                            }
                            
                            
                            let temp_location_array   = dict["location"]  as! [Double]
                            for i in 0..<temp_location_array.count {
                                Temp.location.append(temp_location_array[i])
                            }
                            
                            NearMeRestaurant_Array.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        
                        //================================================================================
                        
                        self.AddDataMarks()
                        //================================================================================
                        
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
}

extension NearmeViewController: CLLocationManagerDelegate {
    
    // Handle incoming location events.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location: CLLocation = locations.last!
        print("Location: \(location)")
        
        let camera = GMSCameraPosition.camera(withLatitude: (location.coordinate.latitude), longitude: (location.coordinate.longitude), zoom: 8.0)
        
        self.viewMap?.animate(to: camera)
        
        //Finally stop updating location otherwise it will come again and again in this delegate
        self.locationManager.stopUpdatingLocation()    }
    
    // Handle authorization for the location manager.
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
//        switch status {
//        case .restricted:
//            print("Location access was restricted.")
//        case .denied:
//            print("User denied access to location.")
//            // Display the map using the default location.
//            viewMap.isHidden = false
//        case .notDetermined:
//            print("Location status not determined.")
//        case .authorizedAlways: fallthrough
//        case .authorizedWhenInUse:
//            print("Location status is OK.")
//        }
    }
    
    // Handle location manager errors.
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationManager.stopUpdatingLocation()
        print("Error: \(error)")
    }

    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        
        
        return false
 
    }

    func mapView(_ mapView: GMSMapView, didTapInfoWindowOf marker: GMSMarker) {
        g_rest_Lat = marker.position.latitude
        g_rest_Lon = marker.position.longitude
        //g_rest_Lat = (view.annotation?.coordinate.latitude)!
        //  g_rest_Lon = (view.annotation?.coordinate.longitude)!
        
        g_poiLat = "\(g_rest_Lat)"
        g_poiLon = "\(g_rest_Lon)"
        
        //        print(view.annotation?.title)
        //        print(view.annotation?.subtitle)
        
        //restPhotoImage.image = UIImage(named: "mapRestHome.png")
        //restNameLabel.text = (view.annotation?.title)!
        restNameLabel.text = marker.title
        restOpenStatusLabel.text = "Open now"
        
        
        
        
        //        let when = DispatchTime.now() + 0.5 // change 2 to desired number of seconds
        //        DispatchQueue.main.asyncAfter(deadline: when) {
        //            self.NearmeRestaurant_Veiw.isHidden = false
        //            self.NearmeRestaurant_Veiw.fadeIn()
        //        }
        
        if let search_index_1 = NearMeRestaurant_Array.index(where: {$0.location[0] == g_rest_Lat}) {
            
            if let search_index_2 = NearMeRestaurant_Array.index(where: {$0.location[1] == g_rest_Lon}) {
                
                if search_index_1 == search_index_2 {
                    g_Pick_Restaurant_Id = NearMeRestaurant_Array[search_index_1].id
                    
                    restPhotoImage.sd_setShowActivityIndicatorView(true)
                    restPhotoImage.sd_setIndicatorStyle(.white)
                    let url = "http://35.177.9.16:8080/upload/restaurant?url=\(NearMeRestaurant_Array[search_index_1].picture).png"
                    restPhotoImage.sd_setImage(with: URL(string: url))
                    
                    
//                    let ScreenSize = UIScreen.main.bounds
//                    let ScreenWidth = ScreenSize.width
//                    let newImg_width = ScreenWidth * 350 / 375
//                    let newImg_height = (restPhotoImage.image?.size.height)! * ((restPhotoImage.image?.size.width)! / newImg_width)//                        
//                    restPhotoImage.image = restPhotoImage.image?.resize(width: newImg_width, height: newImg_height)
                    
                    
                    
                    self.NearmeRestaurant_Veiw.fadeIn()
                }
            }
            
        }

    }

}
   
