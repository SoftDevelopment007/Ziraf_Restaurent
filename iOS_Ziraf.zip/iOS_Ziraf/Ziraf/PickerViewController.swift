//
//  PickerViewController.swift
//  Ziraf
//
//  Created by LEE on 8/5/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class PickerViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    let GlobalVar = Global()
    @IBOutlet weak var tableView: UITableView!
    
    //Set Table Refresh Control
    //var refreshControl = UIRefreshControl()
    
    @IBOutlet weak var view_alert: UIView!
    @IBOutlet weak var alert_Label: UILabel!
    
    @IBOutlet weak var view_Guide: UIView!
    
    @IBOutlet weak var animationView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view_alert.layer.cornerRadius = 4.0
        view_alert.fadeOut(duration: 0.0, delay: 0.0)
        
        
        view_Guide.fadeOut(duration: 0.0, delay: 0.0)
        
        
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        
/*        //Set Table Refresh Control
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "")
        
        
        refreshControl.addTarget(self, action: #selector(self.handleRefresh(sender:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        
        //========================================
        handleRefresh(sender: self)
        //========================================
*/
        tableView.backgroundColor = UIColor.clear
        
        tryGet_Restaurant()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    /*func handleRefresh(sender:AnyObject) {
        
        g_pickTable_Array.removeAll()
        tableView.reloadData()
        
        let temp1: Table_Info = Table_Info(
            title:           "Poeken",
            rate:            9.0,
            popular:         16,
            BackgroundImage: UIImage(named: "Poeken.png")!,
            
            reviews:        ""
        )
        g_pickTable_Array.append(temp1)
        
        let temp2: Table_Info = Table_Info(
            title:           "Padella",
            rate:            13.0,
            popular:         13,
            BackgroundImage: UIImage(named: "Padella food 2.png")!,
            
            reviews:        ""
        )
        g_pickTable_Array.append(temp2)
        
        let temp3: Table_Info = Table_Info(
            title:           "Kintan",
            rate:            10.0,
            popular:         14,
            BackgroundImage: UIImage(named: "Kintan.png")!,
            
            reviews:        ""
        )
        g_pickTable_Array.append(temp3)
        
        let temp4: Table_Info = Table_Info(
            title:           "Cream gants hill",
            rate:            10.0,
            popular:         15,
            BackgroundImage: UIImage(named: "Cream gants hill.png")!,
            
            reviews:        ""
        )
        g_pickTable_Array.append(temp4)
        
        
        refreshControl.endRefreshing()
        tableView.reloadData()
    }*/
    

    
    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }

    //================================================================================
    // table delegate
    //
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return g_pickTable_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PickTableCell") as? PickTableCell
        
        cell?.titleText.text = g_pickTable_Array[indexPath.row].name
        
        
        if g_pickTable_Array[indexPath.row].rating != -1.0 {
            cell?.rateText.text = "\(g_pickTable_Array[indexPath.row].rating)"
        } else {
            cell?.rateText.text = "--"
        }
        
        cell?.popularText.text = "/10"
        
        //Sd image
        cell?.backgroundImage.sd_setShowActivityIndicatorView(true)
        cell?.backgroundImage.sd_setIndicatorStyle(.white)
        
        let url = "http://35.177.9.16:8080/upload/restaurant?url=\(g_pickTable_Array[indexPath.row].picture).png"
        cell?.backgroundImage.sd_setImage(with: URL(string: url))
        
        cell?.selectButton.tag  =  indexPath.row
        return cell!
        
    }
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//    }
    
    @IBAction func onTappedSelectButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        
        print("select Button!")
        
        g_Pick_Restaurant_Id = g_pickTable_Array[index].id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //3
        self.performSegue(withIdentifier: StorySegues.FromPickToDetail.rawValue, sender: self)
    }
    
    @IBAction func onTappedGotoHomeButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        var viewControllers = navigationController?.viewControllers
        viewControllers?.removeLast(g_numerOfpage_Flag) //3 views to pop
        navigationController?.setViewControllers(viewControllers!, animated: true)
    }
    
    @IBAction func onTappedGotoProfileButton(_ sender: Any) {        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //2
        self.performSegue(withIdentifier: StorySegues.FromPickToProfile.rawValue, sender: self)
    }
    
    var Flag_Animation: Bool = false
    @IBAction func onTappedSortButton(_ sender: Any) {
        
        if Flag_Animation == false {
            Flag_Animation = true
            
            UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                //Frame Option 1:
                self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y + 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                
            },completion: { finish in
            })
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            
        } else {
            Flag_Animation = false
            
            view_Guide.fadeOut(duration: 0.1, delay: 0.1)
            
            UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                //Frame Option 1:
                self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y - 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                
            },completion: { finish in
            })
        }
        
        
        
        
        
        
        
        
        
        /*g_sort_int = g_sort_int + 1
        
        if g_sort_int == 1 {
            
            if Flag_Animation == false {
                Flag_Animation = true
                
                UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    //Frame Option 1:
                    self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y + 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                    
                },completion: { finish in
                })
            }
        }
        
        
        switch g_sort_int {
        case 1:
            g_pickTable_Array.sort(by: { $0.rating > $1.rating })
            
            alert_Label.text = "Rating: highest to lowest"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        case 2:
            g_pickTable_Array.sort(by: { $0.rating < $1.rating })
            
            alert_Label.text = "Rating: lowest to highest"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
           
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        case 3:
            g_pickTable_Array.sort(by: { $0.id > $1.id })
            
            alert_Label.text = "Added: latest to oldest"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        case 4:
            g_pickTable_Array.sort(by: { $0.id < $1.id })
            
            alert_Label.text = "Added: oldest to latest"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        case 5:
            g_pickTable_Array.sort(by: { $0.name > $1.name })
            
            alert_Label.text = "A to Z"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        case 6:
            g_sort_int = 0
            g_pickTable_Array.sort(by: { $0.name < $1.name })
            
            alert_Label.text = "Z to A"
            view_alert.fadeIn(duration: 0.3, delay: 0.3)
            
            
            view_Guide.fadeIn(duration: 0.1, delay: 0.1)
            
            let when = DispatchTime.now() + 2
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.view_alert.fadeOut(duration: 0.2, delay: 0.2)
            }
            
        default:
            break
        }
        
        tableView.reloadData()
        */
    }
    
    
    @IBAction func onTappedHideAlertButton(_ sender: Any) {
        view_alert.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    
    
    
    @IBOutlet weak var HighLow_1: UILabel!
    @IBOutlet weak var LowHigh_2: UILabel!
    @IBOutlet weak var HighLow_3: UILabel!
    @IBOutlet weak var Newest_4: UILabel!
    @IBOutlet weak var AZ_5: UILabel!
    @IBOutlet weak var ZA_6: UILabel!
    
    func set_grayColor() {
        HighLow_1.textColor = UIColor.lightGray
        LowHigh_2.textColor = UIColor.lightGray
        HighLow_3.textColor = UIColor.lightGray
        Newest_4.textColor = UIColor.lightGray
        AZ_5.textColor = UIColor.lightGray
        ZA_6.textColor = UIColor.lightGray
    }
    
    
    
    
    
    //var local_Price_Flag: Bool = false
    @IBAction func onTappedPriceSortButton(_ sender: Any) {
        
        /*if local_Price_Flag == false {
            local_Price_Flag = true
            g_pickTable_Array.sort(by: { $0.price > $1.price })
            
        } else {
            local_Price_Flag = false
            g_pickTable_Array.sort(by: { $0.price < $1.price })
        }*/
        
        set_grayColor()
        HighLow_1.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.price > $1.price })
        tableView.reloadData()
    }
    
    @IBAction func onTappedLowHigh_2(_ sender: Any) {
        set_grayColor()
        LowHigh_2.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.price < $1.price })
        tableView.reloadData()
    }
    
    
    //var local_Rating_Flag: Bool = false
    @IBAction func onTappedRatingSortButton(_ sender: Any) {
        
        /*if local_Rating_Flag == false {
            local_Rating_Flag = true
            g_pickTable_Array.sort(by: { $0.rating > $1.rating })
            
        } else {
            local_Rating_Flag = false
            g_pickTable_Array.sort(by: { $0.rating < $1.rating })
        }*/
        
        set_grayColor()
        HighLow_3.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.rating > $1.rating })
        tableView.reloadData()
    }
    
    //var local_Date_Flag: Bool = false
    @IBAction func onTappedDateSortButton(_ sender: Any) {
        
        /*if local_Date_Flag == false {
            local_Date_Flag = true
            g_pickTable_Array.sort(by: { $0.id > $1.id })
            
        } else {
            local_Date_Flag = false
            g_pickTable_Array.sort(by: { $0.id < $1.id })
        }*/
        
        set_grayColor()
        Newest_4.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.id > $1.id })
        tableView.reloadData()
    }
    
    //var local_AZ_Flag: Bool = false
    @IBAction func onTappedAZSortButton(_ sender: Any) {
        
        /*if local_AZ_Flag == false {
            local_AZ_Flag = true
            g_pickTable_Array.sort(by: { $0.name > $1.name })
            
        } else {
            local_AZ_Flag = false
            g_pickTable_Array.sort(by: { $0.name < $1.name })
        }*/
        
        set_grayColor()
        AZ_5.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.name < $1.name })
        tableView.reloadData()
    }
    

    @IBAction func onTappedAZSortButton_6(_ sender: Any) {
        set_grayColor()
        ZA_6.textColor = UIColor.white
        g_pickTable_Array.sort(by: { $0.name > $1.name })
        tableView.reloadData()
    }
    
    @IBAction func onTappedHideGuideButton(_ sender: Any) {
        
        if Flag_Animation == true {
            //g_sort_int = 0
            Flag_Animation = false
            
            view_Guide.fadeOut(duration: 0.1, delay: 0.1)
            
            UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                //Frame Option 1:
                self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y - 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                
            },completion: { finish in
            })
        }

    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        //Bottom Refresh
        /*if scrollView == tableView{
                
            if Flag_Animation == true {
                g_sort_int = 0
                Flag_Animation = false
                
                self.view_Guide.fadeOut(duration: 0.1, delay: 0.1)
                
                UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    //Frame Option 1:
                    self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y - 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                    
                },completion: { finish in
                })
            }
        }*/
        if scrollView == tableView{
            
            if Flag_Animation == true {
                Flag_Animation = false
                
                self.view_Guide.fadeOut(duration: 0.1, delay: 0.1)
                
                UIView.animate(withDuration: 0.1, delay: 0.1, options: UIViewAnimationOptions.curveEaseIn, animations: {
                    //Frame Option 1:
                    self.animationView.frame = CGRect(x: self.animationView.frame.origin.x, y: self.animationView.frame.origin.y - 120, width: self.animationView.frame.width, height: self.animationView.frame.height)
                    
                },completion: { finish in
                })
            }
        }
    }
    
    
    //=========================================================================================
    //
    // Post get_restaurant
    //
    //=========================================================================================
    func tryGet_Restaurant() {
        
        g_pickTable_Array.removeAll()
        tableView.reloadData()
        
        let serviceObj = ServiceClass()
        if g_Category_Id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_Rests)\(g_Category_Id)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let info_dict          = responseObject["info"]  as! NSArray
                    if (info_dict != nil ) {
                        for rest_pick_data in info_dict {
                            
                            var Temp: Pick_Restaurant_Info = Pick_Restaurant_Info(id: -1, name: "", rating: 0.0, price: 0, picture: "")
                            let dict = rest_pick_data as! [String: AnyObject]
                            
                            Temp.id = dict["id"]           as! Int
                            Temp.name = dict["name"]       as! String
                            Temp.rating = dict["rating"]   as! Double
                            Temp.picture = dict["picture"] as! String
                            
                            Temp.price = dict["price"]     as! Int

                            g_pickTable_Array.append(Temp)
                        }
                    }
                    
                    let when = DispatchTime.now() + 1
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        self.tableView.reloadData()
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
}
