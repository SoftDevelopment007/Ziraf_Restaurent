import UIKit

class ProfileCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myTitle: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
}
