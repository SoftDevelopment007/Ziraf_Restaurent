//
//  PhotosCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/25/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class PhotosCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var description_Label: UILabel!
    
    @IBOutlet weak var Round_View: UIView!    
}
