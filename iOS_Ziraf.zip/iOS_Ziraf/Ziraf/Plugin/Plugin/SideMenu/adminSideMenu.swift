//
//  adminSideMenu.swift
//  Hoopoe
//
//  Created by PRK on 2/25/17.
//  Copyright © 2017 rising. All rights reserved.
//

import Foundation
import UIKit

protocol SideMenuViewDelegate {
    
    func onHelpButton(sender:AnyObject) -> Void
    func onShareButton(sender: AnyObject) -> Void
    func onSendButton(sender: AnyObject) -> Void
    func onSyncButton(sender:AnyObject) -> Void
    func onSettingsButton(sender: AnyObject) -> Void
    func onLogoutButton(sender: AnyObject) -> Void
    func onGoogleSignButton(sender: AnyObject) -> Void
}

class adminSideMenu: UIViewController{
    

    var delegate: SideMenuViewDelegate?
    
    
    @IBOutlet weak var imageAvatarMask: UIImageView!
    @IBOutlet weak var buttonAvatar: UIButton!    
    @IBOutlet weak var textUserName: UILabel!
    
    @IBOutlet weak var ButtonGoogleSign: UIButton!
    
    @IBOutlet weak var ButtonHelp: UIButton!
    @IBOutlet weak var ButtonShare: UIButton!
    @IBOutlet weak var ButtonSend: UIButton!
    @IBOutlet weak var ButtonSync: UIButton!
    @IBOutlet weak var ButtonSettings: UIButton!
    @IBOutlet weak var ButtonLogout: UIButton!
    
    @IBOutlet weak var ImageHelp: UIImageView!
    @IBOutlet weak var ImageShare: UIImageView!
    @IBOutlet weak var ImageSend: UIImageView!
    @IBOutlet weak var ImageSync: UIImageView!
    @IBOutlet weak var ImageSettings: UIImageView!
    @IBOutlet weak var ImageLogout: UIImageView!
    
    
    @IBOutlet weak var lastView: UIView!
    @IBOutlet weak var lastAccount: UILabel!
    
    
    func RedAnimation() {
        
        switch g_MenuCurSel {
        case 0:
            
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)
            
        case 1:
            ButtonHelp.setTitleColor(.red, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)
            
        case 2:
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.red, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)

        case 3:
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.red, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)
            
        case 4:
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.red, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)
            
        case 5:
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.red, for: .normal)
            ButtonLogout.setTitleColor(.black, for: .normal)
            
        case 6:
            ButtonHelp.setTitleColor(.black, for: .normal)
            ButtonShare.setTitleColor(.black, for: .normal)
            ButtonSend.setTitleColor(.black, for: .normal)
            ButtonSync.setTitleColor(.black, for: .normal)
            ButtonSettings.setTitleColor(.black, for: .normal)
            ButtonLogout.setTitleColor(.red, for: .normal)
            
        default: break
            
        }
    }
    
    func nopSignShowInit() {
        
        if g_LoginFlag == true {
            self.ButtonGoogleSign.isHidden = true
            
            self.imageAvatarMask.isHidden = false
            self.buttonAvatar.isHidden = false
            self.textUserName.isHidden = false
            
            self.lastView.isHidden = false
            self.lastAccount.isHidden = false
            self.ImageLogout.isHidden = false
            self.ButtonLogout.isHidden = false
        } else {
            self.ButtonGoogleSign.isHidden = false
            
            self.imageAvatarMask.isHidden = true
            self.buttonAvatar.isHidden = true
            self.textUserName.isHidden = true
            
            self.lastView.isHidden = true
            self.lastAccount.isHidden = true
            self.ImageLogout.isHidden = true
            self.ButtonLogout.isHidden = true
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //g_MenuCurSel = 0
        
        RedAnimation()
        nopSignShowInit()
    }
    
    //DownLoad Cover and User Image
    override func viewWillAppear(_ animated: Bool) {
        
        textUserName.text = g_ProfileInfo.name
        self.buttonAvatar.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        textUserName.text = g_ProfileInfo.name
        self.buttonAvatar.setBackgroundImage(g_ProfileInfo.avatarimage, for: .normal)
    }
    
    @IBAction func onTappedHelpButton(_ sender: Any) {
        g_MenuCurSel = 1
        RedAnimation()
        
        self.delegate?.onHelpButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }

    @IBAction func onTappedShareButton(_ sender: Any) {
        g_MenuCurSel = 2
        RedAnimation()
        
        dismiss(animated: true, completion: nil)
        self.delegate?.onShareButton(sender: sender as AnyObject)
        
    }
    
    @IBAction func onTappedSendButton(_ sender: Any) {
        g_MenuCurSel = 3
        RedAnimation()
        
        self.delegate?.onSendButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onTappedSyncButton(_ sender: Any) {
        g_MenuCurSel = 4
        RedAnimation()
        
        self.delegate?.onSyncButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onTappedSettingsButton(_ sender: Any) {
        g_MenuCurSel = 5
        RedAnimation()
        
        self.delegate?.onSettingsButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onTappedLogoutButton(_ sender: Any) {
        g_MenuCurSel = 0
        RedAnimation()
        
        self.delegate?.onLogoutButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onTappedGoogleSignButton(_ sender: Any) {
        g_MenuCurSel = 0
        RedAnimation()
        
        self.delegate?.onGoogleSignButton(sender: sender as AnyObject)
        dismiss(animated: true, completion: nil)
    }
}
