//
//  Global.swift
//  Amoureuse
//
//  Created by LEE on 3/30/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit
import ImageSlideshow

var g_signinType: String = ""

//This is necessary for slideshow in homePage
var g_localSource  = Array<ImageSource>()
var g_UrlSource    = Array<AlamofireSource>()   //Home Page Slide
var g_Rest_Detail_UrlSource  = Array<AlamofireSource>()   //Rest Detail Page Slide

//for pop remove
var g_numerOfpage_Flag: Int = 0
//var g_numerOfpage_nearMe_Flag: Bool = false

// for Profile To Question Flag
var g_profileToquestion: Bool = false



var g_nearbyToquestion: Bool = false

var g_flag_SKIP: Bool = false

//for Sort in pick page
var g_sort_int: Int = 0

// forgot email
var g_forgot_email: String = ""


// Frist Vist ------------------------------------------------------------------
var g_FristVist_Main: Bool = true
var g_FristVist_More: Bool = true

// Sign Page -------------------------------------------------------------------
struct ProfileInfo{
    
    var id:             Int
    
    var email:          String
    var type:           String
    var name:           String
    var quote:          String
    
    var avatarUrl:      String
    var avatarimage:    UIImage
    
    var home:           Array<String> = Array<String>()
    var user_rest:      Array<category_Info> = Array<category_Info>()
    
    var user_que:       Bool
    
    var password:       String
}
var g_ProfileInfo: ProfileInfo = ProfileInfo(
    
    id:     -1,
    email:  "",
    type:   "", // "e", "f", "g"
    name:   "",
    quote:  "",
    
    avatarUrl:  "",
    avatarimage: UIImage(named: "AnonymousImag.png")!,
    
    home: [],
    user_rest: [],
    
    user_que: false,
    
    password: ""
)


//for profile favorite ---------------------------------------------------------
struct category_Info{
    var id:                  Int
    var name:                String
    var type:                String
}

//Exprorer Page Category
var g_Main_Category_Array:   Array<category_Info>   = Array<category_Info>()
var g_More_Category_Array:   Array<category_Info>   = Array<category_Info>()
var g_Category_Id : Int = -1


//var g_subTitleLabel:         String = ""
var g_subTitleLabel_Temp:    String = "Temp"
var g_subID:                 Int    = -1
var g_Sub_Category_Array:    Array<category_Info>   = Array<category_Info>()

// More
var g_MoreCategory_current_Select: Int = -1

//Questions --------------------------------------------------------------------
struct question_Info{
    var id:                  Int
    var question:            String
}
struct answers_Info{
    var id:                  Int
    var name:                String
}
struct Nearme_Info{
    var questions:           question_Info
    var answers            = [answers_Info]()
}
var g_Nearme_Array:         Array<Nearme_Info>      = Array<Nearme_Info>()

//Answers ----------------------------------------------------------------------
struct PostAnswers_info {
    var que_id:  Int
    var ans_num: [Int]
}
var g_post_answers_Array:         Array<PostAnswers_info>      = Array<PostAnswers_info>()


//Zirafers page's collection data ----------------------------------------------
struct zirafer_Info {
    var id: Int
    var name: String
    var profession: String
    var quote: String
    var social_link = [String]()
}
var g_zirafers_Array:        Array<zirafer_Info>   = Array<zirafer_Info>()
var g_zirafersTozirProfile_selectedIndexNumber_Id: Int = -1

// Zirafer profile photo and review --------------------------------------------
struct top_picks_Info {
    var id: Int
    var zirafer_id: Int
    var rest_id: Int
    var description: String
}
struct reviews_Info {
    var id: Int
    var zirafer_id: Int
    var rest_id: Int
    var review: String
    var rating = [Double]()
}
struct restaurants_Info {
    var id: Int
    var name: String
    var rating: Double
    var price: Int
    var phone_number: String
    
    var category_id = [Int]()
    var opening_hours = [String]()
    var pictures = [String]()
    var location = [0.0, 0.0]
    
    var street_name: String
}
struct Zir_restaurants_Info {
    var id: Int
    var name: String
}

struct zirafer_Profile_Info {
    var info: zirafer_Info
    var top_picks = [top_picks_Info]()
    var reviews = [reviews_Info]()
    var restaurants = [restaurants_Info]()
    
    var Zir_restaurants = [Zir_restaurants_Info]()
}

var g_Init_Temp: zirafer_Info = zirafer_Info(id: -1, name: "", profession: "", quote: "", social_link: [])
var g_zirafer_Profile: zirafer_Profile_Info = zirafer_Profile_Info(info: g_Init_Temp, top_picks: [], reviews:[], restaurants: [], Zir_restaurants: [])

// Pick Restaurant Page ---------------------------------------------------------------
struct Pick_Restaurant_Info{
    var id:      Int
    var name:    String
    var rating:  Double
    
    var price:   Int
    
    var picture: String
}

//for Picker table
var g_pickTable_Array:     Array<Pick_Restaurant_Info>   =  Array<Pick_Restaurant_Info>()
var g_Pick_Restaurant_Id:  Int = -1 //g_pickTable_Index

//for picker sort
var g_pickSort_Flag:       Int = 0

// Restaurant Detail Page -------------------------------------------------------------
struct Detail_Restaurant_Info{
    var favorite: Bool
    var top_picks = [top_picks_Info]()
    var info: restaurants_Info
    var reviews = [reviews_Info]()
    var zirafers = [Zir_restaurants_Info]()
}
var g_Rest_Init_Temp: restaurants_Info = restaurants_Info(id: -1, name: "", rating: 0.0, price: 0, phone_number: "", category_id: [], opening_hours: [], pictures: [], location: [], street_name: "")
var g_Detail_Restaurant: Detail_Restaurant_Info = Detail_Restaurant_Info(favorite: false, top_picks: [], info: g_Rest_Init_Temp, reviews: [], zirafers: [])


// Near Me Restaurant -----------------------------------------------------------------
struct NearMeRestaurant_Info{
    var id: Int
    var name: String
    var location = [0.0, 0.0]
    var picture: String
}
var NearMeRestaurant_Array:     Array<NearMeRestaurant_Info>   =  Array<NearMeRestaurant_Info>()



//Near me Page
var g_nearMe_firstVisit: Bool = false

//MapKit
var g_Delta: Double = 40.0

// to ride parameters
var g_poiLat = "51.520865"
var g_poiLon = "-0.130092"

var g_rest_Lat: Double = 51.520865
var g_rest_Lon: Double = -0.130092

var g_User_Lat: Double = 0.0
var g_User_Lon: Double = 0.0

























