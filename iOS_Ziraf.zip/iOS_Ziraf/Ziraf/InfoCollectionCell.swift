//
//  InfoCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/6/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class InfoCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myImageView: UIImageView!
}
