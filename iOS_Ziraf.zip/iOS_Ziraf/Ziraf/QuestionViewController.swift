//
//  QuestioViewController.swift
//  Ziraf
//
//  Created by LEE on 8/7/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
import KSTokenView

class QuestionViewController: UIViewController {
  
    let GlobalVar = Global()
    
    @IBOutlet weak var animation_View: TPKeyboardAvoidingScrollView!
    @IBOutlet weak var UpdateButton: UIButton!
    @IBOutlet weak var SkipButton: UIButton!
    
    
    var myKeys  = Array<String>()
    var key_Cnt: Int = 0
    
    var tableCell_CurSel_Cnt: Int = -1
   
    
    @IBOutlet weak var view1: KSTokenView!
    //let names_Header = HeaderList.Nationality()
    
    @IBOutlet weak var view2: KSTokenView!
    //let names_Dietary = HeaderList.Dietary()
    
    @IBOutlet weak var view3: KSTokenView!
    //let names_Settings = HeaderList.Settings()
    
    @IBOutlet weak var view4: KSTokenView!
    //let names_Cuisines = HeaderList.Cuisines()
    
    @IBOutlet weak var view5: KSTokenView!
    //let Meals_Cuisines = HeaderList.Meals()
    
    
    @IBOutlet weak var Yes_Button: UIButton!
    @IBOutlet weak var No_Button: UIButton!
    
   //var Select_YesNo_Flag: Int = 0  //0: inti, 1: yes, 2: no
    
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button2: UIButton!
    @IBOutlet weak var Button3: UIButton!
    @IBOutlet weak var Button4: UIButton!
    @IBOutlet weak var Button5: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Yes_Button.layer.borderWidth = 1
        Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        No_Button.layer.borderWidth = 1
        No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        
        
        //in this page, dodo's setup
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.init(red: 170.0/255.0, green: 60.0/255.0, blue: 28.0/255.0, alpha: 1.0).withAlphaComponent(0.9)
        
        Button1.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.7)
        Button2.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.7)
        Button3.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.7)
        Button4.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.7)
        Button5.backgroundColor = UIColor(red: 170.0/255.0, green: 170.0/255.0, blue: 170.0/255.0, alpha: 0.7)
        
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        Yes_Button.layer.cornerRadius = Yes_Button.bounds.size.height / 2.0
        Yes_Button.layer.borderColor = UIColor.white.cgColor
        Yes_Button.layer.borderWidth = 1
        
        No_Button.layer.cornerRadius = Yes_Button.bounds.size.height / 2.0
        No_Button.layer.borderColor = UIColor.white.cgColor
        No_Button.layer.borderWidth = 1
        
        Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        
        animation_View.fadeOut(duration: 0.0, delay: 0.0)
        SetupUI()
        
        
//        for i in 0...10 {
//            let token: KSToken = KSToken(title: "aa")
//            view1.addToken(token)
//        }
//        
//        for i in 0..<(view1.tokens()?.count)! {
//            let a: String = "\(view1.tokens()![i])"
//            print(a)
//        }
        
//        self.hideKeyboardWhenTappedAround()
        
        
 //????       g_post_answers_Array.removeAll()
        
        tryGet_Questions()

        UpdateButton.layer.cornerRadius = 5.0
        UpdateButton.layer.borderColor = UIColor.white.cgColor
        UpdateButton.layer.borderWidth = 1
        UpdateButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        
        SkipButton.layer.cornerRadius = 5.0
        SkipButton.layer.borderColor = UIColor.white.cgColor
        SkipButton.layer.borderWidth = 1
        SkipButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
    }
    
    //============================================================================
    func Init_Show_Answers() {
    
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 0
        
        
        for i in 0..<g_post_answers_Array.count {
            
            for j in 0..<g_post_answers_Array[i].ans_num.count {
                
                switch g_post_answers_Array[i].que_id {
                    
                case g_Nearme_Array[0].questions.id:
                    
                    //g_Nearme_Array[0].answers.sort(by: { $0.name > $1.name })
                    
                    if let search_index = g_Nearme_Array[0].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        let token: KSToken = KSToken(title: g_Nearme_Array[0].answers[search_index].name )
                        view1.addToken(token)
                    }
                    
                case g_Nearme_Array[1].questions.id:
                    
                    //g_Nearme_Array[1].answers.sort(by: { $0.name > $1.name })
                    
                    if let search_index = g_Nearme_Array[1].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        let token: KSToken = KSToken(title: g_Nearme_Array[1].answers[search_index].name )
                        view2.addToken(token)
                    }
                    
                case g_Nearme_Array[2].questions.id:
                    
                    //g_Nearme_Array[2].answers.sort(by: { $0.name > $1.name })
                    
                    if let search_index = g_Nearme_Array[2].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        let token: KSToken = KSToken(title: g_Nearme_Array[2].answers[search_index].name )
                        view3.addToken(token)
                    }
                    
                case g_Nearme_Array[3].questions.id:
                    
                    //g_Nearme_Array[3].answers.sort(by: { $0.name > $1.name })
                    
                    if let search_index = g_Nearme_Array[3].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        let token: KSToken = KSToken(title: g_Nearme_Array[3].answers[search_index].name )
                        view4.addToken(token)
                    }
                    
                    
                case g_Nearme_Array[4].questions.id:
                    
                    //g_Nearme_Array[4].answers.sort(by: { $0.name > $1.name })
                    
                    if let search_index = g_Nearme_Array[4].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        
                        let token: KSToken = KSToken(title: g_Nearme_Array[4].answers[search_index].name )
                        view5.addToken(token)
                    }
                    
                    
                case g_Nearme_Array[5].questions.id:
                    
                    if let search_index = g_Nearme_Array[5].answers.index(where: {$0.id == g_post_answers_Array[i].ans_num[j]}) {
                        
                        if g_Nearme_Array[5].answers[search_index].name == "Yes" {
                            
                            //Select_YesNo_Flag = 1
                            
                            Yes_Button.layer.borderWidth = 2
                            //No_Button.layer.borderWidth = 1
                            Yes_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                            //No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                        }
                        if g_Nearme_Array[5].answers[search_index].name == "No" {
                            
                            //Select_YesNo_Flag = 2
                            
                            No_Button.layer.borderWidth = 2
                            //Yes_Button.layer.borderWidth = 1
                            No_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                            //Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                        }
                    }
                    
                    
                default:
                    break
                }
                
            }
        }
        
        
//        switch key_Cnt {
//        case 1:
//            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
//            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
//            
//            for i in 0..<(view1.tokens()?.count)! {
//                let a: String = "\(view1.tokens()![i])"
//                print(a)
//                
//                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
//                    
//                    New_Keys.append(a)
//                    
//                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[i].id)
//                }
//            }
//            
//            g_post_answers_Array.append(temp_Post)
//            
//            view1.deleteAllTokens()
//            for i in 0..<New_Keys.count {
//                let token: KSToken = KSToken(title: New_Keys[i])
//                view1.addToken(token)
//            }
//        }
    }
    
    @IBAction func onTapped_Button1(_ sender: Any) {
        Button1.isHidden = true
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 1
        
    }
    
    @IBAction func onTapped_Button2(_ sender: Any) {
        Button1.isHidden = false
        Button2.isHidden = true
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 2
    }
    
    @IBAction func onTapped_Button3(_ sender: Any) {
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = true
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 3
    }
    
    @IBAction func onTapped_Button4(_ sender: Any) {
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = true
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 4
    }
    
    @IBAction func onTapped_Button5(_ sender: Any) {
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = true
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 5
    }
    
    @IBAction func onTappedYesButton(_ sender: Any) {
        //Select_YesNo_Flag = 1
        
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 0
        
        
        if let search_index = g_post_answers_Array.index(where: {$0.que_id == g_Nearme_Array[5].questions.id}) {
            
            if let indeax_No = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[1].id) { //135
                
                if let indeax_Yes = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[0].id) { //134
                    
                    Yes_Button.layer.borderWidth = 1
                    Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_Yes)
                    
                } else {
                    
                    No_Button.layer.borderWidth = 1
                    No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_No)
                    
                    Yes_Button.layer.borderWidth = 2
                    Yes_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                    g_post_answers_Array[search_index].ans_num.append(g_Nearme_Array[5].answers[0].id)                  //134
                    
                }
                
                
                
            } else {
                if let indeax_Yes = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[0].id) { //134
                    Yes_Button.layer.borderWidth = 1
                    Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_Yes)
                    
                } else {
                    Yes_Button.layer.borderWidth = 2
                    Yes_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                    g_post_answers_Array[search_index].ans_num.append(g_Nearme_Array[5].answers[0].id)                  //134
                }
            }
            
        } else {
            
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[5].questions.id
            temp_Post.ans_num.append(g_Nearme_Array[5].answers[0].id)                                               //134
            g_post_answers_Array.append(temp_Post)
            
            Yes_Button.layer.borderWidth = 2
            Yes_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
            
        }
    }
    
    @IBAction func onTappedNoButton(_ sender: Any) {
        //Select_YesNo_Flag = 2
      
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        view1.endEditing(true)
        view2.endEditing(true)
        view3.endEditing(true)
        view4.endEditing(true)
        view5.endEditing(true)
        
        key_Cnt = 0
        
        if let search_index = g_post_answers_Array.index(where: {$0.que_id == g_Nearme_Array[5].questions.id}) {
            
            if let indeax_Yes = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[0].id) { //134
                
                if let indeax_No = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[1].id) { //135
                    
                    No_Button.layer.borderWidth = 1
                    No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_No)
                    
                } else {
                    No_Button.layer.borderWidth = 2
                    No_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                    g_post_answers_Array[search_index].ans_num.append(g_Nearme_Array[5].answers[1].id)                  //135
                    
                    Yes_Button.layer.borderWidth = 1
                    Yes_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_Yes)
                }
                
            } else {
                
                if let indeax_No = g_post_answers_Array[search_index].ans_num.index(of: g_Nearme_Array[5].answers[1].id) { //135
                    No_Button.layer.borderWidth = 1
                    No_Button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
                    g_post_answers_Array[search_index].ans_num.remove(at: indeax_No)
                    
                } else {
                    No_Button.layer.borderWidth = 2
                    No_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
                    g_post_answers_Array[search_index].ans_num.append(g_Nearme_Array[5].answers[1].id)                  //135
                }
                
            }
            
            
            
        } else {
            
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[5].questions.id
            temp_Post.ans_num.append(g_Nearme_Array[5].answers[1].id)                                               //135
            g_post_answers_Array.append(temp_Post)
            
            No_Button.layer.borderWidth = 2
            No_Button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        }
    }
    
    
    func SetupUI() {
        view1.direction = .horizontal
        view1.style = .rounded
        view1.paddingX = 10.0
        view1.marginX = 2.0
        
        view2.direction = .horizontal
        view2.style = .rounded
        view2.paddingX = 10.0
        view2.marginX = 2.0
        
        view3.direction = .horizontal
        view3.style = .rounded
        view3.paddingX = 10.0
        view3.marginX = 2.0
        
        view4.direction = .horizontal
        view4.style = .rounded
        view4.paddingX = 10.0
        view4.marginX = 2.0
        
        view5.direction = .horizontal
        view5.style = .rounded
        view5.paddingX = 10.0
        view5.marginX = 2.0
        
        
        /// default is 10.0. Horizontal padding of title
        //tokenView.paddingX = 10.0
        
        /// default is 2.0. Vertical padding of title
        //tokenView.paddingY = 2.0
        
        /// default is 5.0. Horizontal margin between tokens
        //tokenView.marginX = 5.0
        
        /// default is 5.0. Vertical margin between tokens
        //tokenView.marginY = 5.0
        
        view1.delegate = self
        view1.promptText = "Nationalities: "
        view1.placeholder = "Type to search"
        view1.descriptionText = " Nationalities"
        view1.maxTokenLimit = -1
        view1.searchResultHeight = 150
        view1.minimumCharactersToSearch = 0 // Show all results without without typing anything
        //view1.style = .squared
        view1.returnKeyType(type: .done)
        view1.font = UIFont.systemFont(ofSize: 14)
        view1.placeholderColor = UIColor.black
        
        view2.delegate = self
        view2.promptText = "Cuisines: "
        view2.placeholder = "Type to search"
        view2.descriptionText = " Cuisines"
        view2.maxTokenLimit = -1
        view2.searchResultHeight = 150
        view2.minimumCharactersToSearch = 0 // Show all results without without typing anything
        //view2.style = .squared
        view2.returnKeyType(type: .done)
        view2.font = UIFont.systemFont(ofSize: 14)
        view2.placeholderColor = UIColor.black
        
        view3.delegate = self
        view3.promptText = "Meals: "
        view3.placeholder = "Type to search"
        view3.descriptionText = " Meals"
        view3.maxTokenLimit = -1
        view3.searchResultHeight = 150
        view3.minimumCharactersToSearch = 0 // Show all results without without typing anything
        //view3.style = .squared
        view3.returnKeyType(type: .done)
        view3.font = UIFont.systemFont(ofSize: 14)
        view3.placeholderColor = UIColor.black
        
        view4.delegate = self
        view4.promptText = "Settings: "
        view4.placeholder = "Type to search"
        view4.descriptionText = " Settings"
        view4.maxTokenLimit = -1
        view4.searchResultHeight = 150
        view4.minimumCharactersToSearch = 0 // Show all results without without typing anything
        //view4.style = .squared
        view4.returnKeyType(type: .done)
        view4.font = UIFont.systemFont(ofSize: 14)
        view4.placeholderColor = UIColor.black
        
        view5.delegate = self
        view5.promptText = "Dietary Restrictions: "
        view5.placeholder = "Type to search"
        view5.descriptionText = " Dietaries"
        view5.maxTokenLimit = -1
        view5.searchResultHeight = 150
        view5.minimumCharactersToSearch = 0 // Show all results without without typing anything
        //view5.style = .squared
        view5.returnKeyType(type: .done)
        view5.font = UIFont.systemFont(ofSize: 14)
        view5.placeholderColor = UIColor.black
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        
        if g_profileToquestion == false {
            
            if g_nearbyToquestion == false {
                g_numerOfpage_Flag = g_numerOfpage_Flag - 1
                self.navigationController?.popViewController(animated: true)
                
            } else {
                
                g_nearbyToquestion = false
                
                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                var viewControllers = navigationController?.viewControllers
                viewControllers?.removeLast(g_numerOfpage_Flag)
                g_numerOfpage_Flag = 0
                navigationController?.setViewControllers(viewControllers!, animated: true)
            }
            
        } else {
            
            g_profileToquestion = false
            
            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
            var viewControllers = navigationController?.viewControllers
            viewControllers?.removeLast(g_numerOfpage_Flag)
            g_numerOfpage_Flag = 0
            navigationController?.setViewControllers(viewControllers!, animated: true)
        }
    
    }
    
    @IBAction func onTappedGotoProfile(_ sender: Any) {
//        if g_profileToquestion == false {
//            
//            if g_nearbyToquestion == false {
//                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
//                self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
//                
//            } else {
//                
//                g_nearbyToquestion = false
//                g_profileToquestion = false
//                
//                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
//                self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
//                
//            }
//            
//        } else {
        
        currentButton = "Profile"
            tryChange_User_Answer()

//        }
        
    }
    
    //=========================================================================================
    //
    // Post Get_Questions
    //
    //=========================================================================================
    func tryGet_Questions() {
        
        g_Nearme_Array.removeAll()
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Questions, fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let main_dict = responseObject["info"] as! NSArray
                    if (main_dict != nil ) {
                        
                        for main_data in main_dict {
                            let info_dict = main_data as! [String: AnyObject]
                            
                            var temp1: question_Info = question_Info(id: -1, question: "")
                            var temp2: Array<answers_Info> = Array<answers_Info>()
                            var temp3: answers_Info = answers_Info(id: -1, name: "")
                            var question_temp: Nearme_Info = Nearme_Info(questions: temp1, answers: temp2)
                            
                            
                            let question_dict = info_dict["question"] as! [String: AnyObject]
                                let id       = question_dict["id"]      as! Int
                                let question = question_dict["question"] as! String
                            
                                temp1.id = id
                                temp1.question = question
                            
                            let answers_dict = info_dict["answers"] as! NSArray
                            for answer_data in answers_dict {
                                let answer_dict = answer_data as! [String: AnyObject]
                                
                                let id       = answer_dict["id"]      as! Int
                                let name     = answer_dict["name"]    as! String
                                
                                temp3.id  = id
                                temp3.name = name
                                temp2.append(temp3)
                            }
                            
                            question_temp.questions = temp1
                            question_temp.answers   = temp2
                            g_Nearme_Array.append(question_temp)
                        }
                        
                        let when = DispatchTime.now() + 1
                        DispatchQueue.main.asyncAfter(deadline: when) {
                            // Your code with delay
                            //ProgressHUD.dismiss()
                            
                            //===================================================
                            //if g_ProfileInfo.user_que == true {
                                self.Init_Show_Answers()
                            //}
                            //===================================================
                            self.animation_View.fadeIn(duration: 0.5, delay: 0.5)
                        }
                    }
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }

    /*func isPostArray() -> Bool {
        
        var flag: Bool = false
        
        for i in 0..<g_post_answers_Array.count {
            if g_post_answers_Array[i].ans_num.count > 0 {
                flag = true
            }
        }
        
        return flag
    }*/
    
    //=========================================================================================
    //
    // Post change_user_answer
    //
    //=========================================================================================
    func tryChange_User_Answer() {
        
//        if isPostArray() == false {
//            g_nearMe_firstVisit = false
//            g_ProfileInfo.user_que = false
//            
//            self.view.dodo.error("You didn't select answers yet.")
//            return
//        }
        
        var g_myParams: [NSDictionary] = []

        var temp_1: NSDictionary = [:]
        for i in 0..<g_post_answers_Array.count {
            
            temp_1 = ["que_id": g_post_answers_Array[i].que_id, "ans_num": g_post_answers_Array[i].ans_num]
            g_myParams.append(temp_1)
        }

        print(g_myParams)
        
        let params: NSDictionary = [
            "id":       g_ProfileInfo.id,
            "answers":  g_myParams
        ]
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Change_User_Answer, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    
                    
//                    if g_profileToquestion == false {
                        
                        if g_nearbyToquestion == false {
                            
                            if self.currentButton == "Profile" {
                                
                                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                                self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
                                
                            } else {
                                
                                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                                //self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
                                self.performSegue(withIdentifier: StorySegues.FromQuestionToNearme.rawValue, sender: self)
                            }

                            
                            
                        } else {
                            
                            g_nearbyToquestion = false
                            g_profileToquestion = false
                            
                            
                            if self.currentButton == "Done" {
                                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                                self.performSegue(withIdentifier: StorySegues.FromQuestionToNearme.rawValue, sender: self)
                                
                            } else if self.currentButton == "Profile" {
                                g_numerOfpage_Flag = g_numerOfpage_Flag + 1
                                self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
                            }
                            
//                            g_numerOfpage_Flag = g_numerOfpage_Flag - 1
//                            //self.performSegue(withIdentifier: StorySegues.FromQuestionToProfile.rawValue, sender: self)
//                            self.navigationController?.popViewController(animated: true)
                            
                        }
                        
//                    }
//                    else {
//                        
//                        if g_profileToquestion == false {
//                            
//                            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
//                            self.performSegue(withIdentifier: StorySegues.FromQuestionToNearme.rawValue, sender: self)
//                            
//                        } else {
//                            
//                            g_profileToquestion = false
//                            
//                            g_numerOfpage_Flag = g_numerOfpage_Flag - 1
//                            self.navigationController?.popViewController(animated: true)
//                        }
//                        
//                    }
                    
                    
                    
                    
//                    if g_profileToquestion == false {
//                        
//                        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
//                        self.performSegue(withIdentifier: StorySegues.FromQuestionToNearme.rawValue, sender: self)
//                        
//                    } else {
//                        
//                        g_profileToquestion = false
//                        
//                        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
//                        self.navigationController?.popViewController(animated: true)
//                    }
                    
                    
                    
                }
            }
            else {
            }
        })
    }

    
    

    var currentButton: String = ""
    
    @IBAction func onTappedUpdateAnswerButton(_ sender: Any) {
        
//        if isPostArray() {
//            g_flag_SKIP = false
//            
//        } else {
//            g_flag_SKIP = true
//        }
        
        UpdateButton.layer.cornerRadius = 5 //UpdateButton.bounds.size.height / 2.0
        UpdateButton.layer.borderColor = UIColor.white.cgColor
        UpdateButton.layer.borderWidth = 2
        UpdateButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        g_ProfileInfo.user_que = true
       
        print(g_post_answers_Array)

        currentButton = "Done"
        tryChange_User_Answer()
        
    }
    
    @IBAction func onTappedSkipButtonMethod(_ sender: Any) {
        
//        if isPostArray() {
//            g_flag_SKIP = false
//        } else {
//            g_flag_SKIP = true
//        }
        
        SkipButton.layer.cornerRadius = 5 //UpdateButton.bounds.size.height / 2.0
        SkipButton.layer.borderColor = UIColor.white.cgColor
        SkipButton.layer.borderWidth = 2
        SkipButton.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        
        g_ProfileInfo.user_que = true
        
//        if g_profileToquestion == false {
            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
            self.performSegue(withIdentifier: StorySegues.FromQuestionToNearme.rawValue, sender: self)
            
//        } else {
//            
//            g_profileToquestion = false
//            
//            g_numerOfpage_Flag = g_numerOfpage_Flag - 1
//            self.navigationController?.popViewController(animated: true)
//        }
    }
}

extension QuestionViewController: KSTokenViewDelegate {
    
    func tokenViewDidBeginEditing(_ tokenView: KSTokenView) {
        
    }
    
    func tokenViewDidEndEditing(_ tokenView: KSTokenView) {
        Button1.isHidden = false
        Button2.isHidden = false
        Button3.isHidden = false
        Button4.isHidden = false
        Button5.isHidden = false
        
        print(key_Cnt)
        
        print(g_post_answers_Array)
        if let search_index = g_post_answers_Array.index(where: {$0.que_id == g_Nearme_Array[key_Cnt - 1].questions.id}) {
            g_post_answers_Array.remove(at: search_index)
            print(g_post_answers_Array)
        }
        
        var New_Keys  = Array<String>()
        
        switch key_Cnt {
        case 1:
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
            
            for i in 0..<(view1.tokens()?.count)! {
                let a: String = "\(view1.tokens()![i])"
                print(a)
                
                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
                    
                    New_Keys.append(a)
                    
                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[search_index].id)
                }
            }
            
            g_post_answers_Array.append(temp_Post)
            
            view1.deleteAllTokens()
            for i in 0..<New_Keys.count {
                let token: KSToken = KSToken(title: New_Keys[i])
                view1.addToken(token)
            }
            
        case 2:
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
            
            for i in 0..<(view2.tokens()?.count)! {
                let a: String = "\(view2.tokens()![i])"
                print(a)
                
                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
                    
                    New_Keys.append(a)
                    
                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[search_index].id)
                }
            }
            
            g_post_answers_Array.append(temp_Post)
            
            view2.deleteAllTokens()
            for i in 0..<New_Keys.count {
                let token: KSToken = KSToken(title: New_Keys[i])
                view2.addToken(token)
            }

        case 3:
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
            
            for i in 0..<(view3.tokens()?.count)! {
                let a: String = "\(view3.tokens()![i])"
                print(a)
                
                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
                    
                    New_Keys.append(a)
                    
                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[search_index].id)
                }
            }
            
            g_post_answers_Array.append(temp_Post)
            
            view3.deleteAllTokens()
            for i in 0..<New_Keys.count {
                let token: KSToken = KSToken(title: New_Keys[i])
                view3.addToken(token)
            }

        case 4:
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
            
            for i in 0..<(view4.tokens()?.count)! {
                let a: String = "\(view4.tokens()![i])"
                print(a)
                
                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
                    
                    New_Keys.append(a)
                    
                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[search_index].id)
                }
            }
            
            g_post_answers_Array.append(temp_Post)
            
            view4.deleteAllTokens()
            for i in 0..<New_Keys.count {
                let token: KSToken = KSToken(title: New_Keys[i])
                view4.addToken(token)
            }

        case 5:
            var temp_Post: PostAnswers_info = PostAnswers_info(que_id: -1, ans_num: [])
            temp_Post.que_id = g_Nearme_Array[key_Cnt - 1].questions.id
            
            for i in 0..<(view5.tokens()?.count)! {
                let a: String = "\(view5.tokens()![i])"
                print(a)
                
                if let search_index = g_Nearme_Array[key_Cnt - 1].answers.index(where: {$0.name == a}) {
                    
                    New_Keys.append(a)
                    
                    temp_Post.ans_num.append(g_Nearme_Array[key_Cnt - 1].answers[search_index].id)
                }
            }
            
            g_post_answers_Array.append(temp_Post)
            
            view5.deleteAllTokens()
            for i in 0..<New_Keys.count {
                let token: KSToken = KSToken(title: New_Keys[i])
                view5.addToken(token)
            }
            
        default: break
        }
        
        key_Cnt = 0
        print(g_post_answers_Array)
        
    }
    
    func tokenView(_ tokenView: KSTokenView, performSearchWithString string: String, completion: ((_ results: Array<AnyObject>) -> Void)?) {
        
//        switch key_Cnt {
//        case 1:
//            myKeys = HeaderList.Nationality()
//            
//        case 2:
//            myKeys = HeaderList.Cuisines()
//            
//        case 3:
//            myKeys = HeaderList.Meals()
//            
//        case 4:
//            myKeys = HeaderList.Settings()
//            
//        case 5:
//            myKeys = HeaderList.Dietary()
//            
//        default: break
//        }
        
        myKeys.removeAll()
        for i in 0..<g_Nearme_Array[key_Cnt - 1].answers.count {
            myKeys.append(g_Nearme_Array[key_Cnt - 1].answers[i].name)
        }
        
//        myKeys.removeAll()
//        for i in 0..<g_Nearme_Array[tableCell_CurSel_Cnt].answers.count {
//            myKeys.append(g_Nearme_Array[tableCell_CurSel_Cnt].answers[i].name)
//        }
        
        
        if (string.characters.isEmpty){
            completion!(myKeys as Array<AnyObject>)
            return
        }
        
        var data: Array<String> = []
        for value: String in myKeys {
            
            if value.lowercased().range(of: string.lowercased()) != nil {
                data.append(value)
            }
        }
        completion!(data as Array<AnyObject>)
    }
    
    func tokenView(_ tokenView: KSTokenView, displayTitleForObject object: AnyObject) -> String {
        return object as! String
    }
    
    func tokenView(_ tokenView: KSTokenView, shouldAddToken token: KSToken) -> Bool {
        
        if token.title == "f" {
            return false
        }
        return true
    }
}

