//
//  ForgotPassViewController.swift
//  Ziraf
//
//  Created by LEE on 8/21/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ForgotPassViewController: UIViewController {

    let GlobalVar = Global()
    
    @IBOutlet weak var Send_Button: UIButton!
    @IBOutlet weak var Email_Text: UITextField!
    
    var verificationCode: Int = -917
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Send_Button.layer.cornerRadius = Send_Button.bounds.size.height / 2.0
        Send_Button.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        Send_Button.layer.borderWidth = 1
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    let kInfoTitle = "Verify"
    let kSubtitle = "Please go to your email and get code."
    
    @IBAction func onTappedSendButton(_ sender: Any) {
        
        if (Email_Text.text?.isEmail)! {
            
            g_forgot_email = Email_Text.text!
            tryGet_ForgotPassword(completion: {
            })
            
            
            let appearance = SCLAlertView.SCLAppearance(showCloseButton: true)
            let alert = SCLAlertView(appearance: appearance)
            let txt = alert.addTextField("Enter your received code")
            txt.keyboardType = .numberPad
            
            _ = alert.addButton("Send") {
                print("Text value: \(txt.text ?? "NA")")
                
                if txt.text == "\(self.verificationCode)" {
                    
                    print(self.verificationCode)
                    
                    self.performSegue(withIdentifier: StorySegues.FromForgotPassToResetPass.rawValue, sender: self)
                } else {
                    let refreshAlert = UIAlertController(title: "Error", message: "Your code doesn't march with server code.", preferredStyle: UIAlertControllerStyle.alert)
                    refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                        print("Handle Ok logic here")
                    }))
                    refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                        print("Handle Cancel Logic here")
                    }))
                    self.present(refreshAlert, animated: true, completion: nil)
                }
            }
            _ = alert.showEdit(self.kInfoTitle, subTitle:self.kSubtitle)            
            
        }
    }

    //=========================================================================================
    //
    // Post get_user_answers
    //
    //=========================================================================================
    
    
    func tryGet_ForgotPassword(completion: @escaping () -> ()) {
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_ForgotPassword)\(Email_Text.text!)", fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {

                    self.verificationCode = responseObject["code"] as! Int

                    print(self.verificationCode)
                    //ProgressHUD.dismiss()
                    
                    completion()
                    
                    
                    
//                    let when = DispatchTime.now() + 1
//                    DispatchQueue.main.asyncAfter(deadline: when) {
//                        // Your code with delay
//                        ProgressHUD.dismiss()
//                        
//                        g_profileToquestion = true
//                        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
//                        self.performSegue(withIdentifier: StorySegues.FromProfileToQuestion.rawValue, sender: self)
//                    }

                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
}
