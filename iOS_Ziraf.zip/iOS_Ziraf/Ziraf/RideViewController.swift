//
//  RideViewController.swift
//  Ziraf
//
//  Created by Unjang on 9/8/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
import GoogleMaps
//GMSMapViewDelegate
import Alamofire

import Foundation
import CoreLocation
import GoogleMaps

class SessionManager {
    let GOOGLE_DIRECTIONS_API_KEY = "AIzaSyC-HL1HinUAXO0uQ-qr3c_fextmoHOggPA"
    
    func requestDirections(from start: CLLocationCoordinate2D, to end: CLLocationCoordinate2D, completionHandler: @escaping ((_ response: GMSPath?, _ error: Error?) -> Void)) {
        
        guard let url = URL(string: "https://maps.googleapis.com/maps/api/directions/json?origin=Toronto&destination=Montreal&key=AIzaSyC-HL1HinUAXO0uQ-qr3c_fextmoHOggPA")
        
        //guard let url = URL(string: "https://maps.googleapis.com/maps/api/directions/json?origin=\(start.latitude),\(start.longitude)&destination=\(end.latitude),\(end.longitude)&key=\(GOOGLE_DIRECTIONS_API_KEY)")
            
            
            else {
            let error = NSError(domain: "LocalDomain", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to create object URL"])
            print("Error: \(error)")
            completionHandler(nil, error)
            return
        }
        
        // Set up the session
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        let task = session.dataTask(with: url) { (data, response, error) in
            // Check if there is an error.
            guard error == nil else {
                DispatchQueue.main.async {
                    print("Google Directions Request Error: \((error!)).")
                    completionHandler(nil, error)
                }
                return
            }
            
            // Make sure data was received.
            guard let data = data else {
                DispatchQueue.main.async {
                    let error = NSError(domain: "GoogleDirectionsRequest", code: 0, userInfo: [NSLocalizedDescriptionKey: "Failed to receive data"])
                    print("Error: \(error).")
                    completionHandler(nil, error)
                }
                return
            }
            
            do {
                // Convert data to dictionary.
                guard let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                    DispatchQueue.main.async {
                        let error = NSError(domain: "GoogleDirectionsRequest", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to convert JSON to Dictionary"])
                        print("Error: \(error).")
                        completionHandler(nil, error)
                    }
                    return
                }
                
                // Check if the the Google Direction API returned a status OK response.
                guard let status: String = json["status"] as? String, status == "OK" else {
                    DispatchQueue.main.async {
                        let error = NSError(domain: "GoogleDirectionsRequest", code: 3, userInfo: [NSLocalizedDescriptionKey: "Google Direction API did not return status OK"])
                        print("Error: \(error).")
                        completionHandler(nil, error)
                    }
                    return
                }
                
                print("Google Direction API response:\n\(json)")
                
                // We only need the 'points' key of the json dictionary that resides within.
                if let routes: [Any] = json["routes"] as? [Any], routes.count > 0, let routes0: [String: Any] = routes[0] as? [String: Any], let overviewPolyline: [String: Any] = routes0["overview_polyline"] as? [String: Any], let points: String = overviewPolyline["points"] as? String {
                    // We need the get the first object of the routes array (route0), then route0's overview_polyline and finally overview_polyline's points object.
                    
                    if let path: GMSPath = GMSPath(fromEncodedPath: points) {
                        DispatchQueue.main.async {
                            completionHandler(path, nil)
                        }
                        return
                    } else {
                        DispatchQueue.main.async {
                            let error = NSError(domain: "GoogleDirections", code: 5, userInfo: [NSLocalizedDescriptionKey: "Failed to create GMSPath from encoded points string."])
                            completionHandler(nil, error)
                        }
                        return
                    }
                    
                } else {
                    DispatchQueue.main.async {
                        let error = NSError(domain: "GoogleDirections", code: 4, userInfo: [NSLocalizedDescriptionKey: "Failed to parse overview polyline's points"])
                        completionHandler(nil, error)
                    }
                    return
                }
                
                
            } catch let error as NSError  {
                DispatchQueue.main.async {
                    completionHandler(nil, error)
                }
                return
            }
            
        }
        
        task.resume()
    }
}


class RideViewController: UIViewController {
    
    
    //Variables
    @IBOutlet weak var activitytLocation: UIActivityIndicatorView!
    @IBOutlet weak var viewMap: UIView!
    @IBOutlet weak var viewGoogleMap: UIView!
    @IBOutlet weak var imgPinCenter: UIImageView!
    
    //custom
    var markerLocation : GMSMarker?
    var currentZoom : Float = 0.0
    var mapView = GMSMapView()
    
    
    
    //myInforView
    @IBOutlet weak var myInforView: UIView!
    
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longitudeLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        //Ahmedabad lat long, yuou can create .gpx file and you can use it as your default location in map
        /*
         <?xml version="1.0"?>
         <gpx version="1.1" creator="Xcode">
         
         <wpt lat="23.0271" lon="72.5085">
         <name>Ahmedabad</name>
         </wpt>
         </gpx>
         */
        
        //Srt temp title
        self.title = "Please wait while fetching address"
        
        //Initially, added temp location address
        let latitude : CLLocationDegrees = 23.0271
        let longitude : CLLocationDegrees = 72.5085
        
        currentZoom = 15
        
        let camera : GMSCameraPosition = GMSCameraPosition.camera(withLatitude: latitude, longitude: longitude, zoom: currentZoom, bearing: 3, viewingAngle: 0)
        
        //let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: 48.857165, longitude: 2.354613, zoom: 8.0)
        
        
        //Setup for mapview
        viewGoogleMap.layer.masksToBounds = true
        var mapTmp: CGRect = viewGoogleMap.frame
        mapTmp.size.height -= 64
        mapView = GMSMapView.map(withFrame: mapTmp, camera: camera)
        mapView.delegate = self
        mapView.isMyLocationEnabled = true
        mapView.settings.myLocationButton = true
        mapView.settings.compassButton = true
        mapView.isIndoorEnabled = false
        //    [mapView animateToViewingAngle:45];
        
        viewGoogleMap.addSubview(mapView)
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.0) {
            self.mapView.frame = self.viewGoogleMap.frame
            self.view.layoutIfNeeded()
        }
        
        UIView.animate(withDuration: 0.3, animations: {
            self.imgPinCenter.center = CGPoint(x: self.viewGoogleMap.center.x, y: self.viewGoogleMap.center.y-(self.imgPinCenter.frame.size.height/2))
        })
        
        
        activitytLocation.startAnimating()
        
        self.getAddressForMapCenter()
        
        
        
        //myInforView
        myInforView.isHidden = true
        
        
        
        // Distance
        let coordinate_1 = CLLocationCoordinate2D(latitude: g_User_Lat, longitude: g_User_Lon)
        let coordinate_2 = CLLocationCoordinate2D(latitude: g_Detail_Restaurant.info.location[0], longitude: g_Detail_Restaurant.info.location[1])

        //getPolylineRoute(from: coordinate_1, to: coordinate_2)
        
        let sessionManager = SessionManager()
        let start = CLLocationCoordinate2D(latitude: 37.778483, longitude: -122.513960)
        let end = CLLocationCoordinate2D(latitude: 37.706753, longitude: -122.418677)
        
        sessionManager.requestDirections(from: start, to: end, completionHandler: { (path, error) in
            
            if let error = error {
                print("Something went wrong, abort drawing!\nError: \(error)")
            } else {
                // Create a GMSPolyline object from the GMSPath
                let polyline = GMSPolyline(path: path!)
                
                // Add the GMSPolyline object to the mapView
                polyline.map = self.mapView
                
                // Move the camera to the polyline
                let bounds = GMSCoordinateBounds(path: path!)
                let cameraUpdate = GMSCameraUpdate.fit(bounds, with: UIEdgeInsets(top: 40, left: 15, bottom: 10, right: 15))
                self.mapView.animate(with: cameraUpdate)
            }
            
        })
        
        
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.imgPinCenter.center = CGPoint(x: self.viewGoogleMap.center.x, y: self.viewGoogleMap.center.y-(self.imgPinCenter.frame.size.height/2))
        })
    }
    
    func getAddressForMapCenter() {
        
        let point : CGPoint = mapView.center
        let coordinate : CLLocationCoordinate2D = mapView.projection.coordinate(for: point)
        let location =  CLLocation.init(latitude: coordinate.latitude, longitude: coordinate.longitude)
        self.GetAnnotationUsingCoordinated(location)
    }
    
    func GetAnnotationUsingCoordinated(_ location : CLLocation) {
        
        //get current address from geocode from apple, from location lat long
        GMSGeocoder().reverseGeocodeCoordinate(location.coordinate) { (response, error) in
            
            //stop animating loader
            if self.activitytLocation.isAnimating {
                self.activitytLocation.stopAnimating()
            }
            
            //self.imgPinCenter.isHidden = true
            
            var strAddresMain : String = ""
            
            if let address : GMSAddress = response?.firstResult() {
                if let lines = address.lines  {
                    if (lines.count > 0) {
                        if lines.count > 0 {
                            if lines[0].length > 0 {
                                strAddresMain = strAddresMain + lines[0]
                            }
                        }
                    }
                    
                    if lines.count > 1 {
                        if lines[1].length > 0 {
                            if strAddresMain.length > 0 {
                                strAddresMain = strAddresMain + ", \(lines[1])"
                            } else {
                                strAddresMain = strAddresMain + "\(lines[1])"
                            }
                        }
                    }
                    
                    if (strAddresMain.length > 0) {
                        print("strAddresMain : \(strAddresMain)")
                        
                        self.title = strAddresMain
                        
                        var strSubTitle = ""
                        if let locality = address.locality {
                            strSubTitle = locality
                        }
                        
                        if let administrativeArea = address.administrativeArea {
                            if strSubTitle.length > 0 {
                                strSubTitle = "\(strSubTitle), \(administrativeArea)"
                            }
                            else {
                                strSubTitle = administrativeArea
                            }
                        }
                        
                        if let country = address.country {
                            if strSubTitle.length > 0 {
                                strSubTitle = "\(strSubTitle), \(country)"
                            }
                            else {
                                strSubTitle = country
                            }
                        }
                        
                        
                        if strSubTitle.length > 0 {
                            self.addPin_with_Title(strAddresMain, subTitle: strSubTitle, location: location)
                        }
                        else {
                            self.addPin_with_Title(strAddresMain, subTitle: "Your address", location: location)
                        }
                    }
                    else {
                        print("Location address not found")
                        self.title = "Location address not found"
                    }
                }
                else {
                    self.title = "Please change location, address is not available"
                    
                    print("Please change location, address is not available")
                }
            }
            else {
                self.title = "Address is not available"
                
                print("Address is not available")
            }
        }
    }
    
    func addPin_with_Title(_ title: String, subTitle: String, location : CLLocation) {
        
        if markerLocation == nil {
            markerLocation = GMSMarker.init()//GMSMarker.init(position: location.coordinate)
        }
        
        //add Marker on google map
        self.addMarkerOnGoogleMap(title, subTitle: subTitle, location: location)
    }
    
    func addMarkerOnGoogleMap(_ title: String, subTitle: String, location: CLLocation) {
        //update title
        //        var titleMain = (title.length > 20) ? ("\(title.substring(to: 20))") : title
        
        let position : CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
        markerLocation = GMSMarker(position: position)
        markerLocation?.title = title
        markerLocation?.snippet = subTitle
        markerLocation?.icon =  #imageLiteral(resourceName: "ic_pin_drop")
        markerLocation?.appearAnimation = .pop
        
        
        
        
        mapView.clear()
        markerLocation?.map = mapView
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Button Action methods

    @IBAction func btnZoomClicked(_ sender: Any) {
        
        let point : CGPoint = mapView.center
        let coordinate : CLLocationCoordinate2D = mapView.projection.coordinate(for: point)
        
        if((sender as! UIButton).tag == 0) {
            print("btnZoominClicked")
            
            currentZoom += 1;
            
        }
        else {
            print("btnZoomOutClicked")
            
            currentZoom -= 1;
        }
        
        let camera : GMSCameraPosition = GMSCameraPosition.camera(withLatitude: coordinate.latitude, longitude: coordinate.longitude, zoom: currentZoom)
        mapView.camera = camera
    }
    
    @IBAction func changeMapType(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Map Types", message: "Select map type:", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let normalMapTypeAction = UIAlertAction(title: "Normal", style: UIAlertActionStyle.default) { (alertAction) -> Void in
            self.mapView.mapType = .normal //  kGMSTypeNormal
            //self.mapView.mapType = GMSMapViewType(rawValue: 1)!
        }
        
        let terrainMapTypeAction = UIAlertAction(title: "Terrain", style: UIAlertActionStyle.default) { (alertAction) -> Void in
            self.mapView.mapType = .terrain // kGMSTypeTerrain
        }
        
        let hybridMapTypeAction = UIAlertAction(title: "Hybrid", style: UIAlertActionStyle.default) { (alertAction) -> Void in
            self.mapView.mapType =  .hybrid // kGMSTypeHybrid
        }
        
        let satelliteMapTypeAction = UIAlertAction(title: "satellite", style: UIAlertActionStyle.default) { (alertAction) -> Void in
            self.mapView.mapType =  .satellite // kGMSTypeSatellite
        }
        
        
        let cancelAction = UIAlertAction(title: "Close", style: UIAlertActionStyle.cancel) { (alertAction) -> Void in
            
        }
        
        
        actionSheet.addAction(normalMapTypeAction)
        actionSheet.addAction(terrainMapTypeAction)
        actionSheet.addAction(hybridMapTypeAction)
        actionSheet.addAction(satelliteMapTypeAction)
        actionSheet.addAction(cancelAction)
        
        present(actionSheet, animated: true, completion: nil)
    }
    
    //Infor View
    @IBAction func onTappedCurrentInfoShare(_ sender: Any) {
        print("~~~~~~~~~~~~~~~~~~~ share ~~~~~~~~~~~~~~~~~~~")
        
        //var image = UIImage(named: "icon_messages.png")?
        //shareTextImageAndURL(sharingText: "Hello this is a test", sharingImage: image, sharingURL: NSURL(string: "http://www.example.com/"))
        
        shareTextImageAndURL(sharingText: "latitude = \(self.latitudeLabel.text!), longitude = \(self.longitudeLabel.text!) ", sharingImage: nil, sharingURL: NSURL(string: ""))
        
        
    }
    
    func shareTextImageAndURL(sharingText: String?, sharingImage: UIImage?, sharingURL: NSURL?) {
        var sharingItems = [AnyObject]()
        
        if let text = sharingText {
            sharingItems.append(text as AnyObject)
        }
        if let image = sharingImage {
            sharingItems.append(image)
        }
        if let url = sharingURL {
            sharingItems.append(url)
        }
        
        let activityViewController = UIActivityViewController(activityItems: sharingItems, applicationActivities: nil)
        
        activityViewController.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList]
        
        
        if(activityViewController.popoverPresentationController != nil) {
            activityViewController.popoverPresentationController?.sourceView = self.view;
            var frame = UIScreen.main.bounds
            //            frame.height = frame.height / 2
            var newFrame = CGRect(x: frame.origin.x, y: frame.origin.y, width: frame.width, height: frame.height / 2)
            activityViewController.popoverPresentationController?.sourceRect = frame;
        }
        
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

   
    
    
}




extension RideViewController : GMSMapViewDelegate {
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        //print("didChangeCameraPosition: \(position)")
        mapView.clear()
        
        //markerLocation?.map = mapView
        
        //self.imgPinCenter.isHidden = false
        activitytLocation.startAnimating()
        
    }
    
    func mapView(_ mapView: GMSMapView, idleAt position: GMSCameraPosition) {
        //print("idleAtCameraPosition: \(position)")
        //stop animating loader
        if !self.activitytLocation.isAnimating {
            activitytLocation.startAnimating()
        }
        
        //self.imgPinCenter.isHidden = false
        self.getAddressForMapCenter()
    }
    
    func mapView(_ mapView: GMSMapView, markerInfoWindow marker: GMSMarker) -> UIView? {
        
        
        /*let customInfoWindow = Bundle.main.loadNibNamed("CustomInfoWindow", owner: self, options: nil)?[0] as! CustomInfoWindow
         
         let point : CGPoint = mapView.center
         let coordinate : CLLocationCoordinate2D = mapView.projection.coordinate(for: point)
         //let location =  CLLocation.init(latitude: coordinate.latitude, longitude: coordinate.longitude)
         
         
         customInfoWindow.architectLbl.text =  String(coordinate.latitude)
         customInfoWindow.completedYearLbl.text = String(coordinate.longitude)
         customInfoWindow.buttonShare.addTarget(self, action: #selector(ViewController.ShareCurrentPoint(_:)), for: .touchUpInside)
         self.view.addSubview(customInfoWindow)
         return customInfoWindow*/
        
        
        
        
        
        /*self.myInforView.isHidden = false
         
         let point : CGPoint = mapView.center
         let coordinate : CLLocationCoordinate2D = mapView.projection.coordinate(for: point)
         
         self.latitudeLabel.text =  String(coordinate.latitude)
         self.longitudeLabel.text = String(coordinate.longitude)
         //self.view.addSubview(nil)
         return nil*/
        return UIView()
        
        //return nil
    }
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        
        self.myInforView.isHidden = false
        
        let point : CGPoint = mapView.center
        let coordinate : CLLocationCoordinate2D = mapView.projection.coordinate(for: point)
        
        self.latitudeLabel.text =  String(coordinate.latitude)
        self.longitudeLabel.text = String(coordinate.longitude)
        
        return false
    }
    
    func mapView(_ mapView: GMSMapView, didTapAt coordinate: CLLocationCoordinate2D) {
        self.myInforView.isHidden = true
    }
    /*func mapView(_ mapView: GMSMapView, didTapInfoWindowOf marker: GMSMarker) {
     //marker.
     }*/
    
    //Delegate
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    func ShareCurrentPoint(_ sender: Any) {
        
        print("asdfasfasfs")
    }
    
    
    /*func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
     
     /*let customInfoWindow = Bundle.main.loadNibNamed("CustomInfoWindow", owner: self, options: nil)?[0] as! CustomInfoWindow
     customInfoWindow.architectLbl.text = "architectNames[index]"
     customInfoWindow.completedYearLbl.text = "completedYear[index]"
     return customInfoWindow*/
     
     /*let position : CLLocationCoordinate2D = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude)
     markerLocation = GMSMarker(position: position)
     markerLocation?.title = title
     markerLocation?.snippet = subTitle
     markerLocation?.icon =  #imageLiteral(resourceName: "ic_pin_drop")
     markerLocation?.appearAnimation = .pop
     mapView.clear()
     markerLocation?.map = mapView*/
     
     
     return true
     }*/
    
    
}

//class RideViewController: UIViewController, GMSMapViewDelegate {
//
//    // Properties
//    @IBOutlet weak var map: GMSMapView!
//
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        self.map.delegate = self
//        
//        // Do any additional setup after loading the view.
//        // Distance
//        let coordinate_1 = CLLocationCoordinate2D(latitude: g_User_Lat, longitude: g_User_Lon)
//        let coordinate_2 = CLLocationCoordinate2D(latitude: g_Detail_Restaurant.info.location[0], longitude: g_Detail_Restaurant.info.location[1])
//        
//        //getPolylineRoute(from: coordinate_1, to: coordinate_2)
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
//
//    @IBAction func onTappedBackButton(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
//    }
//    
//    
//    // Pass your source and destination coordinates in this method.
//    func getPolylineRoute(from source: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D){
//        
//        let config = URLSessionConfiguration.default
//        let session = URLSession(configuration: config)
//        
//        let url = URL(string: "http://maps.googleapis.com/maps/api/directions/json?origin=\(source.latitude),\(source.longitude)&destination=\(destination.latitude),\(destination.longitude)&sensor=false&mode=driving")!
//        
//        let task = session.dataTask(with: url, completionHandler: {
//            (data, response, error) in
//            if error != nil {
//                print(error!.localizedDescription)
//            }else{
//                do {
//                    if let json : [String:Any] = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]{
//                        
//                        let routes = json["routes"] as? [Any]
//                        let overview_polyline = routes?[0] as?[String:Any]
//                        let polyString = overview_polyline?["points"] as?String
//                        
//                        //Call this method to draw path on map
//                        self.showPath(polyStr: polyString!)
//                    }
//                    
//                }catch{
//                    print("error in JSONSerialization")
//                }
//            }
//        })
//        task.resume()
//    }
//    
//    func showPath(polyStr :String){
//        let path = GMSPath(fromEncodedPath: polyStr)
//        let polyline = GMSPolyline(path: path)
//        polyline.strokeWidth = 3.0
//        polyline.map = map // Your map view
//    }
//
//}
