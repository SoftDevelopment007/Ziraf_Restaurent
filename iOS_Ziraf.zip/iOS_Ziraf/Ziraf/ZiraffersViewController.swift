//
//  ZiraffersViewController.swift
//  Ziraf
//
//  Created by LEE on 8/7/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ZiraffersViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    let GlobalVar = Global()
    @IBOutlet weak var collectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        // Loading Data
//        TryLoad_ziraferArray(completion: {
//            self.collectionView.reloadData()
//        })
        
        tryGetZiraffers()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        analyticsEvent(forName: "Zirafers")
    }
    
    func analyticsEvent(forName: String!) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let analytics = appDelegate.analytics
        let eventClient = analytics?.eventClient;
        let levelEvent = eventClient?.createEvent(withEventType: "Zirafers")
        levelEvent?.addAttribute(forName, forKey:"Zirafers")
        eventClient?.record(levelEvent)
        eventClient?.submitEvents()
    }
    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func onTappedGotoProfile(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //1
        self.performSegue(withIdentifier: StorySegues.FromZirafersToProfile.rawValue, sender: self)
        
    }
    
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return g_zirafers_Array.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ZiraffersCollectionCell", for: indexPath as IndexPath) as! ZiraffersCollectionCell
        
        //Cell shape
        cell.LabelRoundView.backgroundColor = UIColor(red: 230.0/255.0, green: 230.0/255.0, blue: 230.0/255.0, alpha: 0.75)
        
        //cell.backgroundColor =  UIColor.clear//UIColor.cyan // make cell more visible in our example project
        cell.zirafersRoundView.layer.borderColor = UIColor.black.cgColor
        cell.zirafersRoundView.layer.borderWidth = 1
        
        cell.zirafersName.text = g_zirafers_Array[indexPath.item].name
        
        cell.myImageView.sd_setShowActivityIndicatorView(true)
        cell.myImageView.sd_setIndicatorStyle(.white)
        
        
        let k = randomInt(min: 1, max: 30)
        let avatar_url = "http://35.177.9.16:8080/upload/zirafer?url=\(g_zirafers_Array[indexPath.item].id).png&temp=\(k)"
        cell.myImageView.sd_setImage(with: URL(string: avatar_url))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        
        let newCellWidth = 170 * ScreenWidth / 375
        let newCellHeight = 170 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        g_zirafersTozirProfile_selectedIndexNumber_Id = g_zirafers_Array[indexPath.item].id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromZirafersToZirProfile.rawValue, sender: self)
    }
    
    //Try Load Data ==========================================================================================
    //
    //
    /*func TryLoad_ziraferArray(completion: @escaping() -> Void) {
        
        var items = ["Onafoodhunt", "Stubudget", "Stephaniechan14", "Hungrybeard", "Leggooeat", "Cuppacup"]
        var items_Image = [UIImage]()
        items_Image.append(UIImage(named: "zirafers1.png")!)
        items_Image.append(UIImage(named: "zirafers2.png")!)
        items_Image.append(UIImage(named: "zirafers3.png")!)
        items_Image.append(UIImage(named: "zirafers4.png")!)
        items_Image.append(UIImage(named: "zirafers5.png")!)
        items_Image.append(UIImage(named: "zirafers6.png")!)
        var items_Image_str = ["zirafers1.png", "zirafers2.png", "zirafers3.png", "zirafers4.png", "zirafers5.png", "zirafers6.png"]
        
        g_zirafers_Array.removeAll()
        g_zirafersTozirProfile_selectedIndexNumber = -1
        
        for i in 0..<items.count {
            
            var temp: zirafer_Info = zirafer_Info(id: -1, name: "", profession: "Food Expert", quote: "First we eat, then we do everything else.", social_link: [], photos: [])
            
            temp.name = items[i]
            temp.photos[i].append(items_Image_str[i])
            
            g_zirafers_Array.append(temp)
        }
        
        completion()
    }*/
    //=========================================================================================
    //
    // Post GetZiraffers
    //
    //=========================================================================================
    func tryGetZiraffers() {
        
        g_zirafers_Array.removeAll()
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Get_Zirafers, fields: "", completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    let info_dict = responseObject["info"] as! NSArray
                    if (info_dict != nil ) {
                        for info_data in info_dict {
                            
                            var temp : zirafer_Info = zirafer_Info(id: -1, name: "", profession: "", quote: "", social_link: [])
                            
                            let dict = info_data as! [String: AnyObject]
                            temp.id = dict["_id"] as! Int
                            temp.name = dict["name"] as! String
                            temp.profession = dict["profession"] as! String
                            temp.quote = dict["quote"] as! String
                            
                            let social_link_array = dict["social_link"] as! [String]
                            for i in 0..<social_link_array.count {
                                temp.social_link.append(social_link_array[i])
                            }
                            
                            g_zirafers_Array.append(temp)
                        }
                        
                        let when = DispatchTime.now() + 1
                        DispatchQueue.main.asyncAfter(deadline: when) {
                            // Your code with delay
                            
                            //g_FristVist_Main = false
                            //ProgressHUD.dismiss()
                            self.collectionView.reloadData()
                        }
                        
                    }
                }
            }
            else {
            }
        })
    }
    
}
