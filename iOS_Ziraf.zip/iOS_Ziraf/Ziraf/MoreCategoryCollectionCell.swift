//
//  MoreCategoryCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/19/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class MoreCategoryCollectionCell: UICollectionViewCell {
    @IBOutlet weak var moreCategory_Label: UILabel!
}
