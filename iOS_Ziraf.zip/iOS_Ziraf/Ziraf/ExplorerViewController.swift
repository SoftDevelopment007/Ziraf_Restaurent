//
//  ExplorerViewController.swift
//  Ziraf
//
//  Created by LEE on 8/5/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ExplorerViewController: UIViewController, UITextFieldDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    let GlobalVar = Global()
    
    @IBOutlet weak var SearchRoundView: UIView!
    @IBOutlet weak var SearchText: UITextField!
    @IBOutlet weak var SearchTextBackground: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var leftSearchImage: UIImageView!
    @IBOutlet weak var rightSearchImage: UIImageView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var bottomBarImage: UIImageView!
    
    //var refresher: UIRefreshControl!
    var refreshControl:UIRefreshControl!
    
    var searchActive : Bool = false
    var filtered:[category_Info] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        //Text Delegate
        SearchText.delegate = self
        SearchText.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        
        SetupUI()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.tintColor = UIColor.white
        
        //self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        let attributes = [NSForegroundColorAttributeName: UIColor.white, NSFontAttributeName: UIFont.systemFont(ofSize: 12)]
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh", attributes: attributes)
        
        self.refreshControl.addTarget(self, action: #selector(loadData), for: UIControlEvents.valueChanged)
        collectionView!.addSubview(refreshControl)
        
        if g_FristVist_Main == true {
            loadData()
        }
        
        //tryGet_MainCategory()
        self.collectionView.reloadData()
    }

    func loadData() {
        //code to execute during refresher
        tryGet_MainCategory()
        stopRefresher()
        collectionView.reloadData()
    }
    
    func stopRefresher() {
        self.refreshControl.endRefreshing()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    func SetupUI() {
        
//        SearchText.layer.cornerRadius = SearchText.bounds.size.height / 2.0
//        SearchText.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
//        SearchText.layer.borderWidth = 1
//        
//        SearchTextBackground.layer.cornerRadius = SearchTextBackground.bounds.size.height / 2.0
//        SearchTextBackground.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
//        SearchTextBackground.layer.borderWidth = 1
        
        
        SearchRoundView.layer.cornerRadius = 16 //SearchRoundView.bounds.size.height / 2.0
        SearchRoundView.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        SearchRoundView.layer.borderWidth = 1
        
        SearchTextBackground.isHidden = false
        leftSearchImage.isHidden = false
        rightSearchImage.isHidden = true
        searchButton.isHidden = true
        
        bottomBarImage.alpha = 0.55
        
        searchActive = false
    }
    
    func textFieldDidChange(_ textField: UITextField) {
        if SearchText.text == "" {
            SearchTextBackground.isHidden = false
            leftSearchImage.isHidden = false
            rightSearchImage.isHidden = true
            searchButton.isHidden = true
            
            searchActive = false
            self.collectionView.reloadData()
            
        } else {
            SearchTextBackground.isHidden = true
            leftSearchImage.isHidden = true
            rightSearchImage.isHidden = false
            searchButton.isHidden = false
            
            searchActive = true
            
            self.filtered.removeAll()
            for i in 0 ... g_Main_Category_Array.count - 1 {
                
                if g_Main_Category_Array[i].name.lowercased().range(of: (SearchText.text?.lowercased())!) != nil  {
                    filtered.append(g_Main_Category_Array[i])
                }
            }
            self.collectionView.reloadData()
        }
    }
    
    @IBAction func onTappedGotoHome(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedGotoProfile(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromExplorerToProfile.rawValue, sender: self)
        
    }
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchActive {
            return filtered.count
        } else {
            return g_Main_Category_Array.count
        }
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ExplorerCollectionCell", for: indexPath as IndexPath) as! ExplorerCollectionCell
        cell.backgroundColor =  UIColor.clear
        
        if searchActive {
            cell.myTitle.text = filtered[indexPath.item].name
            
            cell.myImageView.sd_setShowActivityIndicatorView(true)
            cell.myImageView.sd_setIndicatorStyle(.white)
            
            let url = "http://35.177.9.16:8080/upload/category?url=\(filtered[indexPath.item].id).png"
            cell.myImageView.sd_setImage(with: URL(string: url))
            
        } else {
            cell.myTitle.text = g_Main_Category_Array[indexPath.item].name
            
            cell.myImageView.sd_setShowActivityIndicatorView(true)
            cell.myImageView.sd_setIndicatorStyle(.white)
            
            let url = "http://35.177.9.16:8080/upload/category?url=\(g_Main_Category_Array[indexPath.item].id).png"
            cell.myImageView.sd_setImage(with: URL(string: url))
        }
        
//        cell.myImageView.layer.borderColor = UIColor.black.cgColor
//        cell.myImageView.layer.borderWidth = 1
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        let ScreenHeight = ScreenSize.height
        
        let newCellWidth = 110 * ScreenWidth / 375
        let newCellHeight = 110 * ScreenHeight / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
        
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        g_Category_Id = g_Main_Category_Array[indexPath.item].id
        
        let categoryName = g_Main_Category_Array[indexPath.item].name
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let analytics = appDelegate.analytics
        let eventClient = analytics?.eventClient;
        let levelEvent = eventClient?.createEvent(withEventType: "OpenCategory")
        levelEvent?.addAttribute(categoryName, forKey:"categoryName")
        eventClient?.record(levelEvent)
        eventClient?.submitEvents()

        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromExplorerToPicker.rawValue, sender: self)
    }
    
    //
    @IBAction func onTappedSearchButton(_ sender: Any) {
        if searchActive {
            
            self.filtered.removeAll()
            for i in 0 ... g_Main_Category_Array.count - 1 {
                
                if g_Main_Category_Array[i].name.lowercased().range(of: (SearchText.text?.lowercased())!) != nil  {
                    filtered.append(g_Main_Category_Array[i])
                }
            }
            
        } else {
        }
        self.collectionView.reloadData()
    }
    
    @IBAction func onTappedMoreCategoriesButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromExplorerToMore.rawValue, sender: self)
    }

    //=========================================================================================
    //
    // Post Get_MainCategory
    //
    //=========================================================================================
    func tryGet_MainCategory() {
        
        g_Main_Category_Array.removeAll()
        self.collectionView.reloadData()
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.Explorer_Main, fields: "", completion: {(responseObject) in
            
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    let main_dict = responseObject["info"] as! NSArray
                    if (main_dict != nil ) {
                        
                        for main_data in main_dict {
                            let dict = main_data as! [String: AnyObject]
                            
                            let id   = dict["_id"]  as! Int
                            let name = dict["name"] as! String
                            let type = dict["type"] as! String
                            
                            var temp : category_Info = category_Info(id: -1, name: "", type: "")
                            temp.id = id
                            temp.name = name
                            temp.type = type
                            
                            g_Main_Category_Array.append(temp)
                            //self.collectionView.reloadData()
                        }
                        
                        let when = DispatchTime.now() + 1
                        DispatchQueue.main.asyncAfter(deadline: when) {
                            // Your code with delay
                            
                            g_FristVist_Main = false
                            //ProgressHUD.dismiss()
                            self.collectionView.reloadData()
                        }
                        
                    }
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
}


