//
//  DetailViewController.swift
//  Ziraf
//
//  Created by LEE on 8/6/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit
import ImageSlideshow
import CoreLocation
import GoogleMaps


class DetailViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegateFlowLayout, UIWebViewDelegate {

    let GlobalVar = Global()
    
    @IBOutlet weak var sub_view: UIView!
    @IBOutlet weak var round_view1: UIView!
    @IBOutlet weak var round_view2: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var detail_Label: UILabel!
    
    
    
    @IBOutlet weak var slideView: ImageSlideshow!
    
    @IBOutlet weak var RestaurantName: UILabel!
    @IBOutlet weak var RestaurantLocation: UILabel!
    @IBOutlet weak var HomeRoundView: UIView!
    
    // Mark-- "Info, Reviews, Menu"
    @IBOutlet weak var InfoRoundView: UIView!
    @IBOutlet weak var ReviewsRoundView: UIView!
    @IBOutlet weak var MenuRoundView: UIView!
    
    @IBOutlet weak var InfoStaticView: UIView!
    @IBOutlet weak var ReviewsStaticView: UIView!
    @IBOutlet weak var MenuStaticView: UIView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tableView: UITableView!
    
    // Info view
    @IBOutlet weak var info_price_Label: UILabel!
    @IBOutlet weak var info_topic_Label: UILabel!
    @IBOutlet weak var info_rating_Label: UILabel!
    @IBOutlet weak var info_distance_Label: UILabel!
    @IBOutlet weak var info_phone_number_Label: UILabel!
    
    
    @IBOutlet weak var info_open_MainLabel: UILabel!
    @IBOutlet weak var info_open_SubView: UIView!
    //@IBOutlet weak var info_open_Subtext: UITextView!
    
    @IBOutlet weak var info_open_Sub_TextView: UITextView!
    @IBOutlet weak var info_open_Sub_Label: UILabel!
    @IBOutlet weak var info_Done_Button: UIButton!
    
    @IBOutlet weak var menu_web_view: UIWebView!
    
    // Animation View
    @IBOutlet weak var AnimationView1: UIView!
    @IBOutlet weak var AnimationView2: UIView!
    
    // giraf neck favorite
    @IBOutlet weak var small_neck_button: UIButton!
    
    
    
    
    //Set Table Refresh Control
//    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sub_view.fadeOut(duration: 0.0, delay: 0.0)
        //round_view1.layer.cornerRadius = 4.0
        //round_view2.layer.cornerRadius = 4.0
        
        self.info_open_SubView.fadeOut(duration: 0.0, delay: 0.0)
        self.AnimationView1.fadeOut(duration: 0.0, delay: 0.0)
        self.AnimationView2.fadeOut(duration: 0.0, delay: 0.0)
        self.small_neck_button.fadeOut(duration: 0.0, delay: 0.0)
        
        SetupUI()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = UIColor.clear
        
/*        //Set Table Refresh Control
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "")
        
        refreshControl.addTarget(self, action: #selector(self.handleRefresh(sender:)), for: UIControlEvents.valueChanged)
        self.tableView.addSubview(refreshControl)
        
        //========================================
        handleRefresh(sender: self)
        //========================================
*/
        //SlideShow==========================================================================
        
        //slideshow.backgroundColor = UIColor.white
        slideView.slideshowInterval = 3.5
        slideView.pageControlPosition = PageControlPosition.underScrollView
        slideView.pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        slideView.pageControl.pageIndicatorTintColor = UIColor.black
        slideView.contentScaleMode = UIViewContentMode.scaleAspectFill
        slideView.currentPageChanged = { page in
            //print("current page:", page)
        }
        
        //Get_DetailRestaurant()

    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func SetupUI() {
        
        onTappedInfoButton(self)
        
        HomeRoundView.layer.cornerRadius = HomeRoundView.bounds.size.height / 2.0
        HomeRoundView.layer.borderColor = UIColor.white.cgColor
        
        InfoRoundView.layer.cornerRadius = InfoRoundView.bounds.size.height / 2.0
        InfoRoundView.layer.borderColor = UIColor.white.cgColor
        
        ReviewsRoundView.layer.cornerRadius = ReviewsRoundView.bounds.size.height / 2.0
        ReviewsRoundView.layer.borderColor = UIColor.white.cgColor
        
        MenuRoundView.layer.cornerRadius = MenuRoundView.bounds.size.height / 2.0
        MenuRoundView.layer.borderColor = UIColor.white.cgColor
        
        info_Done_Button.layer.cornerRadius = info_Done_Button.bounds.size.height / 2.0
        info_Done_Button.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        info_Done_Button.layer.borderWidth = 1
        
        info_open_SubView.layer.cornerRadius = 5.0
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.info_open_SubView.fadeOut(duration: 0.0, delay: 0.0)
        self.AnimationView1.fadeOut(duration: 0.0, delay: 0.0)
        self.AnimationView2.fadeOut(duration: 0.0, delay: 0.0)
        self.small_neck_button.fadeOut(duration: 0.0, delay: 0.0)
        
        Get_DetailRestaurant()
//        slideView.setImageInputs(g_localSource_Detail)
    }
    
/*    func handleRefresh(sender:AnyObject) {
        
        g_reviewsTable_Array.removeAll()
        //tableView.reloadData()
        
        let temp1: Table_Info = Table_Info(
            title:           "onafoodhunt",
            rate:            8.5,
            popular:         10,
            BackgroundImage: UIImage(named: "review1.png")!,
            
            reviews:        "Amazing japanese BBQ in central London that certainly won't burn a hole in your pocket. Their happy hour promo is the BAE, drop by 12-6 pm to get more bang for your buck."
        )
        g_reviewsTable_Array.append(temp1)
        
        let temp2: Table_Info = Table_Info(
            title:           "Eatwithsteph_ldn",
            rate:            8.5,
            popular:         10,
            BackgroundImage: UIImage(named: "review2.png")!,
            
            reviews:        "Such a relaxing place to spend your eventing. The service was good and fast, and the spick pork kalbi is absolute delish!"
        )
        g_reviewsTable_Array.append(temp2)
        
        let temp3: Table_Info = Table_Info(
            title:           "Leggooeat",
            rate:            8.5,
            popular:         10,
            BackgroundImage: UIImage(named: "review3.png")!,
            
            reviews:        "I had a wonderful experience here. Highly recommended it."
        )
        g_reviewsTable_Array.append(temp3)
        
        refreshControl.endRefreshing()
        tableView.reloadData()
    }
*/
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedGotoFavoriteButton(_ sender: Any) {
        trySet_Favorite()
    }
    
    
    @IBAction func onTappedInfoButton(_ sender: Any) {
        InfoRoundView.backgroundColor = UIColor.white
        ReviewsRoundView.backgroundColor = UIColor.clear
        MenuRoundView.backgroundColor = UIColor.clear
        
        InfoStaticView.isHidden = false
        ReviewsStaticView.isHidden = true
        MenuStaticView.isHidden = true
        
        //InfoStaticView.isUserInteractionEnabled = true
        //self.info_open_SubView.fadeOut(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedReviewsButton(_ sender: Any) {
        InfoRoundView.backgroundColor = UIColor.clear
        ReviewsRoundView.backgroundColor = UIColor.white
        MenuRoundView.backgroundColor = UIColor.clear
        
        InfoStaticView.isHidden = true
        ReviewsStaticView.isHidden = false
        MenuStaticView.isHidden = true
        
        //InfoStaticView.isUserInteractionEnabled = true
        self.info_open_SubView.fadeOut(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedMenuButton(_ sender: Any) {
        InfoRoundView.backgroundColor = UIColor.clear
        ReviewsRoundView.backgroundColor = UIColor.clear
        MenuRoundView.backgroundColor = UIColor.white
        
        InfoStaticView.isHidden = true
        ReviewsStaticView.isHidden = true
        MenuStaticView.isHidden = false
        
        //InfoStaticView.isUserInteractionEnabled = true
        self.info_open_SubView.fadeOut(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedInfoDoneButton(_ sender: Any) {
        //InfoStaticView.isUserInteractionEnabled = true
        self.info_open_SubView.fadeOut(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedShowOpenTime(_ sender: Any) {
        //InfoStaticView.isUserInteractionEnabled = false
        self.info_open_SubView.fadeIn(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedShowOpenTimeWatch(_ sender: Any) {
        self.info_open_SubView.fadeIn(duration: 0.5, delay: 0.5)
    }
    
    @IBAction func onTappedGotoHomeButton(_ sender: Any) {
//        if g_numerOfpage_nearMe_Flag {
//            g_numerOfpage_nearMe_Flag = false
//            
//            var viewControllers = navigationController?.viewControllers
//            viewControllers?.removeLast(g_numerOfpage_Flag + 1) //2 views to pop
//            navigationController?.setViewControllers(viewControllers!, animated: true)
//            
//        } else {
//            g_numerOfpage_nearMe_Flag = false
//            
//            var viewControllers = navigationController?.viewControllers
//            viewControllers?.removeLast(g_numerOfpage_Flag + 2) //3 views to pop
//            navigationController?.setViewControllers(viewControllers!, animated: true)
//        }

            g_numerOfpage_Flag = g_numerOfpage_Flag + 1
            var viewControllers = navigationController?.viewControllers
            viewControllers?.removeLast(g_numerOfpage_Flag) //2 views to pop
            navigationController?.setViewControllers(viewControllers!, animated: true)
    }

    @IBAction func onTappedGotoProfileButton(_ sender: Any) {
//        if g_numerOfpage_nearMe_Flag {
//            
//            g_numerOfpage_nearMe_Flag = false
//            g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //2
//
//            self.performSegue(withIdentifier: StorySegues.FromDetailToProfile.rawValue, sender: self)
//            
//        } else {
//            g_numerOfpage_nearMe_Flag = false
//            g_numerOfpage_Flag = g_numerOfpage_Flag + 2 //3
//            self.performSegue(withIdentifier: StorySegues.FromDetailToProfile.rawValue, sender: self)
//        }
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromDetailToProfile.rawValue, sender: self)
    }
    
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return g_Detail_Restaurant.top_picks.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InfoCollectionCell", for: indexPath as IndexPath) as! InfoCollectionCell
        
        cell.myImageView.sd_setShowActivityIndicatorView(true)
        cell.myImageView.sd_setIndicatorStyle(.white)
        
        let url = "http://35.177.9.16:8080/upload/top_pick?url=\(g_Detail_Restaurant.top_picks[indexPath.item].id).png"
        cell.myImageView.sd_setImage(with: URL(string: url))
        
        cell.layer.backgroundColor =  UIColor.clear.cgColor
        
//        cell.myImageView.layer.borderColor = UIColor.black.cgColor
//        cell.myImageView.layer.borderWidth = 1
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        //let ScreenHeight = ScreenSize.height
        
        let newCellWidth = 90 * ScreenWidth / 375
        let newCellHeight = 90 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//        
//        let ScreenSize = UIScreen.main.bounds
//        let ScreenWidth = ScreenSize.width
//        return 5 * ScreenWidth / 375 - 1;
//    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        
//        let ScreenSize = UIScreen.main.bounds
//        let ScreenWidth = ScreenSize.width
//        return 5 * ScreenWidth / 375 - 1;
//    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        //let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InfoCollectionCell", for: indexPath as IndexPath) as! InfoCollectionCell
        
        
        self.imageView.sd_setShowActivityIndicatorView(true)
        self.imageView.sd_setIndicatorStyle(.white)
        
        let url = "http://35.177.9.16:8080/upload/top_pick?url=\(g_Detail_Restaurant.top_picks[indexPath.item].id).png"
        self.imageView.sd_setImage(with: URL(string: url))
        
        
//        let ScreenSize = UIScreen.main.bounds
//        let ScreenWidth = ScreenSize.width
//        let newImg_width = ScreenWidth * 350 / 375   //(320)
//        let newImg_height = (imageView.image?.size.height)! * ((imageView.image?.size.width)! / newImg_width )
//        imageView.image = imageView.image?.resize(width: newImg_width, height: newImg_height)
        
        self.detail_Label.text = g_Detail_Restaurant.top_picks[indexPath.item].description
        
        sub_view.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    @IBAction func onTappedHideButton(_ sender: Any) {
        sub_view.fadeOut(duration: 0.2, delay: 0.2)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 8 * ScreenWidth / 375 - 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 8 * ScreenWidth / 375 - 1;
    }
    
    
    //================================================================================
    // table delegate
    //
    //
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return g_Detail_Restaurant.reviews.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReviewsTableCell") as? ReviewsTableCell
        
        cell?.backgroundImage.bounds.size.height = (cell?.backgroundImage.bounds.size.width)!
        cell?.backgroundImage.layer.cornerRadius = (cell?.backgroundImage.bounds.size.width)! / 2.0 //50
        cell?.backgroundImage.layer.borderColor = UIColor.gray.cgColor
        cell?.backgroundImage.layer.borderWidth = 1
        
        for i in 0..<g_Detail_Restaurant.zirafers.count {
            if g_Detail_Restaurant.zirafers[i].id == g_Detail_Restaurant.reviews[indexPath.row].zirafer_id {
                cell?.titleText.text = g_Detail_Restaurant.zirafers[i].name
                
                cell?.backgroundImage.sd_setShowActivityIndicatorView(true)
                cell?.backgroundImage.sd_setIndicatorStyle(.white)
                let avatar_url = "http://35.177.9.16:8080/upload/zirafer?url=\(g_Detail_Restaurant.zirafers[i].id).png"
                cell?.backgroundImage.sd_setImage(with: URL(string: avatar_url))
                
                continue
            }
        }
        
        cell?.rateText.text = "\(g_Detail_Restaurant.reviews[indexPath.row].rating[4])"
        cell?.reviewTextView.text = g_Detail_Restaurant.reviews[indexPath.row].review
        
        cell?.select_Button.tag  =  indexPath.row
        
        //cell?.layer.backgroundColor = UIColor.clear.cgColor
        return cell!
        
    }
    
    @IBAction func onTappedSelectButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        
        print("select Button!")
        
        
        g_zirafersTozirProfile_selectedIndexNumber_Id = g_Detail_Restaurant.reviews[index].zirafer_id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1
        self.performSegue(withIdentifier: StorySegues.FromDetailToZirafProfile.rawValue, sender: self)

    }
    
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//    }
    
    @IBAction func onTappedRideAppleMap(_ sender: Any) {
        // Apple Map
//        let directionUrl = "http://maps.apple.com/?daddr=\(g_poiLat),\(g_poiLon)&dirflg=w"
//        
//        if (UIApplication.shared.canOpenURL(URL(string:"http://maps.apple.com")!)) {
//            UIApplication.shared.openURL(URL(string: directionUrl)!)
//        } else {
//            NSLog("Can't use Apple Maps");
//        }

        // Google Map
       //self.performSegue(withIdentifier: StorySegues.FromDetailToRide.rawValue, sender: self)
        
        if UIApplication.shared.canOpenURL(URL(string: "comgooglemaps://")!) {
            UIApplication.shared.openURL(URL(string: "comgooglemaps://?saddr=&daddr=\(g_poiLat),\(g_poiLon)&directionsmode=driving&zoom=20")!)
        }
        else {
            
            let alert = UIAlertController(title: ("Google Maps hasn't installed in your phone. Do you want to install now?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Apple Store", style: .default, handler: { (action) in

                UIApplication.shared.openURL(URL(string: "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?type=Purple+Software&id=585027354")!)
                
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
    }
    
    @IBAction func onTappedRideUber(_ sender: Any) {
        // Apple Map
        //        let directionUrl = "http://maps.apple.com/?daddr=\(g_poiLat),\(g_poiLon)&dirflg=w"
        //
        //        if (UIApplication.shared.canOpenURL(URL(string:"http://maps.apple.com")!)) {
        //            UIApplication.shared.openURL(URL(string: directionUrl)!)
        //        } else {
        //            NSLog("Can't use Apple Maps");
        //        }
        
        // Google Map
        //self.performSegue(withIdentifier: StorySegues.FromDetailToRide.rawValue, sender: self)
        
        if UIApplication.shared.canOpenURL(URL(string:"uber://")!) {
            UIApplication.shared.openURL(URL(string: "uber://")!)
       }
        else {
            let alert = UIAlertController(title: ("Uber Ride hasn't installed in your phone. Do you want to install now?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Apple Store", style: .default, handler: { (action) in
                
                UIApplication.shared.openURL(URL(string: "itms-apps://itunes.apple.com/WebObjects/MZStore.woa/wa/viewSoftware?type=Purple+Software&id=368677368")!)
                
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func removeSpecialCharsFromString(text: String) -> String {
        let okayChars : Set<Character> =
            Set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890+-*=(),.:!_".characters)
        return String(text.characters.filter {okayChars.contains($0) })
    }
    
    @IBAction func onTappedCall(_ sender: Any) {

        //var ph = "+442565895321"    //"+44207228076"
        var ph = info_phone_number_Label.text
        ph = removeSpecialCharsFromString(text: ph!)
        print(ph)
        
        if let phoneURL = NSURL(string: "tel://\(ph!)") {
            
            //UIApplication.shared.openURL(phoneURL as URL)
            
            
            let alert = UIAlertController(title: ("Call \(ph!) ?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Call", style: .default, handler: { (action) in
                UIApplication.shared.openURL(phoneURL as URL)
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
    }

/*
    struct Detail_Restaurant_Info{
        var favorite: Bool
        var top_picks = [top_picks_Info]()
        var info: restaurants_Info
        var reviews = [reviews_Info]()
        var zirafers = [Zir_restaurants_Info]()
    }
    var g_Rest_Init_Temp: restaurants_Info = restaurants_Info(id: -1, name: "", rating: 0.0, price: 0, phone_number: "", category_id: [], opening_hours: [], pictures: [], location: [])
    var g_Detail_Restaurant: Detail_Restaurant_Info = Detail_Restaurant_Info(favorite: false, top_picks: [], info: g_Rest_Init_Temp, reviews: [], zirafers: [])
*/
    
    //=========================================================================================
    //
    // Post Get_DetailRestaurant
    //
    //=========================================================================================
    func Get_DetailRestaurant() {

        g_Rest_Init_Temp = restaurants_Info(id: -1, name: "", rating: 0.0, price: 0, phone_number: "", category_id: [], opening_hours: [], pictures: [], location: [], street_name: "")
        g_Detail_Restaurant = Detail_Restaurant_Info(favorite: false, top_picks: [], info: g_Rest_Init_Temp, reviews: [], zirafers: [])
        tableView.reloadData()
        
        let serviceObj = ServiceClass()
        if g_Pick_Restaurant_Id == -1 {
            return
        }
        if g_ProfileInfo.id == -1 {
            return
        }
        
        //ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.Get_Rest_Info)\(g_Pick_Restaurant_Id)&user_id=\(g_ProfileInfo.id)", fields: "", completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject["success"] as! Bool
                
                if returnTemp == false {
                    //ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    g_Detail_Restaurant.favorite = responseObject["favorite"] as! Bool
                    
                    let top_picks_dict  = responseObject["top_picks"]  as! NSArray
                    if (top_picks_dict != nil ) {
                        
                        for top_picks_data in top_picks_dict {
                        
                            var Temp: top_picks_Info = top_picks_Info(id: -1, zirafer_id: -1, rest_id: -1, description: "")
                            let dict = top_picks_data as! [String: AnyObject]
                            
                            Temp.id = dict["_id"]                   as! Int
                            Temp.zirafer_id = dict["zirafer_id"]    as! Int
                            Temp.rest_id = dict["rest_id"]          as! Int
                            Temp.description = dict["description"]  as! String
                            
                            g_Detail_Restaurant.top_picks.append(Temp)
                        }
                    }

                    
                    let info_dict = responseObject["info"] as! [String: AnyObject]
                    g_Rest_Init_Temp.id = info_dict["_id"]          as! Int
                    g_Rest_Init_Temp.name = info_dict["name"]       as! String
                    g_Rest_Init_Temp.rating = info_dict["rating"]   as! Double
                    g_Rest_Init_Temp.price = info_dict["price"]     as! Int
                    g_Rest_Init_Temp.phone_number = info_dict["phone_number"]   as! String
                    g_Rest_Init_Temp.street_name = info_dict["street_name"]   as! String
                    
                    g_Rest_Init_Temp.opening_hours = info_dict["opening_hours"] as! [String]
                    g_Rest_Init_Temp.pictures = info_dict["pictures"] as! [String]
                    g_Rest_Init_Temp.location = info_dict["location"] as! [Double]
                    
                    g_Detail_Restaurant.info = g_Rest_Init_Temp
                    
                    
                    let reviews_dict = responseObject["reviews"]  as! NSArray
                    if (reviews_dict != nil ) {
                        for reviews_data in reviews_dict {
                            
                            var Temp: reviews_Info = reviews_Info(id: -1, zirafer_id: -1, rest_id: -1, review: "", rating: [])
                            let dict = reviews_data as! [String: AnyObject]
                            
                            Temp.id = dict["_id"]                   as! Int
                            Temp.zirafer_id = dict["zirafer_id"]    as! Int
                            Temp.rest_id = dict["rest_id"]          as! Int
                            Temp.review = dict["review"]            as! String
                            Temp.rating = dict["rating"]            as! [Double]
                            
                            g_Detail_Restaurant.reviews.append(Temp)
                        }
                    }

                    
                    let zirafers_dict = responseObject["zirafers"]  as! NSArray
                    if (zirafers_dict != nil ) {
                        for zirafers_data in zirafers_dict {
                            
                            var Temp: Zir_restaurants_Info = Zir_restaurants_Info(id: -1, name: "")
                            let dict = zirafers_data as! [String: AnyObject]
                            
                            Temp.id = dict["id"]        as! Int
                            Temp.name = dict["name"]    as! String
                            
                            g_Detail_Restaurant.zirafers.append(Temp)
                        }
                    }
                    
                    
                    
                    let when = DispatchTime.now() + 1.0
                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        //ProgressHUD.dismiss()
                        
                        self.UpdateUI()
                        
                        self.AnimationView1.fadeIn(duration: 0.5, delay: 0.5)
                        self.AnimationView2.fadeIn(duration: 0.5, delay: 0.5)
                        self.small_neck_button.fadeIn(duration: 0.5, delay: 0.5)
                        
                        self.tableView.reloadData()
                        self.collectionView.reloadData()
                    }
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                //ProgressHUD.dismiss()
            }
        })
    }
    
    func UpdateUI() {
        
        // favorite ICON
        if g_Detail_Restaurant.favorite == true {
            self.small_neck_button.setBackgroundImage(UIImage(named: "white_giraff.png"), for: .normal)
        } else {
            self.small_neck_button.setBackgroundImage(UIImage(named: "Ziraf favourite button.png"), for: .normal)
        }
        
        // Slide VIEW
        g_Rest_Detail_UrlSource.removeAll()
        for i in 0..<g_Detail_Restaurant.info.pictures.count {
            let url = "http://35.177.9.16:8080/upload/restaurant?url=\(g_Detail_Restaurant.info.pictures[i]).png"
            g_Rest_Detail_UrlSource.append(AlamofireSource(url: URL(string: url)!))
        }
        if g_Detail_Restaurant.info.pictures.count != 0 {
            slideView.setImageInputs(g_Rest_Detail_UrlSource)
        }
        
        // Restaurant Name
        RestaurantName.text = g_Detail_Restaurant.info.name
        
        // Restaurant street_name
        RestaurantLocation.text = g_Detail_Restaurant.info.street_name
       
        // Price, TopPickNum, Rating, Distance
        var temp_price: String = ""
        for i in 0..<g_Detail_Restaurant.info.price {
            temp_price = temp_price + "£"
        }
        info_price_Label.text = temp_price
        info_topic_Label.text = "\(g_Detail_Restaurant.top_picks.count)"
        
        if g_Detail_Restaurant.info.rating != -1.0 {
            info_rating_Label.text = "\(g_Detail_Restaurant.info.rating)"
        } else {
            info_rating_Label.text = "--"
        }
        
        
        // Direction, Phone_Number, OpenTime
        info_distance_Label.text = ""
        info_phone_number_Label.text = g_Detail_Restaurant.info.phone_number
        
        var temp_opentime: String = ""
        for i in 0..<g_Detail_Restaurant.info.opening_hours.count {
            temp_opentime = temp_opentime + g_Detail_Restaurant.info.opening_hours[i] + "\n\r"
        }
        
        info_open_Sub_TextView.text = temp_opentime
        info_open_Sub_Label.text = temp_opentime
        
        if g_Detail_Restaurant.info.opening_hours.count != 0 {
            info_open_MainLabel.text = g_Detail_Restaurant.info.opening_hours[0]
        } else {
            info_open_MainLabel.text = ""
        }
        
        // Restaurant Location
        g_poiLat = "\(g_Detail_Restaurant.info.location[0])"
        g_poiLon = "\(g_Detail_Restaurant.info.location[1])"
        
        // Distance
        let coordinate_1 = CLLocation(latitude: g_User_Lat, longitude: g_User_Lon)
        let coordinate_2 = CLLocation(latitude: g_Detail_Restaurant.info.location[0], longitude: g_Detail_Restaurant.info.location[1])
        
        let distanceInMeters = coordinate_1.distance(from: coordinate_2) // result is in meters
        let distanceInMiles = distanceInMeters/1609.344
        
        let amountString = String(format: "%.01f", distanceInMiles)
        info_distance_Label.text = "\(amountString) mi"
        
        // menu page
        let menu_url = "http://35.177.9.16:8080/upload/menu?url=\(g_Detail_Restaurant.info.id).pdf"
        menu_web_view.delegate = self
        if let url = URL(string: menu_url) {
            let request = URLRequest(url: url)
            menu_web_view.loadRequest(request)
        }
    }
    
    @IBAction func onTapped_Interesting_ButtonMethod(_ sender: Any) {
        // menu page
        
        // menu page
        let menu_url = "http://35.177.9.16:8080/upload/menu?url=\(g_Detail_Restaurant.info.id).pdf"
        menu_web_view.delegate = self
        if let url = URL(string: menu_url) {
            let request = URLRequest(url: url)
            menu_web_view.loadRequest(request)
        }
        
        let alertController = UIAlertController(title: "button text ?", message: "", preferredStyle: .alert)
        let confirmAction = UIAlertAction(title: "ok", style: .default) { (_) in
            if let TitleTextField = alertController.textFields?[0] {
                
                if TitleTextField.text == "" { return }
                if TitleTextField.text != "dhjdaj" { return }
                
                let menu_url = "https://www.google.com/"
                self.menu_web_view.delegate = self
                if let url = URL(string: menu_url) {
                    let request = URLRequest(url: url)
                    self.self.menu_web_view.loadRequest(request)
                }
            }
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in
        }
        
        alertController.addTextField { (textField) in
            textField.placeholder = ""
        }
        
        alertController.addAction(confirmAction)
        alertController.addAction(cancelAction)
        
        let subview = (alertController.view.subviews.first?.subviews.first?.subviews.first!)! as UIView
        subview.backgroundColor = UIColor.lightGray
        
        present(alertController, animated: true, completion: nil)
    
    }
    //=========================================================================================
    //
    // Post Set_Favorite
    //
    //=========================================================================================
    func trySet_Favorite() {
        
        let params: NSDictionary = [
            "user_id": g_ProfileInfo.id,
            "rest_id": g_Detail_Restaurant.info.id
        ]
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.SET_FAVORITE, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                } else {
                    
                    if g_Detail_Restaurant.favorite == true {
                        g_Detail_Restaurant.favorite = false
                        self.small_neck_button.setBackgroundImage(UIImage(named: "Ziraf favourite button.png"), for: .normal)
                    } else {
                        g_Detail_Restaurant.favorite = true
                        self.small_neck_button.setBackgroundImage(UIImage(named: "white_giraff.png"), for: .normal)
                    }
                }
            }
            else {
            }
        })
    }
}


