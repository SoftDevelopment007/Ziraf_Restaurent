//
//  ResetPassViewController.swift
//  Ziraf
//
//  Created by LEE on 8/21/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class ResetPassViewController: UIViewController {
    
    let GlobalVar = Global()
    
    @IBOutlet weak var Done_Button: UIButton!
    
    @IBOutlet weak var NewPass_Text: UITextField!
    @IBOutlet weak var ConfirmPass_Text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        //in this page, dodo's setup
        self.view.dodo.topLayoutGuide = self.topLayoutGuide
        self.view.dodo.bottomLayoutGuide = self.bottomLayoutGuide
        self.view.dodo.style.bar.backgroundColor = UIColor.init(red: 170.0/255.0, green: 60.0/255.0, blue: 28.0/255.0, alpha: 1.0).withAlphaComponent(0.9)
        
        
        Done_Button.layer.cornerRadius = Done_Button.bounds.size.height / 2.0
        Done_Button.layer.borderColor = UIColor.init(red: 237.0/255.0, green: 125.0/255.0, blue: 13.0/255.0, alpha: 1.0).cgColor
        Done_Button.layer.borderWidth = 1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
        
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedDoneButton(_ sender: Any) {
        
        if NewPass_Text.text == ConfirmPass_Text.text {
            tryResetPassWord()
        } else {
            self.view.dodo.error("Please input correct password.")
        }
        
    }
    
    //=========================================================================================
    //
    // Post tryResetPassWord
    //
    //=========================================================================================
    func tryResetPassWord() {
        
        let params: NSDictionary = [
            "email":    g_forgot_email,
            "new_password": NewPass_Text.text
        ]
        
        let serviceObj = ServiceClass()
        
        //ProgressHUD.show()
        
        serviceObj.servicePostMethodWithAPIHeaderValue(apiValue: GlobalVar.APIHEADER, headerValue: GlobalVar.RESET_PASS, parameters: params, completion: { (responseObject) in
            
            //ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["success"] as! Bool
                
                if returnTemp == false {
                    
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                    let errorMsg = responseObject?["success"] as! Bool
                    self.view.dodo.error("\(errorMsg)")

                } else {
                    self.view.dodo.error("Your password changed successfully.")
                    
                    var viewControllers = self.navigationController?.viewControllers
                    viewControllers?.removeLast(2) // views to pop
                    self.navigationController?.setViewControllers(viewControllers!, animated: true)
                }
            }
            else {
            }
        })
    }
    
}
