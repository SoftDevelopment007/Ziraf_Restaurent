//
//  PhotosViewController.swift
//  Ziraf
//
//  Created by LEE on 8/25/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import UIKit

class PhotosViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var sub_view: UIView!
    @IBOutlet weak var round_view1: UIView!
    @IBOutlet weak var round_view2: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var detail_Label: UILabel!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sub_view.fadeOut(duration: 0.0, delay: 0.0)
        
//        round_view1.layer.cornerRadius = 4.0
//        round_view1.layer.borderColor = UIColor.white.cgColor
//        round_view1.layer.borderWidth = 1
        
//        round_view2.layer.cornerRadius = 4.0
//        round_view2.layer.borderColor = UIColor.white.cgColor
//        round_view2.layer.borderWidth = 1
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)

        self.collectionView.reloadData()
        
        currentTableIndex = -1
    }

    @IBAction func onTappedHideButton(_ sender: Any) {
        sub_view.fadeOut(duration: 0.2, delay: 0.2)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }    

    @IBAction func onTappedBackButton(_ sender: Any) {
        g_numerOfpage_Flag = g_numerOfpage_Flag - 1
        self.navigationController?.popViewController(animated: true)
    }
    
    
    var currentTableIndex: Int = -1
    @IBAction func onTappedPhotosToDetailMethod(_ sender: Any) {
        
        if currentTableIndex == -1 {
            return
        }
        
        g_Pick_Restaurant_Id = g_zirafer_Profile.top_picks[currentTableIndex].rest_id
        //g_pickTable_Array[index].id
        
        g_numerOfpage_Flag = g_numerOfpage_Flag + 1 //3
        self.performSegue(withIdentifier: StorySegues.FromPhotosToDetail.rawValue, sender: self)
        
        
    }
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return g_zirafer_Profile.top_picks.count
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotosCollectionCell", for: indexPath as IndexPath) as! PhotosCollectionCell
        cell.backgroundColor =  UIColor.clear
        
        cell.myImageView.sd_setShowActivityIndicatorView(true)
        cell.myImageView.sd_setIndicatorStyle(.white)
        
        let url = "http://35.177.9.16:8080/upload/top_pick?url=\(g_zirafer_Profile.top_picks[indexPath.item].id).png"
        cell.myImageView.sd_setImage(with: URL(string: url))
        
        cell.description_Label.text = g_zirafer_Profile.top_picks[indexPath.item].description
    
        cell.Round_View.layer.borderColor = UIColor.black.cgColor
        cell.Round_View.layer.borderWidth = 1
        
        currentTableIndex = indexPath.item
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        let ScreenHeight = ScreenSize.height
        
        let newCellWidth = 110 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellWidth)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 10 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    // MARK: - UICollectionViewDelegate protocol
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        //let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotosCollectionCell", for: indexPath as IndexPath) as! PhotosCollectionCell
        
        
        imageView.sd_setShowActivityIndicatorView(true)
        imageView.sd_setIndicatorStyle(.white)
        let url = "http://35.177.9.16:8080/upload/top_pick?url=\(g_zirafer_Profile.top_picks[indexPath.item].id).png"
        imageView.sd_setImage(with: URL(string: url))
        
//        let ScreenSize = UIScreen.main.bounds
//        let ScreenWidth = ScreenSize.width
//        let newImg_width = ScreenWidth * 350 / 375
//        let newImg_height = (imageView.image?.size.height)! * ((imageView.image?.size.width)! / newImg_width)
//        imageView.image = imageView.image?.resize(width: newImg_width, height: newImg_height)

        
        self.detail_Label.text = g_zirafer_Profile.top_picks[indexPath.item].description
        
        sub_view.fadeIn(duration: 0.3, delay: 0.3)
    }

}

public extension UIImage {
    public func resize(width:CGFloat, height: CGFloat) -> UIImage? {
        
        UIGraphicsBeginImageContext(CGSize(width: width, height: height))
        self.draw(in: CGRect(x:0, y:0, width:width, height:height))
        let resultImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return resultImage
    }
}
