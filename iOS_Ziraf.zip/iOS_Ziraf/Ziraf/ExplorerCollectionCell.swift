//
//  ExplorerCollectionCell.swift
//  Ziraf
//
//  Created by LEE on 8/5/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit

class ExplorerCollectionCell: UICollectionViewCell {
    @IBOutlet weak var myTitle: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
}
