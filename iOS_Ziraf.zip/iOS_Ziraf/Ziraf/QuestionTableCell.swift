//
//  QuestionTableCell.swift
//  Ziraf
//
//  Created by LEE on 8/19/17.
//  Copyright © 2017 Ziraf. All rights reserved.
//

import Foundation
import UIKit
import KSTokenView

class QuestionTableCell: UITableViewCell {
    @IBOutlet weak var Question_Label: UILabel!
    @IBOutlet weak var Answer_TokenView: KSTokenView!
    
    @IBOutlet weak var selectButton: UIButton!
}
